ApplicationInformation2()
{

	/* select add a row in common area */

/*Correlation comment: Automatic rules - Do not change!  
Original value='/wEPDwUJOTIwNjYwMjQzDxYEHgpVaURhdGFLZXlzFQEUQXBwU3BlY1RhYmxlMTVDRTIwOEYeE1ZhbGlkYXRlUmVxdWVzdE1vZGUCARYCZg9kFgICAg9kFggCAQ8PFgIeB1Zpc2libGVoZGQCBw8WAh4FY2xhc3MFCEFDQV9IaWRlFgICAQ8PFgIfAmhkZAIJD2QWAgIBDxYCHgtfIUl0ZW1Db3VudAIBFgJmD2QWAgIBDw8WAh4WRXhwcmVzc2lvblNlc3Npb25Nb2RlbDKoCwABAAAA/////wEAAAAAAAAADAIAAABLQWNjZWxhLkFDQS5Nb2RlbCwgVmVyc2lvbj05LjIuMC4yMTczNCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWxsBQEAAAAxQWNjZWxhLkFDQS5FeHByZXNzaW9uQnVpbGQuRXhwcmVzc2lvblNlc3Npb25Nb2RlbAQAAAAmPEV4cHJlc3Npb25GYWN0b3J5VHlwZT5rX19CYWNraW5nRmllbGQrPEV4cHJlc3Npb25Bcmd1bWVudFBLTW9kZWxzPmtfX0JhY2tpbmdGaWVsZCc8RXhwcmVzc2lvbkJhc2VDb250cm9scz5rX19CYWNraW5nRmllbGQePEFzaXRVaURhdGFLZXk+a19fQmFja2luZ0ZpZWxkBAMDASlBY2NlbGEuQUNBLkV4cHJlc3Npb25CdWlsZC5FeHByZXNzaW9uVHlwZQIAAAClAVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkxpc3RgMVtbQWNjZWxhLkFDQS5XU1Byb3h5LkV4cHJlc3Npb25SdW50aW1lQXJndW1lbnRQS01vZGVsLCBBY2NlbGEuQUNBLk1vZGVsLCBWZXJzaW9uPTkuMi4wLjIxNzM0LCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPW51bGxdXeIBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuRGljdGlvbmFyeWAyW1tTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldLFtTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQIAAAAF/f///ylBY2NlbGEuQUNBLkV4cHJlc3Npb25CdWlsZC5FeHByZXNzaW9uVHlwZQEAAAAHdmFsdWVfXwAIAgAAAP7///8KCQQAAAAGBQAAABRBcHBTcGVjVGFibGUxNUNFMjA4RgQEAAAA4gFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5EaWN0aW9uYXJ5YDJbW1N5c3RlbS5TdHJpbmcsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV0sW1N5c3RlbS5TdHJpbmcsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV1dAwAAAAdWZXJzaW9uCENvbXBhcmVyCEhhc2hTaXplAAMACJIBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuR2VuZXJpY0VxdWFsaXR5Q29tcGFyZXJgMVtbU3lzdGVtLlN0cmluZywgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XV0IAAAAAAkGAAAAAAAAAAQGAAAAkgFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5HZW5lcmljRXF1YWxpdHlDb21wYXJlcmAxW1tTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQAAAAALZBYCAgMPPCsACQEADxYEHghEYXRhS2V5cxYAHwQCAWQWAmYPZBYCAgEPZBYCZg9kFgICAQ9kFgICAg9kFgJmD2QWAmYPZBYCZg8PZBYKHgpvbmtleXByZXNzBR5maWx0ZXIodGhpcyx0cnVlLHRydWUsZXZlbnQpOyAeB29ua2V5dXAFJnJlcGxhY2VEZWNpbWFsU2VwYXJhdG9yKHRoaXMsIGV2ZW50KTsgHgZvbmJsdXIFGExpbWl0UGFyc2UodGhpcyxldmVudCk7IB4Ib25jaGFuZ2UFJnJlcGxhY2VEZWNpbWFsU2VwYXJhdG9yKHRoaXMsIGV2ZW50KTsgHgp2YWxpZENoYXJzBQIuLmQCDQ8PFgIfAmhkZGQJ9t9uoUM5topJXLmJ2NNjYoRK5yuSvZW5zpCQYp/FTA==' 
Name ='AspNet_ViewState_5' 
Type ='Rule' 
AppName ='ASP.NET' 
RuleName ='__VIEWSTATE'*/
	web_reg_save_param_ex(
		"ParamName=AspNet_ViewState_5",
		"LB/IC=__VIEWSTATE\" value=\"",
		"RB/IC=\"",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/EditForm.aspx*",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='E91B3513' 
Name ='ViewStateGen_4' 
Type ='Rule' 
AppName ='AA' 
RuleName ='ViewstateGen'*/
	web_reg_save_param_ex(
		"ParamName=ViewStateGen_4",
		"LB/IC=__VIEWSTATEGENERATOR\" id=\"__VIEWSTATEGENERATOR\" value=\"",
		"RB/IC=\"",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/EditForm.aspx*",
		LAST);

	web_url("DrillDown.aspx", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/ASIT/DrillDown.aspx?module=LandDevelopment&action=add&param=%5B%2215CE208F%22%5D&qty=1&isSubAgencyCap=&uikey=[\"AppSpecTable15CE208F\"]&isPopup=Y&agencyCode=COSA", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=2&currentStep=2&currentPage=1&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=,N,N,N,N,N,N,N&confirmStepNumber=0&isFromConfirmPage=N&agencyCode=COSA", 
		"Snapshot=t73.inf", 
		"Mode=HTML", 
		LAST);

	/* enter acres and click submit */

	lr_think_time(21);

	web_submit_data("EditForm.aspx",
		"Action=https://acatest.sanantonio.gov/TestCitizenAccess/ASIT/EditForm.aspx?module=LandDevelopment&action=add&param=%5b%2215CE208F%22%5d&qty=1&isSubAgencyCap=&uikey=%5b%22AppSpecTable15CE208F%22%5d&isPopup=Y&agencyCode=COSA",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/ASIT/EditForm.aspx?module=LandDevelopment&action=add&param=%5b%2215CE208F%22%5d&qty=1&isSubAgencyCap=&uikey=%5b%22AppSpecTable15CE208F%22%5d&isPopup=Y&agencyCode=COSA",
		"Snapshot=t74.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=ACA_CS_FIELD", "Value={ACA_CS_FIELD}", ENDITEM,
		"Name=__EVENTTARGET", "Value=ctl00$phPopup$btnSubmit", ENDITEM,
		"Name=__EVENTARGUMENT", "Value=", ENDITEM,
		"Name=__VIEWSTATE", "Value={AspNet_ViewState_5}", ENDITEM,
		"Name=__VIEWSTATEGENERATOR", "Value={ViewStateGen_4}", ENDITEM,
		"Name=ASIT_15CE208F_1_0", "Value=0", ENDITEM,
		"Name=ctl00$HDExpressionParam", "Value=", ENDITEM,
		LAST);

	web_add_header("X-MicrosoftAjax", 
		"Delta=true");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

//Capture Viewstate	
	
	web_submit_data("CapEdit.aspx_8",
		"Action=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=2&currentStep=2&currentPage=1&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=%2cN%2cN%2cN%2cN%2cN%2cN%2cN&isFromConfirmPage=N&confirmStepNumber=0&agencyCode=COSA",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/plain",
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=2&currentStep=2&currentPage=1&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=,N,N,N,N,N,N,N&confirmStepNumber=0&isFromConfirmPage=N&agencyCode=COSA",
		"Snapshot=t75.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=ctl00$ScriptManager1", "Value=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl00$tablePanel|ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl00$tablePanel$HANDLE_ASIT_POSTEVENT$SYNC_ASIT_UICOPYDATA", ENDITEM,
		"Name=ACA_CS_FIELD", "Value={ACA_CS_FIELD}", ENDITEM,
		"Name=__EVENTTARGET", "Value=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl00$tablePanel$HANDLE_ASIT_POSTEVENT$SYNC_ASIT_UICOPYDATA", ENDITEM,
		"Name=__EVENTARGUMENT", "Value=", ENDITEM,
		"Name=__VIEWSTATE", "Value=/wEPDwULLTIxMTE2NDc3NDkPFgIeDEN1cnJlbnRDYXBJRDKvAgABAAAA/////wEAAAAAAAAADAIAAABLQWNjZWxhLkFDQS5Nb2RlbCwgVmVyc2lvbj05LjIuMC4yMTczNCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWxsBQEAAAAgQWNjZWxhLkFDQS5XU1Byb3h5LkNhcElETW9kZWw0V1MGAAAADWN1c3RvbUlERmllbGQIaWQxRmllbGQIaWQyRmllbGQIaWQzRmllbGQYc2VydmljZVByb3ZpZGVyQ29kZUZpZWxkD3RyYWNraW5nSURGaWVsZAEBAQEBAAkCAAAABgMAAAAMMThUTVAtMDA1OTM5BgQAAAAFMThFU1QGBQAAAAUwMDAwMAYGAAAABTA2MDM4BgcAAAAEQ09TQRLqlQ8AAAAACxYCZg9kFgYCAg8PFgQeCUFjY2Vzc0tleQUBMB4HVmlzaWJsZWhkZAIDDw8WBB8BBQExHghUYWJJbmRleAH//2RkAgQPZBYGAgIPZBYCAgIPZBYEZg8WAh8CZxYKZg8WAh4EaHJlZgUeL1Rlc3RDaXRpemVuQWNjZXNzL0xvZ291dC5hc3B4ZAIHDw9kFgIeBXN0eWxlBQ1kaXNwbGF5Om5vbmU7ZAIJDxYCHwJoFgICAQ8PFgIfAmhkZAIKDw8WBB4JSXNFbmNvZGVkaB4EVGV4dAUPQ29sbGVjdGlvbnMgKDApZGQCDg8PFgYeB1Rvb2xUaXAFDEFtaXQgQWdyYXdhbB8GaB8HBQxBbWl0IEFncmF3YWxkZAIBD2QWBAIDDw9kFgIfBQUNZGlzcGxheTpub25lO2QCBQ8WAh8EZGQCAw9kFg5mDw8WCB4IQ3NzQ2xhc3MFFkFDQV9OU2hvdCBtYXNrZWRmaWVsZHMeBVRleHQyZR4JTWF4TGVuZ3RoZh4EXyFTQgICZBYEAgMPFhAeIEN1bHR1cmVDdXJyZW5jeVN5bWJvb"
		"FBsYWNlaG9sZGVyBQEkHgdDdWx0dXJlBQVlbi1VUx4WQ3VsdHVyZVRpbWVQbGFjZWhvbGRlcgUBOh4bQ3VsdHVyZVRob3VzYW5kc1BsYWNlaG9sZGVyBQEsHhZDdWx0dXJlRGF0ZVBsYWNlaG9sZGVyBQEvHhlDdWx0dXJlRGVjaW1hbFBsYWNlaG9sZGVyBQEuHg5DdWx0dXJlRGF0ZUZNVAUDTURZHhZDdWx0dXJlQU1QTVBsYWNlaG9sZGVyBQVBTTtQTWQCBA8PZBYuHg5Ub29sdGlwTWVzc2FnZWUeE01heGltdW1WYWx1ZU1lc3NhZ2VlHhNNaW5pbXVtVmFsdWVNZXNzYWdlBR5EYXRlIG11c3QgYmUgYWZ0ZXIgMDEvMDEvMTc1NS4eClZhbGlkRW1wdHkFBHRydWUeB0NlbnR1cnkFATAeGENsaWVudFZhbGlkYXRpb25GdW5jdGlvbmUeEGxhc3RNYXNrUG9zaXRpb24FAjExHhFGaXJzdE1hc2tQb3NpdGlvbgUBMB4MTWluaW11bVZhbHVlBQowMS8wMS8xNzU1HgxNYXhpbXVtVmFsdWVlHgpEYXRlRm9ybWF0BQNNRFkeFFZhbGlkYXRpb25FeHByZXNzaW9uZR4MSXNNYXNrZWRFZGl0BQR0cnVlHghDc3NGb2N1cwUPTWFza2VkRWRpdEZvY3VzHhNJbnZhbGlkVmFsdWVNZXNzYWdlBRNFbnRlciBhcyBNTS9kZC95eXl5Hg9UYXJnZXRWYWxpZGF0b3IFKWN0bDAwX1BsYWNlSG9sZGVyTWFpbl9BY2NlbGFDYWxlbmRhclRleHQxHhRJbnZhbGlkVmFsdWVDc3NDbGFzcwUPTWFza2VkRWRpdEVycm9yHgtJc0hpanJpRGF0ZQUFZmFsc2UeD0Nzc0JsdXJOZWdhdGl2ZQUWTWFza2VkRWRpdEJsdXJOZWdhdGl2ZR4QQ3NzRm9jdXNOZWdhdGl2ZQUXTWFza2VkRWRpdEZvY3VzTmV"
		"nYXRpdmUeEUVtcHR5VmFsdWVNZXNzYWdlZR4MSW5pdGlhbFZhbHVlZR4NRGF0ZVNlcGFyYXRvcgUBL2QCAQ9kFgpmD2QWAmYPFgIeBXRpdGxlBQdMb2NrZWQgZAIBD2QWAmYPFgIfLAUHT24gSG9sZGQCAg9kFgJmDxYCHywFBk5vdGljZWQCAw9kFgJmDxYCHywFCFJlcXVpcmVkZAIED2QWBAIBD2QWAgIFD2QWAmYPZBYCAgEPPCsAEQIBEBYAFgAWAAwUKwAAZAIDD2QWAgIFD2QWAmYPZBYCAgMPPCsAEQMADxYCHg5TaG93RXhwb3J0TGlua2hkARAWABYAFgAMFCsAAGQCAg8PFgIeCHN0ZXBMaXN0MscnAAEAAAD/////AQAAAAAAAAAEAQAAAPkBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuRGljdGlvbmFyeWAyW1tTeXN0ZW0uSW50MzIsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV0sW0FjY2VsYS5XZWIuQ29udHJvbHMuQnJlYWRDcnVtcEluZm8sIEFjY2VsYS5XZWIuQ29udHJvbHMsIFZlcnNpb249OS4yLjAuMjE3MzgsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49bnVsbF1dBAAAAAdWZXJzaW9uCENvbXBhcmVyCEhhc2hTaXplDUtleVZhbHVlUGFpcnMAAwADCJEBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuR2VuZXJpY0VxdWFsaXR5Q29tcGFyZXJgMVtbU3lzdGVtLkludDMyLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQj9AVN5c3RlbS5Db2xsZ"
		"WN0aW9ucy5HZW5lcmljLktleVZhbHVlUGFpcmAyW1tTeXN0ZW0uSW50MzIsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV0sW0FjY2VsYS5XZWIuQ29udHJvbHMuQnJlYWRDcnVtcEluZm8sIEFjY2VsYS5XZWIuQ29udHJvbHMsIFZlcnNpb249OS4yLjAuMjE3MzgsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49bnVsbF1dW10HAAAACQIAAAAHAAAACQMAAAAEAgAAAJEBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuR2VuZXJpY0VxdWFsaXR5Q29tcGFyZXJgMVtbU3lzdGVtLkludDMyLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQAAAAAHAwAAAAABAAAABwAAAAP7AVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLktleVZhbHVlUGFpcmAyW1tTeXN0ZW0uSW50MzIsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV0sW0FjY2VsYS5XZWIuQ29udHJvbHMuQnJlYWRDcnVtcEluZm8sIEFjY2VsYS5XZWIuQ29udHJvbHMsIFZlcnNpb249OS4yLjAuMjE3MzgsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49bnVsbF1dDAUAAABOQWNjZWxhLldlYi5Db250cm9scywgVmVyc2lvbj05LjIuMC4yMTczOCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWx"
		"sBPz////7AVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLktleVZhbHVlUGFpcmAyW1tTeXN0ZW0uSW50MzIsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV0sW0FjY2VsYS5XZWIuQ29udHJvbHMuQnJlYWRDcnVtcEluZm8sIEFjY2VsYS5XZWIuQ29udHJvbHMsIFZlcnNpb249OS4yLjAuMjE3MzgsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49bnVsbF1dAgAAAANrZXkFdmFsdWUABAgiQWNjZWxhLldlYi5Db250cm9scy5CcmVhZENydW1wSW5mbwUAAAABAAAACQYAAAAB+f////z///8CAAAACQgAAAAB9/////z///8DAAAACQoAAAAB9f////z///8EAAAACQwAAAAB8/////z///8FAAAACQ4AAAAB8f////z///8GAAAACRAAAAAB7/////z///8HAAAACRIAAAAFBgAAACJBY2NlbGEuV2ViLkNvbnRyb2xzLkJyZWFkQ3J1bXBJbmZvCAAAAAdfZW5hYmxlGDxDYXBOYW1lPmtfX0JhY2tpbmdGaWVsZBo8UGFnZXRpdGxlPmtfX0JhY2tpbmdGaWVsZBo8U3RlcEluZGV4PmtfX0JhY2tpbmdGaWVsZB88U3RlcEluZGV4VGl0bGU+a19fQmFja2luZ0ZpZWxkFjxUaXRsZT5rX19CYWNraW5nRmllbGQUPFVybD5rX19CYWNraW5nRmllbGQhPFBhZ2VJbnN0cnVjdGlvbnM+a19fQmFja2luZ0ZpZWxkAAEBAAEBAQMBCH9TeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5MaXN0YDFbW1N5c3RlbS5TdHJpbmcsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1c"
		"mU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV1dBQAAAAEGEwAAAApNYWpvciBQbGF0BhQAAAA9UHJvcGVydHl8QWRkaXRpb25hbCBQYXJjZWwocyl8U2VhcmNoIFJlc3VsdHxTZWxlY3RlZCBQYXJjZWxzfAEAAAAGFQAAAAExBhYAAAAUUHJvcGVydHkgSW5mb3JtYXRpb24GFwAAANwBL1Rlc3RDaXRpemVuQWNjZXNzL0NhcC9DYXBFZGl0LmFzcHg/c3NuPTEmY3VycmVudFBhZ2U9MCZpc0Zyb21TaG9wcGluZ0NhcnQ9JmN1cnJlbnRTdGVwPSZpc0Zyb21Db25maXJtUGFnZT0sTixOLE4sTixOLE4sTixOJmNvbmZpcm1TdGVwTnVtYmVyPTAmc3RlcE51bWJlcj0yJnBhZ2VOdW1iZXI9MSZpc1JlbmV3YWw9TiZNb2R1bGU9TGFuZERldmVsb3BtZW50JmFnZW5jeUNvZGU9Q09TQQkYAAAAAQgAAAAGAAAAAQkTAAAABhoAAAATQXBwbGljYW50fENvbnRhY3RzfAIAAAAGGwAAAAEyBhwAAAATQ29udGFjdCBJbmZvcm1hdGlvbgYdAAAA3QEvVGVzdENpdGl6ZW5BY2Nlc3MvQ2FwL0NhcEVkaXQuYXNweD9zc249MSZjdXJyZW50UGFnZT0wJmlzRnJvbVNob3BwaW5nQ2FydD0mY3VycmVudFN0ZXA9MSZpc0Zyb21Db25maXJtUGFnZT0sTixOLE4sTixOLE4sTixOJmNvbmZpcm1TdGVwTnVtYmVyPTAmc3RlcE51bWJlcj0zJnBhZ2VOdW1iZXI9MSZpc1JlbmV3YWw9TiZNb2R1bGU9TGFuZERldmVsb3BtZW50JmFnZW5jeUNvZGU9Q09TQQkeAAAAAQoAAAAGAAAAAQkTAAAABiAAAAA9QXBwbGljYXRpb24gRGV0YWlsfEFwcGxpY2F0aW9uIERldGF"
		"pbCAyfEFwcGxpY2F0aW9uIERldGFpbCAzfAMAAAAGIQAAAAEzBiIAAAAXQXBwbGljYXRpb24gSW5mb3JtYXRpb24GIwAAAN0BL1Rlc3RDaXRpemVuQWNjZXNzL0NhcC9DYXBFZGl0LmFzcHg/c3NuPTEmY3VycmVudFBhZ2U9MCZpc0Zyb21TaG9wcGluZ0NhcnQ9JmN1cnJlbnRTdGVwPTImaXNGcm9tQ29uZmlybVBhZ2U9LE4sTixOLE4sTixOLE4sTiZjb25maXJtU3RlcE51bWJlcj0wJnN0ZXBOdW1iZXI9NCZwYWdlTnVtYmVyPTEmaXNSZW5ld2FsPU4mTW9kdWxlPUxhbmREZXZlbG9wbWVudCZhZ2VuY3lDb2RlPUNPU0EJJAAAAAEMAAAABgAAAAEJEwAAAAYmAAAACkRvY3VtZW50c3wEAAAABicAAAABNAYoAAAAFERvY3VtZW50IEluZm9ybWF0aW9uBikAAADdAS9UZXN0Q2l0aXplbkFjY2Vzcy9DYXAvQ2FwRWRpdC5hc3B4P3Nzbj0xJmN1cnJlbnRQYWdlPTAmaXNGcm9tU2hvcHBpbmdDYXJ0PSZjdXJyZW50U3RlcD0zJmlzRnJvbUNvbmZpcm1QYWdlPSxOLE4sTixOLE4sTixOLE4mY29uZmlybVN0ZXBOdW1iZXI9MCZzdGVwTnVtYmVyPTUmcGFnZU51bWJlcj0xJmlzUmVuZXdhbD1OJk1vZHVsZT1MYW5kRGV2ZWxvcG1lbnQmYWdlbmN5Q29kZT1DT1NBCSoAAAABDgAAAAYAAAABCRMAAAAKBQAAAAYsAAAAATUGLQAAAAZSZXZpZXcGLgAAAAAKARAAAAAGAAAAAQkTAAAACgYAAAAGMAAAAAE2BjEAAAAIUGF5IEZlZXMJLgAAAAoBEgAAAAYAAAABCRMAAAAKBwAAAAY0AAAAATcGNQAAAA9SZWNvcmQgSXNzdWFuY2UJLgAAAAoEGAAAAH9TeXN0ZW0uQ29sbGVjd"
		"GlvbnMuR2VuZXJpYy5MaXN0YDFbW1N5c3RlbS5TdHJpbmcsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV1dAwAAAAZfaXRlbXMFX3NpemUIX3ZlcnNpb24GAAAICAk3AAAABAAAAAQAAAABHgAAABgAAAAJOAAAAAIAAAACAAAAASQAAAAYAAAACTkAAAADAAAAAwAAAAEqAAAAGAAAAAk6AAAAAQAAAAEAAAARNwAAAAQAAAAKBjsAAACtAzxkaXYgY2xhc3M9IkFDQV9MZ0J1dHRvbiBBQ0FfTGdCdXR0b25fRm9udFNpemUiPjxhIHRpdGxlPSJObyBBZGRpdGlvbmFsIFBhcmNlbHMiIGlkPSJidG5za2lwYWRkaXRpbmFscGFyY2VsIiBocmVmPSIvVGVzdENpdGl6ZW5BY2Nlc3MvQ2FwL0NhcEVkaXQuYXNweD9zdGVwTnVtYmVyPTMmYW1wO3BhZ2VOdW1iZXI9MSZhbXA7Y3VycmVudFN0ZXA9MSZhbXA7Y3VycmVudFBhZ2U9MCZhbXA7TW9kdWxlPUxhbmREZXZlbG9wbWVudCZhbXA7aXNSZW5ld2FsPU4mYW1wO2lzRnJvbVNob3BwaW5nQ2FydD0mYW1wO2lzRnJvbUNvbmZpcm1QYWdlPSxOLE4sTixOJmFtcDtjb25maXJtU3RlcE51bWJlcj0wJmFtcDtpc0Zyb21Db25maXJtUGFnZT1OJmFtcDthZ2VuY3lDb2RlPUNPU0EiID48c3Bhbj5ObyBBZGRpdGlvbmFsIFBhcmNlbHM8L3NwYW4+PC9hPjwvZGl2PgY8AAAAiAM8ZGl2IGNsYXNzPSJBQ0FfTGdCdXR0b24gQUNBX0xnQnV0dG9uX0ZvbnRTaXplIj48YSB0aXRsZT0iQWRkIE1vcmUgUGFyY2VscyIgaWQ9ImJ0bmFkZG1vcmV"
		"wYXJjZWwiIGhyZWY9Ii9UZXN0Q2l0aXplbkFjY2Vzcy9DYXAvQ2FwRWRpdC5hc3B4P3N0ZXBOdW1iZXI9MiZhbXA7cGFnZU51bWJlcj0yJmFtcDtjdXJyZW50U3RlcD0wJmFtcDtjdXJyZW50UGFnZT0xJmFtcDtNb2R1bGU9TGFuZERldmVsb3BtZW50JmFtcDtpc1JlbmV3YWw9TiZhbXA7aXNGcm9tU2hvcHBpbmdDYXJ0PSZhbXA7aXNGcm9tQ29uZmlybVBhZ2U9JmFtcDtjb25maXJtU3RlcE51bWJlcj0wJmFtcDtpc0Zyb21Db25maXJtUGFnZT1OJmFtcDthZ2VuY3lDb2RlPUNPU0EiPjxzcGFuPkJhY2s8L3NwYW4+PC9hPjwvZGl2PgY9AAAAlAM8ZGl2IGNsYXNzPSJBQ0FfTGdCdXR0b24gQUNBX0xnQnV0dG9uX0ZvbnRTaXplIj48YSB0aXRsZT0iQWRkIE1vcmUgUGFyY2VscyIgaWQ9ImJ0bmFkZG1vcmVwYXJjZWwiIGhyZWY9Ii9UZXN0Q2l0aXplbkFjY2Vzcy9DYXAvQ2FwRWRpdC5hc3B4P3N0ZXBOdW1iZXI9MiZhbXA7cGFnZU51bWJlcj0yJmFtcDtjdXJyZW50U3RlcD0wJmFtcDtjdXJyZW50UGFnZT0xJmFtcDtNb2R1bGU9TGFuZERldmVsb3BtZW50JmFtcDtpc1JlbmV3YWw9TiZhbXA7aXNGcm9tU2hvcHBpbmdDYXJ0PSZhbXA7aXNGcm9tQ29uZmlybVBhZ2U9JmFtcDtjb25maXJtU3RlcE51bWJlcj0wJmFtcDtpc0Zyb21Db25maXJtUGFnZT1OJmFtcDthZ2VuY3lDb2RlPUNPU0EiPjxzcGFuPkFkZCBNb3JlIFBhcmNlbHM8L3NwYW4+PC9hPjwvZGl2PhE4AAAABAAAAA0EETkAAAAEAAAADQQROgAAAAQAAAANBAtkZAIDD2QWAmYPZBYCAgUPZBYCA"
		"gEPZBYCAgEPEA8WBB8JBSxhY2FfY2hlY2tib3ggYWNhX2NoZWNrYm94X2ZvbnRzaXplIGFjYV9yYWRpbx8MAgIWAh4Ecm9sZQUMcHJlc2VudGF0aW9uZBYAZAIHD2QWBmYPDxYEHwEFATMfB2VkZAIBDxYCHwJoFgICAw8PFgIfAmhkZAIDDxYCHwJnFgICAw8WBB4FY2xhc3MFDk5vdFNob3dMb2FkaW5nHywFlgFTYXZlIHlvdXIgY2hhbmdlcyBhbmQgcmVzdW1lIGxhdGVyLiBXaGVuIHlvdSByZXR1cm4geW91IHdpbGwgc3RhcnQgb24gdGhlIGZpcnN0IHBhZ2Ugb2YgdGhlIGFwcGxpY2F0aW9uIHRvIGVuc3VyZSB5b3UgaGF2ZSBjb21wbGV0ZWQgYWxsIHJlcXVpcmVtZW50cy5kAgsPD2QWAh4Jb25rZXlkb3duBT5PdmVycmlkZVRhYktleShldmVudCwgdHJ1ZSwgJ2N0bDAwX1BsYWNlSG9sZGVyTWFpbl9idG5DYW5jZWwnKWQCDA8PZBYCHzEFO092ZXJyaWRlVGFiS2V5KGV2ZW50LCBmYWxzZSwgJ2N0bDAwX1BsYWNlSG9sZGVyTWFpbl9idG5PSycpZAIFDw8WAh8CaGRkGAsFPGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRjYXBDb25kaXRpb25zJGdkdkdlbmVyYWxDb25kaXRpb25zTGlzdA9nZAVQY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMDIkZ2R2QVNJVGFibGUPPCsADAEIZmQFUGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxNUNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDA0JGdkdkFTSVRhYmxlDzwrAAwBCGZkBVBjdGwwMCRQbGFjZUhvbGRlck1haW4kQXB"
		"wU3BlY1RhYmxlMTVDRTIwOEZFZGl0JHJwdEFTSVRhYmxlTGlzdCRjdGwxNCRnZHZBU0lUYWJsZQ88KwAMAQhmZAVQY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMDgkZ2R2QVNJVGFibGUPPCsADAEIZmQFUGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxNUNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDEwJGdkdkFTSVRhYmxlDzwrAAwBCGZkBVBjdGwwMCRQbGFjZUhvbGRlck1haW4kQXBwU3BlY1RhYmxlMTVDRTIwOEZFZGl0JHJwdEFTSVRhYmxlTGlzdCRjdGwxNiRnZHZBU0lUYWJsZQ88KwAMAQhmZAU/Y3RsMDAkUGxhY2VIb2xkZXJNYWluJGNhcENvbmRpdGlvbnMkZ2R2Q29uZGl0aW9uc09mQXBwcm92YWxMaXN0D2dkBVBjdGwwMCRQbGFjZUhvbGRlck1haW4kQXBwU3BlY1RhYmxlMTVDRTIwOEZFZGl0JHJwdEFTSVRhYmxlTGlzdCRjdGwwMCRnZHZBU0lUYWJsZQ88KwAMAQhmZAVQY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMDYkZ2R2QVNJVGFibGUPPCsADAEIZmQFUGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxNUNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDEyJGdkdkFTSVRhYmxlDzwrAAwBCGZk65phuSaibilpQTnTqojLn8BFVNeHHg6VC1XxpiXzqGY=", ENDITEM,
		"Name=__VIEWSTATEGENERATOR", "Value={ViewStateGen_3}", ENDITEM,
		"Name=txtSearchCondition", "Value=Search...", ENDITEM,
		"Name=ctl00$HeaderNavigation$hdnShoppingCartItemNumber", "Value=", ENDITEM,
		"Name=ctl00$HeaderNavigation$hdnShowReportLink", "Value=Y", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AccelaCalendarText1", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AccelaCalendarText1_ext_ClientState", "Value=", ENDITEM,
		"Name=component", "Value=AppSpecTable15CE208FEdit", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl00$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl02$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl04$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl06$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl08$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl10$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl12$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl14$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl16$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$HDExpressionParam", "Value=", ENDITEM,
		"Name=__LASTFOCUS_ID", "Value=ctl00_PlaceHolderMain_AppSpecTable15CE208FEdit_rptASITableList_ctl00_btnAdd", ENDITEM,
		"Name=__ASYNCPOST", "Value=true", ENDITEM,
		LAST);

	/* add a row for proposed use  */

	web_url("DrillDown.aspx_2", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/ASIT/DrillDown.aspx?module=LandDevelopment&action=add&param=%5B%22DA5F448A%22%5D&qty=1&isSubAgencyCap=&uikey=[\"AppSpecTable15CE208F\"]&isPopup=Y&agencyCode=COSA", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=2&currentStep=2&currentPage=1&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=,N,N,N,N,N,N,N&confirmStepNumber=0&isFromConfirmPage=N&agencyCode=COSA", 
		"Snapshot=t76.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(4);

	web_custom_request("RunExpression_20", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/WebService/ExpressionService.asmx/RunExpression", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/ASIT/EditForm.aspx?module=LandDevelopment&action=add&param=%5b%22DA5F448A%22%5d&qty=1&isSubAgencyCap=&uikey=%5b%22AppSpecTable15CE208F%22%5d&isPopup=Y&agencyCode=COSA", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"expressionArgument\":\"{\\\"apoNumber\\\":null,\\\"appSpecificInfoModelList\\\":null,\\\"argumentPKs\\\":[{\\\"portletID\\\":-2,\\\"viewKey1\\\":\\\"PROPOSED USE\\\",\\\"viewKey2\\\":null,\\\"viewKey3\\\":null}],\\\"asiGroupCode\\\":\\\"LAND_PLATMAJ\\\",\\\"callerID\\\":\\\"PUBLICUSER235\\\",\\\"capID\\\":{\\\"customID\\\":\\\"18TMP-005939\\\",\\\"ID1\\\":\\\"18EST\\\",\\\"ID2\\\":\\\"00000\\\",\\\"ID3\\\":\\\"06038\\\",\\\"serviceProviderCode\\\":\\\"COSA\\\",\\\"trackingID\\\":261483026}"
		",\\\"executeFieldVariableKey\\\":\\\"ASIT::PROPOSED USE::Proposed Use\\\",\\\"executeIn\\\":null,\\\"maxRowIndexes\\\":null,\\\"servProvCode\\\":\\\"COSA\\\"}\",\"inputFieldNames\":[\"InsertFirstRow\\fASIT::PROPOSED USE::Square Footage\",\"InsertFirstRow\\fASIT::PROPOSED USE::Number of Units\",\"InsertFirstRow\\fASIT::PROPOSED USE::Proposed Use\",\"InsertFirstRow\\fASIT::PROPOSED USE::Gross Floor Area (sq ft)\",\"InsertFirstRow\\fASIT::PROPOSED USE::Density\",\"InsertFirstRow\\fASIT::PROPOSED USE:"
		":Acres\",\"ASIT_DA5F448A_1_0\",\"ASIT_DA5F448A_1_2\",\"ASIT_DA5F448A_1_3\",\"ASIT_DA5F448A_1_4\",\"ASIT_DA5F448A_1_6\",\"ASIT_DA5F448A_1_7\"],\"inputFieldProperties\":[null,null,null,null,null,null,\"Single Family\\f\\f\\f\\f\",\"\\f\\f\\f\\f\",\"\\f\\f\\f\\f\",\"\\f\\f\\f\\f\",\"\\f\\f\\f\\f\",\"\\f\\f\\f\\f\"]}", 
		LAST);

	/* submit details for proposed use */

	lr_think_time(18);

	web_custom_request("RunExpression_21", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/WebService/ExpressionService.asmx/RunExpression", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/ASIT/EditForm.aspx?module=LandDevelopment&action=add&param=%5b%22DA5F448A%22%5d&qty=1&isSubAgencyCap=&uikey=%5b%22AppSpecTable15CE208F%22%5d&isPopup=Y&agencyCode=COSA", 
		"Snapshot=t78.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"expressionArgument\":\"{\\\"apoNumber\\\":null,\\\"appSpecificInfoModelList\\\":null,\\\"argumentPKs\\\":[{\\\"portletID\\\":-2,\\\"viewKey1\\\":\\\"PROPOSED USE\\\",\\\"viewKey2\\\":null,\\\"viewKey3\\\":null}],\\\"asiGroupCode\\\":\\\"LAND_PLATMAJ\\\",\\\"callerID\\\":\\\"PUBLICUSER235\\\",\\\"capID\\\":{\\\"customID\\\":\\\"18TMP-005939\\\",\\\"ID1\\\":\\\"18EST\\\",\\\"ID2\\\":\\\"00000\\\",\\\"ID3\\\":\\\"06038\\\",\\\"serviceProviderCode\\\":\\\"COSA\\\",\\\"trackingID\\\":261483026}"
		",\\\"executeFieldVariableKey\\\":\\\"onASITRowSubmit\\\",\\\"executeIn\\\":null,\\\"maxRowIndexes\\\":null,\\\"servProvCode\\\":\\\"COSA\\\"}\",\"inputFieldNames\":[\"InsertFirstRow\\fASIT::PROPOSED USE::Square Footage\",\"InsertFirstRow\\fASIT::PROPOSED USE::Number of Units\",\"InsertFirstRow\\fASIT::PROPOSED USE::Proposed Use\",\"InsertFirstRow\\fASIT::PROPOSED USE::Gross Floor Area (sq ft)\",\"InsertFirstRow\\fASIT::PROPOSED USE::Density\",\"InsertFirstRow\\fASIT::PROPOSED USE::Acres\",\""
		"ASIT_DA5F448A_1_0\",\"ASIT_DA5F448A_1_2\",\"ASIT_DA5F448A_1_3\",\"ASIT_DA5F448A_1_4\",\"ASIT_DA5F448A_1_6\",\"ASIT_DA5F448A_1_7\"],\"inputFieldProperties\":[null,null,null,null,null,null,\"Single Family\\f\\f\\f\\f\",\"500\\f\\f\\f\\f\",\"5\\f\\f\\f\\f\",\"10\\f\\f\\f\\f\",\"500\\f\\f\\f\\f\",\"50\\ftrue\\f\\f\\f\"]}", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_submit_data("EditForm.aspx_2",
		"Action=https://acatest.sanantonio.gov/TestCitizenAccess/ASIT/EditForm.aspx?module=LandDevelopment&action=add&param=%5b%22DA5F448A%22%5d&qty=1&isSubAgencyCap=&uikey=%5b%22AppSpecTable15CE208F%22%5d&isPopup=Y&agencyCode=COSA",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/ASIT/EditForm.aspx?module=LandDevelopment&action=add&param=%5b%22DA5F448A%22%5d&qty=1&isSubAgencyCap=&uikey=%5b%22AppSpecTable15CE208F%22%5d&isPopup=Y&agencyCode=COSA",
		"Snapshot=t79.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=ACA_CS_FIELD", "Value={ACA_CS_FIELD}", ENDITEM,
		"Name=__EVENTTARGET", "Value=ctl00$phPopup$btnSubmit", ENDITEM,
		"Name=__EVENTARGUMENT", "Value=", ENDITEM,
		"Name=__VIEWSTATE", "Value=/wEPDwUJOTIwNjYwMjQzDxYEHgpVaURhdGFLZXlzFQEUQXBwU3BlY1RhYmxlMTVDRTIwOEYeE1ZhbGlkYXRlUmVxdWVzdE1vZGUCARYCZg9kFgICAg9kFggCAQ8PFgIeB1Zpc2libGVoZGQCBw8WAh4FY2xhc3MFCEFDQV9IaWRlFgICAQ8PFgIfAmhkZAIJD2QWAgIBDxYCHgtfIUl0ZW1Db3VudAIBFgJmD2QWAgIBDw8WAh4WRXhwcmVzc2lvblNlc3Npb25Nb2RlbDKoCwABAAAA/////wEAAAAAAAAADAIAAABLQWNjZWxhLkFDQS5Nb2RlbCwgVmVyc2lvbj05LjIuMC4yMTczNCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWxsBQEAAAAxQWNjZWxhLkFDQS5FeHByZXNzaW9uQnVpbGQuRXhwcmVzc2lvblNlc3Npb25Nb2RlbAQAAAAmPEV4cHJlc3Npb25GYWN0b3J5VHlwZT5rX19CYWNraW5nRmllbGQrPEV4cHJlc3Npb25Bcmd1bWVudFBLTW9kZWxzPmtfX0JhY2tpbmdGaWVsZCc8RXhwcmVzc2lvbkJhc2VDb250cm9scz5rX19CYWNraW5nRmllbGQePEFzaXRVaURhdGFLZXk+a19fQmFja2luZ0ZpZWxkBAMDASlBY2NlbGEuQUNBLkV4cHJlc3Npb25CdWlsZC5FeHByZXNzaW9uVHlwZQIAAAClAVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkxpc3RgMVtbQWNjZWxhLkFDQS5XU1Byb3h5LkV4cHJlc3Npb25SdW50aW1lQXJndW1lbnRQS01vZGVsLCBBY2NlbGEuQUNBLk1vZGVsLCBWZXJzaW9uPTkuMi4wLjIxNzM0LCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPW51bGxdXeIBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVya"
		"WMuRGljdGlvbmFyeWAyW1tTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldLFtTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQIAAAAF/f///ylBY2NlbGEuQUNBLkV4cHJlc3Npb25CdWlsZC5FeHByZXNzaW9uVHlwZQEAAAAHdmFsdWVfXwAIAgAAAP7///8KCQQAAAAGBQAAABRBcHBTcGVjVGFibGUxNUNFMjA4RgQEAAAA4gFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5EaWN0aW9uYXJ5YDJbW1N5c3RlbS5TdHJpbmcsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV0sW1N5c3RlbS5TdHJpbmcsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV1dAwAAAAdWZXJzaW9uCENvbXBhcmVyCEhhc2hTaXplAAMACJIBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuR2VuZXJpY0VxdWFsaXR5Q29tcGFyZXJgMVtbU3lzdGVtLlN0cmluZywgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XV0IAAAAAAkGAAAAAAAAAAQGAAAAkgFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJ"
		"pYy5HZW5lcmljRXF1YWxpdHlDb21wYXJlcmAxW1tTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQAAAAALZBYCAgMPPCsACQEADxYEHghEYXRhS2V5cxYAHwQCAWQWAmYPZBYCAgEPZBYCZg9kFgICAQ9kFgICAg9kFgZmD2QWAgICD2QWAmYPD2QWCh4Kb25rZXlwcmVzcwUeZmlsdGVyKHRoaXMsdHJ1ZSx0cnVlLGV2ZW50KTsgHgdvbmtleXVwBSZyZXBsYWNlRGVjaW1hbFNlcGFyYXRvcih0aGlzLCBldmVudCk7IB4Gb25ibHVyBRhMaW1pdFBhcnNlKHRoaXMsZXZlbnQpOyAeCG9uY2hhbmdlBSZyZXBsYWNlRGVjaW1hbFNlcGFyYXRvcih0aGlzLCBldmVudCk7IB4KdmFsaWRDaGFycwUCLi5kAgEPZBYEZg9kFgJmDw9kFgofBwUeZmlsdGVyKHRoaXMsdHJ1ZSx0cnVlLGV2ZW50KTsgHwgFJnJlcGxhY2VEZWNpbWFsU2VwYXJhdG9yKHRoaXMsIGV2ZW50KTsgHwkFGExpbWl0UGFyc2UodGhpcyxldmVudCk7IB8KBSZyZXBsYWNlRGVjaW1hbFNlcGFyYXRvcih0aGlzLCBldmVudCk7IB8LBQIuLmQCAQ9kFgJmDw9kFgofBwUeZmlsdGVyKHRoaXMsdHJ1ZSx0cnVlLGV2ZW50KTsgHwgFJnJlcGxhY2VEZWNpbWFsU2VwYXJhdG9yKHRoaXMsIGV2ZW50KTsgHwkFGExpbWl0UGFyc2UodGhpcyxldmVudCk7IB8KBSZyZXBsYWNlRGVjaW1hbFNlcGFyYXRvcih0aGlzLCBldmVudCk7IB8LBQIuLmQCAg9kFgRmD2QWAmYPD2QWCh8HBR5maWx0ZXIodGhpc"
		"yx0cnVlLHRydWUsZXZlbnQpOyAfCAUmcmVwbGFjZURlY2ltYWxTZXBhcmF0b3IodGhpcywgZXZlbnQpOyAfCQUYTGltaXRQYXJzZSh0aGlzLGV2ZW50KTsgHwoFJnJlcGxhY2VEZWNpbWFsU2VwYXJhdG9yKHRoaXMsIGV2ZW50KTsgHwsFAi4uZAIBD2QWAmYPD2QWCh8HBR5maWx0ZXIodGhpcyx0cnVlLHRydWUsZXZlbnQpOyAfCAUmcmVwbGFjZURlY2ltYWxTZXBhcmF0b3IodGhpcywgZXZlbnQpOyAfCQUYTGltaXRQYXJzZSh0aGlzLGV2ZW50KTsgHwoFJnJlcGxhY2VEZWNpbWFsU2VwYXJhdG9yKHRoaXMsIGV2ZW50KTsgHwsFAi4uZAINDw8WAh8CaGRkZHmWQ0cWNdpZUkNcZY9qn/YlP4rHdivhO21mJBS3bwZi", ENDITEM,
		"Name=__VIEWSTATEGENERATOR", "Value={ViewStateGen_4}", ENDITEM,
		"Name=ASIT_DA5F448A_1_0", "Value=Single Family", ENDITEM,
		"Name=ASIT_DA5F448A_1_1", "Value=", ENDITEM,
		"Name=ASIT_DA5F448A_1_2", "Value=500", ENDITEM,
		"Name=ASIT_DA5F448A_1_3", "Value=5", ENDITEM,
		"Name=ASIT_DA5F448A_1_4", "Value=10", ENDITEM,
		"Name=ASIT_DA5F448A_1_5", "Value=", ENDITEM,
		"Name=ASIT_DA5F448A_1_6", "Value=500", ENDITEM,
		"Name=ASIT_DA5F448A_1_7", "Value=50", ENDITEM,
		"Name=ctl00$HDExpressionParam", "Value=[{\"name\":\"ASIT_DA5F448A_1_7\",\"required\":true,\"readOnly\":null,\"message\":\"\",\"type\":4,\"hidden\":null,\"IsChecked\":false}]", ENDITEM,
		LAST);

	web_add_header("X-MicrosoftAjax", 
		"Delta=true");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("CapEdit.aspx_9",
		"Action=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=2&currentStep=2&currentPage=1&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=%2cN%2cN%2cN%2cN%2cN%2cN%2cN&isFromConfirmPage=N&confirmStepNumber=0&agencyCode=COSA",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/plain",
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=2&currentStep=2&currentPage=1&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=,N,N,N,N,N,N,N&confirmStepNumber=0&isFromConfirmPage=N&agencyCode=COSA",
		"Snapshot=t80.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=ctl00$ScriptManager1", "Value=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl16$tablePanel|ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl16$tablePanel$HANDLE_ASIT_POSTEVENT$SYNC_ASIT_UICOPYDATA", ENDITEM,
		"Name=txtSearchCondition", "Value=Search...", ENDITEM,
		"Name=ctl00$HeaderNavigation$hdnShoppingCartItemNumber", "Value=", ENDITEM,
		"Name=ctl00$HeaderNavigation$hdnShowReportLink", "Value=Y", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AccelaCalendarText1", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AccelaCalendarText1_ext_ClientState", "Value=", ENDITEM,
		"Name=component", "Value=AppSpecTable15CE208FEdit", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl00$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl02$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl04$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl06$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl08$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl10$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl12$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl14$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl16$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$HDExpressionParam", "Value=", ENDITEM,
		"Name=__LASTFOCUS_ID", "Value=ctl00_PlaceHolderMain_AppSpecTable15CE208FEdit_rptASITableList_ctl16_btnAdd", ENDITEM,
		"Name=__EVENTTARGET", "Value=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl16$tablePanel$HANDLE_ASIT_POSTEVENT$SYNC_ASIT_UICOPYDATA", ENDITEM,
		"Name=__EVENTARGUMENT", "Value=", ENDITEM,
		"Name=__VIEWSTATE", "Value=/wEPDwULLTIxMTE2NDc3NDkPFgIeDEN1cnJlbnRDYXBJRDKvAgABAAAA/////wEAAAAAAAAADAIAAABLQWNjZWxhLkFDQS5Nb2RlbCwgVmVyc2lvbj05LjIuMC4yMTczNCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWxsBQEAAAAgQWNjZWxhLkFDQS5XU1Byb3h5LkNhcElETW9kZWw0V1MGAAAADWN1c3RvbUlERmllbGQIaWQxRmllbGQIaWQyRmllbGQIaWQzRmllbGQYc2VydmljZVByb3ZpZGVyQ29kZUZpZWxkD3RyYWNraW5nSURGaWVsZAEBAQEBAAkCAAAABgMAAAAMMThUTVAtMDA1OTM5BgQAAAAFMThFU1QGBQAAAAUwMDAwMAYGAAAABTA2MDM4BgcAAAAEQ09TQRLqlQ8AAAAACxYCZg9kFgYCAg8PFgQeCUFjY2Vzc0tleQUBMB4HVmlzaWJsZWhkZAIDDw8WBB8BBQExHghUYWJJbmRleAH//2RkAgQPZBYGAgIPZBYCAgIPZBYEZg8WAh8CZxYKZg8WAh4EaHJlZgUeL1Rlc3RDaXRpemVuQWNjZXNzL0xvZ291dC5hc3B4ZAIHDw9kFgIeBXN0eWxlBQ1kaXNwbGF5Om5vbmU7ZAIJDxYCHwJoFgICAQ8PFgIfAmhkZAIKDw8WBB4JSXNFbmNvZGVkaB4EVGV4dAUPQ29sbGVjdGlvbnMgKDApZGQCDg8PFgYeB1Rvb2xUaXAFDEFtaXQgQWdyYXdhbB8GaB8HBQxBbWl0IEFncmF3YWxkZAIBD2QWBAIDDw9kFgIfBQUNZGlzcGxheTpub25lO2QCBQ8WAh8EZGQCAw9kFg5mDw8WCB4IQ3NzQ2xhc3MFI0FDQV9OU2hvdCBtYXNrZWRmaWVsZHMgbWFza2VkZmllbGRzHgVUZXh0MmUeCU1heExlbmd0aGYeBF8hU0ICAmQWBAIDDxYQHiBDdWx0dXJlQ"
		"3VycmVuY3lTeW1ib2xQbGFjZWhvbGRlcgUBJB4HQ3VsdHVyZQUFZW4tVVMeFkN1bHR1cmVUaW1lUGxhY2Vob2xkZXIFAToeG0N1bHR1cmVUaG91c2FuZHNQbGFjZWhvbGRlcgUBLB4WQ3VsdHVyZURhdGVQbGFjZWhvbGRlcgUBLx4ZQ3VsdHVyZURlY2ltYWxQbGFjZWhvbGRlcgUBLh4OQ3VsdHVyZURhdGVGTVQFA01EWR4WQ3VsdHVyZUFNUE1QbGFjZWhvbGRlcgUFQU07UE1kAgQPD2QWLh4OVG9vbHRpcE1lc3NhZ2VlHhNNYXhpbXVtVmFsdWVNZXNzYWdlZR4TTWluaW11bVZhbHVlTWVzc2FnZQUeRGF0ZSBtdXN0IGJlIGFmdGVyIDAxLzAxLzE3NTUuHgpWYWxpZEVtcHR5BQR0cnVlHgdDZW50dXJ5BQEwHhhDbGllbnRWYWxpZGF0aW9uRnVuY3Rpb25lHhBsYXN0TWFza1Bvc2l0aW9uBQIxMR4RRmlyc3RNYXNrUG9zaXRpb24FATAeDE1heGltdW1WYWx1ZWUeCkRhdGVGb3JtYXQFA01EWR4MSXNNYXNrZWRFZGl0BQR0cnVlHgxNaW5pbXVtVmFsdWUFCjAxLzAxLzE3NTUeE0ludmFsaWRWYWx1ZU1lc3NhZ2UFE0VudGVyIGFzIE1NL2RkL3l5eXkeD1RhcmdldFZhbGlkYXRvcgUpY3RsMDBfUGxhY2VIb2xkZXJNYWluX0FjY2VsYUNhbGVuZGFyVGV4dDEeCENzc0ZvY3VzBQ9NYXNrZWRFZGl0Rm9jdXMeFEludmFsaWRWYWx1ZUNzc0NsYXNzBQ9NYXNrZWRFZGl0RXJyb3IeC0lzSGlqcmlEYXRlBQVmYWxzZR4PQ3NzQmx1ck5lZ2F0aXZlBRZNYXNrZWRFZGl0Qmx1ck5lZ2F0aXZlHhBDc3NGb2N1c05lZ2F0aXZlBRdNYXNrZWRFZGl0Rm9jdXNOZWdhdGl2ZR4RRW1"
		"wdHlWYWx1ZU1lc3NhZ2VlHgxJbml0aWFsVmFsdWVlHhRWYWxpZGF0aW9uRXhwcmVzc2lvbmUeDURhdGVTZXBhcmF0b3IFAS9kAgEPZBYKZg9kFgJmDxYCHgV0aXRsZQUHTG9ja2VkIGQCAQ9kFgJmDxYCHywFB09uIEhvbGRkAgIPZBYCZg8WAh8sBQZOb3RpY2VkAgMPZBYCZg8WAh8sBQhSZXF1aXJlZGQCBA9kFgQCAQ9kFgICBQ9kFgJmD2QWAgIBDzwrABECARAWABYAFgAMFCsAAGQCAw9kFgICBQ9kFgJmD2QWAgIDDzwrABEDAA8WAh4OU2hvd0V4cG9ydExpbmtoZAEQFgAWABYADBQrAABkAgIPDxYCHghzdGVwTGlzdDLHJwABAAAA/////wEAAAAAAAAABAEAAAD5AVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkRpY3Rpb25hcnlgMltbU3lzdGVtLkludDMyLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldLFtBY2NlbGEuV2ViLkNvbnRyb2xzLkJyZWFkQ3J1bXBJbmZvLCBBY2NlbGEuV2ViLkNvbnRyb2xzLCBWZXJzaW9uPTkuMi4wLjIxNzM4LCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPW51bGxdXQQAAAAHVmVyc2lvbghDb21wYXJlcghIYXNoU2l6ZQ1LZXlWYWx1ZVBhaXJzAAMAAwiRAVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkdlbmVyaWNFcXVhbGl0eUNvbXBhcmVyYDFbW1N5c3RlbS5JbnQzMiwgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XV0I/"
		"QFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5LZXlWYWx1ZVBhaXJgMltbU3lzdGVtLkludDMyLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldLFtBY2NlbGEuV2ViLkNvbnRyb2xzLkJyZWFkQ3J1bXBJbmZvLCBBY2NlbGEuV2ViLkNvbnRyb2xzLCBWZXJzaW9uPTkuMi4wLjIxNzM4LCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPW51bGxdXVtdBwAAAAkCAAAABwAAAAkDAAAABAIAAACRAVN5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkdlbmVyaWNFcXVhbGl0eUNvbXBhcmVyYDFbW1N5c3RlbS5JbnQzMiwgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XV0AAAAABwMAAAAAAQAAAAcAAAAD+wFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5LZXlWYWx1ZVBhaXJgMltbU3lzdGVtLkludDMyLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldLFtBY2NlbGEuV2ViLkNvbnRyb2xzLkJyZWFkQ3J1bXBJbmZvLCBBY2NlbGEuV2ViLkNvbnRyb2xzLCBWZXJzaW9uPTkuMi4wLjIxNzM4LCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPW51bGxdXQwFAAAATkFjY2VsYS5XZWIuQ29udHJvbHMsIFZlcnNpb249OS4yLjAuMjE3MzgsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGl"
		"jS2V5VG9rZW49bnVsbAT8////+wFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5LZXlWYWx1ZVBhaXJgMltbU3lzdGVtLkludDMyLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldLFtBY2NlbGEuV2ViLkNvbnRyb2xzLkJyZWFkQ3J1bXBJbmZvLCBBY2NlbGEuV2ViLkNvbnRyb2xzLCBWZXJzaW9uPTkuMi4wLjIxNzM4LCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPW51bGxdXQIAAAADa2V5BXZhbHVlAAQIIkFjY2VsYS5XZWIuQ29udHJvbHMuQnJlYWRDcnVtcEluZm8FAAAAAQAAAAkGAAAAAfn////8////AgAAAAkIAAAAAff////8////AwAAAAkKAAAAAfX////8////BAAAAAkMAAAAAfP////8////BQAAAAkOAAAAAfH////8////BgAAAAkQAAAAAe/////8////BwAAAAkSAAAABQYAAAAiQWNjZWxhLldlYi5Db250cm9scy5CcmVhZENydW1wSW5mbwgAAAAHX2VuYWJsZRg8Q2FwTmFtZT5rX19CYWNraW5nRmllbGQaPFBhZ2V0aXRsZT5rX19CYWNraW5nRmllbGQaPFN0ZXBJbmRleD5rX19CYWNraW5nRmllbGQfPFN0ZXBJbmRleFRpdGxlPmtfX0JhY2tpbmdGaWVsZBY8VGl0bGU+a19fQmFja2luZ0ZpZWxkFDxVcmw+a19fQmFja2luZ0ZpZWxkITxQYWdlSW5zdHJ1Y3Rpb25zPmtfX0JhY2tpbmdGaWVsZAABAQABAQEDAQh/U3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdGAxW1tTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00L"
		"jAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQUAAAABBhMAAAAKTWFqb3IgUGxhdAYUAAAAPVByb3BlcnR5fEFkZGl0aW9uYWwgUGFyY2VsKHMpfFNlYXJjaCBSZXN1bHR8U2VsZWN0ZWQgUGFyY2Vsc3wBAAAABhUAAAABMQYWAAAAFFByb3BlcnR5IEluZm9ybWF0aW9uBhcAAADcAS9UZXN0Q2l0aXplbkFjY2Vzcy9DYXAvQ2FwRWRpdC5hc3B4P3Nzbj0xJmN1cnJlbnRQYWdlPTAmaXNGcm9tU2hvcHBpbmdDYXJ0PSZjdXJyZW50U3RlcD0maXNGcm9tQ29uZmlybVBhZ2U9LE4sTixOLE4sTixOLE4sTiZjb25maXJtU3RlcE51bWJlcj0wJnN0ZXBOdW1iZXI9MiZwYWdlTnVtYmVyPTEmaXNSZW5ld2FsPU4mTW9kdWxlPUxhbmREZXZlbG9wbWVudCZhZ2VuY3lDb2RlPUNPU0EJGAAAAAEIAAAABgAAAAEJEwAAAAYaAAAAE0FwcGxpY2FudHxDb250YWN0c3wCAAAABhsAAAABMgYcAAAAE0NvbnRhY3QgSW5mb3JtYXRpb24GHQAAAN0BL1Rlc3RDaXRpemVuQWNjZXNzL0NhcC9DYXBFZGl0LmFzcHg/c3NuPTEmY3VycmVudFBhZ2U9MCZpc0Zyb21TaG9wcGluZ0NhcnQ9JmN1cnJlbnRTdGVwPTEmaXNGcm9tQ29uZmlybVBhZ2U9LE4sTixOLE4sTixOLE4sTiZjb25maXJtU3RlcE51bWJlcj0wJnN0ZXBOdW1iZXI9MyZwYWdlTnVtYmVyPTEmaXNSZW5ld2FsPU4mTW9kdWxlPUxhbmREZXZlbG9wbWVudCZhZ2VuY3lDb2RlPUNPU0EJHgAAAAEKAAAABgAAAAEJEwAAAAYgAAAAPUFwcGxpY2F0aW9uIERldGFpbHxBcHB"
		"saWNhdGlvbiBEZXRhaWwgMnxBcHBsaWNhdGlvbiBEZXRhaWwgM3wDAAAABiEAAAABMwYiAAAAF0FwcGxpY2F0aW9uIEluZm9ybWF0aW9uBiMAAADdAS9UZXN0Q2l0aXplbkFjY2Vzcy9DYXAvQ2FwRWRpdC5hc3B4P3Nzbj0xJmN1cnJlbnRQYWdlPTAmaXNGcm9tU2hvcHBpbmdDYXJ0PSZjdXJyZW50U3RlcD0yJmlzRnJvbUNvbmZpcm1QYWdlPSxOLE4sTixOLE4sTixOLE4mY29uZmlybVN0ZXBOdW1iZXI9MCZzdGVwTnVtYmVyPTQmcGFnZU51bWJlcj0xJmlzUmVuZXdhbD1OJk1vZHVsZT1MYW5kRGV2ZWxvcG1lbnQmYWdlbmN5Q29kZT1DT1NBCSQAAAABDAAAAAYAAAABCRMAAAAGJgAAAApEb2N1bWVudHN8BAAAAAYnAAAAATQGKAAAABREb2N1bWVudCBJbmZvcm1hdGlvbgYpAAAA3QEvVGVzdENpdGl6ZW5BY2Nlc3MvQ2FwL0NhcEVkaXQuYXNweD9zc249MSZjdXJyZW50UGFnZT0wJmlzRnJvbVNob3BwaW5nQ2FydD0mY3VycmVudFN0ZXA9MyZpc0Zyb21Db25maXJtUGFnZT0sTixOLE4sTixOLE4sTixOJmNvbmZpcm1TdGVwTnVtYmVyPTAmc3RlcE51bWJlcj01JnBhZ2VOdW1iZXI9MSZpc1JlbmV3YWw9TiZNb2R1bGU9TGFuZERldmVsb3BtZW50JmFnZW5jeUNvZGU9Q09TQQkqAAAAAQ4AAAAGAAAAAQkTAAAACgUAAAAGLAAAAAE1Bi0AAAAGUmV2aWV3Bi4AAAAACgEQAAAABgAAAAEJEwAAAAoGAAAABjAAAAABNgYxAAAACFBheSBGZWVzCS4AAAAKARIAAAAGAAAAAQkTAAAACgcAAAAGNAAAAAE3BjUAAAAPUmVjb3JkIElzc3VhbmNlCS4AAAAKBBgAAAB/U"
		"3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuTGlzdGAxW1tTeXN0ZW0uU3RyaW5nLCBtc2NvcmxpYiwgVmVyc2lvbj00LjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODldXQMAAAAGX2l0ZW1zBV9zaXplCF92ZXJzaW9uBgAACAgJNwAAAAQAAAAEAAAAAR4AAAAYAAAACTgAAAACAAAAAgAAAAEkAAAAGAAAAAk5AAAAAwAAAAMAAAABKgAAABgAAAAJOgAAAAEAAAABAAAAETcAAAAEAAAACgY7AAAArQM8ZGl2IGNsYXNzPSJBQ0FfTGdCdXR0b24gQUNBX0xnQnV0dG9uX0ZvbnRTaXplIj48YSB0aXRsZT0iTm8gQWRkaXRpb25hbCBQYXJjZWxzIiBpZD0iYnRuc2tpcGFkZGl0aW5hbHBhcmNlbCIgaHJlZj0iL1Rlc3RDaXRpemVuQWNjZXNzL0NhcC9DYXBFZGl0LmFzcHg/c3RlcE51bWJlcj0zJmFtcDtwYWdlTnVtYmVyPTEmYW1wO2N1cnJlbnRTdGVwPTEmYW1wO2N1cnJlbnRQYWdlPTAmYW1wO01vZHVsZT1MYW5kRGV2ZWxvcG1lbnQmYW1wO2lzUmVuZXdhbD1OJmFtcDtpc0Zyb21TaG9wcGluZ0NhcnQ9JmFtcDtpc0Zyb21Db25maXJtUGFnZT0sTixOLE4sTiZhbXA7Y29uZmlybVN0ZXBOdW1iZXI9MCZhbXA7aXNGcm9tQ29uZmlybVBhZ2U9TiZhbXA7YWdlbmN5Q29kZT1DT1NBIiA+PHNwYW4+Tm8gQWRkaXRpb25hbCBQYXJjZWxzPC9zcGFuPjwvYT48L2Rpdj4GPAAAAIgDPGRpdiBjbGFzcz0iQUNBX0xnQnV0dG9uIEFDQV9MZ0J1dHRvbl9Gb250U2l6ZSI+PGEgdGl0bGU9IkFkZCBNb3JlIFBhcmNlbHMiIGl"
		"kPSJidG5hZGRtb3JlcGFyY2VsIiBocmVmPSIvVGVzdENpdGl6ZW5BY2Nlc3MvQ2FwL0NhcEVkaXQuYXNweD9zdGVwTnVtYmVyPTImYW1wO3BhZ2VOdW1iZXI9MiZhbXA7Y3VycmVudFN0ZXA9MCZhbXA7Y3VycmVudFBhZ2U9MSZhbXA7TW9kdWxlPUxhbmREZXZlbG9wbWVudCZhbXA7aXNSZW5ld2FsPU4mYW1wO2lzRnJvbVNob3BwaW5nQ2FydD0mYW1wO2lzRnJvbUNvbmZpcm1QYWdlPSZhbXA7Y29uZmlybVN0ZXBOdW1iZXI9MCZhbXA7aXNGcm9tQ29uZmlybVBhZ2U9TiZhbXA7YWdlbmN5Q29kZT1DT1NBIj48c3Bhbj5CYWNrPC9zcGFuPjwvYT48L2Rpdj4GPQAAAJQDPGRpdiBjbGFzcz0iQUNBX0xnQnV0dG9uIEFDQV9MZ0J1dHRvbl9Gb250U2l6ZSI+PGEgdGl0bGU9IkFkZCBNb3JlIFBhcmNlbHMiIGlkPSJidG5hZGRtb3JlcGFyY2VsIiBocmVmPSIvVGVzdENpdGl6ZW5BY2Nlc3MvQ2FwL0NhcEVkaXQuYXNweD9zdGVwTnVtYmVyPTImYW1wO3BhZ2VOdW1iZXI9MiZhbXA7Y3VycmVudFN0ZXA9MCZhbXA7Y3VycmVudFBhZ2U9MSZhbXA7TW9kdWxlPUxhbmREZXZlbG9wbWVudCZhbXA7aXNSZW5ld2FsPU4mYW1wO2lzRnJvbVNob3BwaW5nQ2FydD0mYW1wO2lzRnJvbUNvbmZpcm1QYWdlPSZhbXA7Y29uZmlybVN0ZXBOdW1iZXI9MCZhbXA7aXNGcm9tQ29uZmlybVBhZ2U9TiZhbXA7YWdlbmN5Q29kZT1DT1NBIj48c3Bhbj5BZGQgTW9yZSBQYXJjZWxzPC9zcGFuPjwvYT48L2Rpdj4ROAAAAAQAAAANBBE5AAAABAAAAA0EEToAAAAEAAAADQQLZGQCAw9kF"
		"gJmD2QWAgIFD2QWAgIBD2QWAgIBDxAPFgQfCQUsYWNhX2NoZWNrYm94IGFjYV9jaGVja2JveF9mb250c2l6ZSBhY2FfcmFkaW8fDAICFgIeBHJvbGUFDHByZXNlbnRhdGlvbmQWAGQCBw9kFgZmDw8WBB8BBQEzHwdlZGQCAQ8WAh8CaBYCAgMPDxYCHwJoZGQCAw8WAh8CZxYCAgMPFgQeBWNsYXNzBQ5Ob3RTaG93TG9hZGluZx8sBZYBU2F2ZSB5b3VyIGNoYW5nZXMgYW5kIHJlc3VtZSBsYXRlci4gV2hlbiB5b3UgcmV0dXJuIHlvdSB3aWxsIHN0YXJ0IG9uIHRoZSBmaXJzdCBwYWdlIG9mIHRoZSBhcHBsaWNhdGlvbiB0byBlbnN1cmUgeW91IGhhdmUgY29tcGxldGVkIGFsbCByZXF1aXJlbWVudHMuZAILDw9kFgIeCW9ua2V5ZG93bgU+T3ZlcnJpZGVUYWJLZXkoZXZlbnQsIHRydWUsICdjdGwwMF9QbGFjZUhvbGRlck1haW5fYnRuQ2FuY2VsJylkAgwPD2QWAh8xBTtPdmVycmlkZVRhYktleShldmVudCwgZmFsc2UsICdjdGwwMF9QbGFjZUhvbGRlck1haW5fYnRuT0snKWQCBQ8PFgIfAmhkZBgMBTxjdGwwMCRQbGFjZUhvbGRlck1haW4kY2FwQ29uZGl0aW9ucyRnZHZHZW5lcmFsQ29uZGl0aW9uc0xpc3QPZ2QFUGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxNUNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDEwJGdkdkFTSVRhYmxlDzwrAAwBCGZkBVBjdGwwMCRQbGFjZUhvbGRlck1haW4kQXBwU3BlY1RhYmxlMTVDRTIwOEZFZGl0JHJwdEFTSVRhYmxlTGlzdCRjdGwwMiRnZHZBU0lUYWJsZQ88KwAMAQhmZAVQY3RsMDAkUGxhY2V"
		"Ib2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMDQkZ2R2QVNJVGFibGUPPCsADAEIZmQFUGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxNUNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDA4JGdkdkFTSVRhYmxlDzwrAAwBCGZkBVBjdGwwMCRQbGFjZUhvbGRlck1haW4kQXBwU3BlY1RhYmxlMTVDRTIwOEZFZGl0JHJwdEFTSVRhYmxlTGlzdCRjdGwxNCRnZHZBU0lUYWJsZQ88KwAMAQhmZAVQY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMTYkZ2R2QVNJVGFibGUPPCsADAEIZmQFP2N0bDAwJFBsYWNlSG9sZGVyTWFpbiRjYXBDb25kaXRpb25zJGdkdkNvbmRpdGlvbnNPZkFwcHJvdmFsTGlzdA9nZAVQY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMDAkZ2R2QVNJVGFibGUPPCsADAEIAgFkBVBjdGwwMCRQbGFjZUhvbGRlck1haW4kQXBwU3BlY1RhYmxlMTVDRTIwOEZFZGl0JHJwdEFTSVRhYmxlTGlzdCRjdGwwNiRnZHZBU0lUYWJsZQ88KwAMAQhmZAUeX19Db250cm9sc1JlcXVpcmVQb3N0QmFja0tleV9fFgEFW2N0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxNUNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDAwJGdkdkFTSVRhYmxlJGN0bDAyJENCXzAFUGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxN"
		"UNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDEyJGdkdkFTSVRhYmxlDzwrAAwBCGZk8lWekuTat2ucWdzq3g5FvKg8XR78LvDr1bnw7DT5xKc=", ENDITEM,
		"Name=__VIEWSTATEGENERATOR", "Value={ViewStateGen_3}", ENDITEM,
		"Name=ACA_CS_FIELD", "Value={ACA_CS_FIELD}", ENDITEM,
		"Name=__ASYNCPOST", "Value=true", ENDITEM,
		LAST);

	/* continue application */

	web_submit_data("CapEdit.aspx_10",
		"Action=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=2&currentStep=2&currentPage=1&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=%2cN%2cN%2cN%2cN%2cN%2cN%2cN&isFromConfirmPage=N&confirmStepNumber=0&agencyCode=COSA",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=2&currentStep=2&currentPage=1&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=,N,N,N,N,N,N,N&confirmStepNumber=0&isFromConfirmPage=N&agencyCode=COSA",
		"Snapshot=t81.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=txtSearchCondition", "Value=Search...", ENDITEM,
		"Name=ctl00$HeaderNavigation$hdnShoppingCartItemNumber", "Value=", ENDITEM,
		"Name=ctl00$HeaderNavigation$hdnShowReportLink", "Value=Y", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AccelaCalendarText1", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AccelaCalendarText1_ext_ClientState", "Value=", ENDITEM,
		"Name=component", "Value=AppSpecTable15CE208FEdit", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl00$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl02$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl04$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl06$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl08$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl10$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl12$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl14$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$PlaceHolderMain$AppSpecTable15CE208FEdit$rptASITableList$ctl16$gdvASITable$hfSaveSelectedItems", "Value=", ENDITEM,
		"Name=ctl00$HDExpressionParam", "Value=", ENDITEM,
		"Name=__LASTFOCUS_ID", "Value=", ENDITEM,
		"Name=__EVENTTARGET", "Value=ctl00$PlaceHolderMain$actionBarBottom$btnContinue", ENDITEM,
		"Name=__EVENTARGUMENT", "Value=", ENDITEM,
		"Name=__VIEWSTATE", "Value=/wEPDwULLTIxMTE2NDc3NDkPFgIeDEN1cnJlbnRDYXBJRDKvAgABAAAA/////wEAAAAAAAAADAIAAABLQWNjZWxhLkFDQS5Nb2RlbCwgVmVyc2lvbj05LjIuMC4yMTczNCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWxsBQEAAAAgQWNjZWxhLkFDQS5XU1Byb3h5LkNhcElETW9kZWw0V1MGAAAADWN1c3RvbUlERmllbGQIaWQxRmllbGQIaWQyRmllbGQIaWQzRmllbGQYc2VydmljZVByb3ZpZGVyQ29kZUZpZWxkD3RyYWNraW5nSURGaWVsZAEBAQEBAAkCAAAABgMAAAAMMThUTVAtMDA1OTM5BgQAAAAFMThFU1QGBQAAAAUwMDAwMAYGAAAABTA2MDM4BgcAAAAEQ09TQRLqlQ8AAAAACxYCZg9kFgYCAg8PFgQeCUFjY2Vzc0tleQUBMB4HVmlzaWJsZWhkZAIDDw8WBB8BBQExHghUYWJJbmRleAH//2RkAgQPZBYGAgIPZBYCAgIPZBYEZg8WAh8CZxYKZg8WAh4EaHJlZgUeL1Rlc3RDaXRpemVuQWNjZXNzL0xvZ291dC5hc3B4ZAIHDw9kFgIeBXN0eWxlBQ1kaXNwbGF5Om5vbmU7ZAIJDxYCHwJoFgICAQ8PFgIfAmhkZAIKDw8WBB4JSXNFbmNvZGVkaB4EVGV4dAUPQ29sbGVjdGlvbnMgKDApZGQCDg8PFgYeB1Rvb2xUaXAFDEFtaXQgQWdyYXdhbB8GaB8HBQxBbWl0IEFncmF3YWxkZAIBD2QWBAIDDw9kFgIfBQUNZGlzcGxheTpub25lO2QCBQ8WAh8EZGQCAw9kFg5mDw8WCB4IQ3NzQ2xhc3MFMEFDQV9OU2hvdCBtYXNrZWRmaWVsZHMgbWFza2VkZmllbGRzIG1hc2tlZGZpZWxkcx4FVGV4dDJlHglNYXhMZW5ndGhmHgRfIVNCAgJkFgQCA"
		"w8WEB4gQ3VsdHVyZUN1cnJlbmN5U3ltYm9sUGxhY2Vob2xkZXIFASQeB0N1bHR1cmUFBWVuLVVTHhZDdWx0dXJlVGltZVBsYWNlaG9sZGVyBQE6HhtDdWx0dXJlVGhvdXNhbmRzUGxhY2Vob2xkZXIFASweFkN1bHR1cmVEYXRlUGxhY2Vob2xkZXIFAS8eGUN1bHR1cmVEZWNpbWFsUGxhY2Vob2xkZXIFAS4eDkN1bHR1cmVEYXRlRk1UBQNNRFkeFkN1bHR1cmVBTVBNUGxhY2Vob2xkZXIFBUFNO1BNZAIEDw9kFi4eDlRvb2x0aXBNZXNzYWdlZR4TTWF4aW11bVZhbHVlTWVzc2FnZWUeC0lzSGlqcmlEYXRlBQVmYWxzZR4KVmFsaWRFbXB0eQUEdHJ1ZR4HQ2VudHVyeQUBMB4YQ2xpZW50VmFsaWRhdGlvbkZ1bmN0aW9uZR4QbGFzdE1hc2tQb3NpdGlvbgUCMTEeEUZpcnN0TWFza1Bvc2l0aW9uBQEwHgxNYXhpbXVtVmFsdWVlHgpEYXRlRm9ybWF0BQNNRFkeFFZhbGlkYXRpb25FeHByZXNzaW9uZR4MSXNNYXNrZWRFZGl0BQR0cnVlHgxNaW5pbXVtVmFsdWUFCjAxLzAxLzE3NTUeE0ludmFsaWRWYWx1ZU1lc3NhZ2UFE0VudGVyIGFzIE1NL2RkL3l5eXkeD1RhcmdldFZhbGlkYXRvcgUpY3RsMDBfUGxhY2VIb2xkZXJNYWluX0FjY2VsYUNhbGVuZGFyVGV4dDEeCENzc0ZvY3VzBQ9NYXNrZWRFZGl0Rm9jdXMeFEludmFsaWRWYWx1ZUNzc0NsYXNzBQ9NYXNrZWRFZGl0RXJyb3IeD0Nzc0JsdXJOZWdhdGl2ZQUWTWFza2VkRWRpdEJsdXJOZWdhdGl2ZR4QQ3NzRm9jdXNOZWdhdGl2ZQUXTWFza2VkRWRpdEZvY3VzTmVnYXRpdmUeEUVtcHR5VmFsdWVNZXNzYWdlZR4"
		"MSW5pdGlhbFZhbHVlZR4TTWluaW11bVZhbHVlTWVzc2FnZQUeRGF0ZSBtdXN0IGJlIGFmdGVyIDAxLzAxLzE3NTUuHg1EYXRlU2VwYXJhdG9yBQEvZAIBD2QWCmYPZBYCZg8WAh4FdGl0bGUFB0xvY2tlZCBkAgEPZBYCZg8WAh8sBQdPbiBIb2xkZAICD2QWAmYPFgIfLAUGTm90aWNlZAIDD2QWAmYPFgIfLAUIUmVxdWlyZWRkAgQPZBYEAgEPZBYCAgUPZBYCZg9kFgICAQ88KwARAgEQFgAWABYADBQrAABkAgMPZBYCAgUPZBYCZg9kFgICAw88KwARAwAPFgIeDlNob3dFeHBvcnRMaW5raGQBEBYAFgAWAAwUKwAAZAICDw8WAh4Ic3RlcExpc3QyxycAAQAAAP////8BAAAAAAAAAAQBAAAA+QFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5EaWN0aW9uYXJ5YDJbW1N5c3RlbS5JbnQzMiwgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XSxbQWNjZWxhLldlYi5Db250cm9scy5CcmVhZENydW1wSW5mbywgQWNjZWxhLldlYi5Db250cm9scywgVmVyc2lvbj05LjIuMC4yMTczOCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWxsXV0EAAAAB1ZlcnNpb24IQ29tcGFyZXIISGFzaFNpemUNS2V5VmFsdWVQYWlycwADAAMIkQFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5HZW5lcmljRXF1YWxpdHlDb21wYXJlcmAxW1tTeXN0ZW0uSW50MzIsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjN"
		"TYxOTM0ZTA4OV1dCP0BU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuS2V5VmFsdWVQYWlyYDJbW1N5c3RlbS5JbnQzMiwgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XSxbQWNjZWxhLldlYi5Db250cm9scy5CcmVhZENydW1wSW5mbywgQWNjZWxhLldlYi5Db250cm9scywgVmVyc2lvbj05LjIuMC4yMTczOCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWxsXV1bXQcAAAAJAgAAAAcAAAAJAwAAAAQCAAAAkQFTeXN0ZW0uQ29sbGVjdGlvbnMuR2VuZXJpYy5HZW5lcmljRXF1YWxpdHlDb21wYXJlcmAxW1tTeXN0ZW0uSW50MzIsIG1zY29ybGliLCBWZXJzaW9uPTQuMC4wLjAsIEN1bHR1cmU9bmV1dHJhbCwgUHVibGljS2V5VG9rZW49Yjc3YTVjNTYxOTM0ZTA4OV1dAAAAAAcDAAAAAAEAAAAHAAAAA/sBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuS2V5VmFsdWVQYWlyYDJbW1N5c3RlbS5JbnQzMiwgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XSxbQWNjZWxhLldlYi5Db250cm9scy5CcmVhZENydW1wSW5mbywgQWNjZWxhLldlYi5Db250cm9scywgVmVyc2lvbj05LjIuMC4yMTczOCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWxsXV0MBQAAAE5BY2NlbGEuV2ViLkNvbnRyb2xzLCBWZXJzaW9uPTkuMi4wLjIxNzM4LCBDdWx0dXJlPW5"
		"ldXRyYWwsIFB1YmxpY0tleVRva2VuPW51bGwE/P////sBU3lzdGVtLkNvbGxlY3Rpb25zLkdlbmVyaWMuS2V5VmFsdWVQYWlyYDJbW1N5c3RlbS5JbnQzMiwgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XSxbQWNjZWxhLldlYi5Db250cm9scy5CcmVhZENydW1wSW5mbywgQWNjZWxhLldlYi5Db250cm9scywgVmVyc2lvbj05LjIuMC4yMTczOCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1udWxsXV0CAAAAA2tleQV2YWx1ZQAECCJBY2NlbGEuV2ViLkNvbnRyb2xzLkJyZWFkQ3J1bXBJbmZvBQAAAAEAAAAJBgAAAAH5/////P///wIAAAAJCAAAAAH3/////P///wMAAAAJCgAAAAH1/////P///wQAAAAJDAAAAAHz/////P///wUAAAAJDgAAAAHx/////P///wYAAAAJEAAAAAHv/////P///wcAAAAJEgAAAAUGAAAAIkFjY2VsYS5XZWIuQ29udHJvbHMuQnJlYWRDcnVtcEluZm8IAAAAB19lbmFibGUYPENhcE5hbWU+a19fQmFja2luZ0ZpZWxkGjxQYWdldGl0bGU+a19fQmFja2luZ0ZpZWxkGjxTdGVwSW5kZXg+a19fQmFja2luZ0ZpZWxkHzxTdGVwSW5kZXhUaXRsZT5rX19CYWNraW5nRmllbGQWPFRpdGxlPmtfX0JhY2tpbmdGaWVsZBQ8VXJsPmtfX0JhY2tpbmdGaWVsZCE8UGFnZUluc3RydWN0aW9ucz5rX19CYWNraW5nRmllbGQAAQEAAQEBAwEIf1N5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkxpc3RgMVtbU3lzdGVtLlN0cmluZywgbXNjb3Jsa"
		"WIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XV0FAAAAAQYTAAAACk1ham9yIFBsYXQGFAAAAD1Qcm9wZXJ0eXxBZGRpdGlvbmFsIFBhcmNlbChzKXxTZWFyY2ggUmVzdWx0fFNlbGVjdGVkIFBhcmNlbHN8AQAAAAYVAAAAATEGFgAAABRQcm9wZXJ0eSBJbmZvcm1hdGlvbgYXAAAA3AEvVGVzdENpdGl6ZW5BY2Nlc3MvQ2FwL0NhcEVkaXQuYXNweD9zc249MSZjdXJyZW50UGFnZT0wJmlzRnJvbVNob3BwaW5nQ2FydD0mY3VycmVudFN0ZXA9JmlzRnJvbUNvbmZpcm1QYWdlPSxOLE4sTixOLE4sTixOLE4mY29uZmlybVN0ZXBOdW1iZXI9MCZzdGVwTnVtYmVyPTImcGFnZU51bWJlcj0xJmlzUmVuZXdhbD1OJk1vZHVsZT1MYW5kRGV2ZWxvcG1lbnQmYWdlbmN5Q29kZT1DT1NBCRgAAAABCAAAAAYAAAABCRMAAAAGGgAAABNBcHBsaWNhbnR8Q29udGFjdHN8AgAAAAYbAAAAATIGHAAAABNDb250YWN0IEluZm9ybWF0aW9uBh0AAADdAS9UZXN0Q2l0aXplbkFjY2Vzcy9DYXAvQ2FwRWRpdC5hc3B4P3Nzbj0xJmN1cnJlbnRQYWdlPTAmaXNGcm9tU2hvcHBpbmdDYXJ0PSZjdXJyZW50U3RlcD0xJmlzRnJvbUNvbmZpcm1QYWdlPSxOLE4sTixOLE4sTixOLE4mY29uZmlybVN0ZXBOdW1iZXI9MCZzdGVwTnVtYmVyPTMmcGFnZU51bWJlcj0xJmlzUmVuZXdhbD1OJk1vZHVsZT1MYW5kRGV2ZWxvcG1lbnQmYWdlbmN5Q29kZT1DT1NBCR4AAAABCgAAAAYAAAABCRMAAAAGIAAAAD1BcHBsaWNhdGl"
		"vbiBEZXRhaWx8QXBwbGljYXRpb24gRGV0YWlsIDJ8QXBwbGljYXRpb24gRGV0YWlsIDN8AwAAAAYhAAAAATMGIgAAABdBcHBsaWNhdGlvbiBJbmZvcm1hdGlvbgYjAAAA3QEvVGVzdENpdGl6ZW5BY2Nlc3MvQ2FwL0NhcEVkaXQuYXNweD9zc249MSZjdXJyZW50UGFnZT0wJmlzRnJvbVNob3BwaW5nQ2FydD0mY3VycmVudFN0ZXA9MiZpc0Zyb21Db25maXJtUGFnZT0sTixOLE4sTixOLE4sTixOJmNvbmZpcm1TdGVwTnVtYmVyPTAmc3RlcE51bWJlcj00JnBhZ2VOdW1iZXI9MSZpc1JlbmV3YWw9TiZNb2R1bGU9TGFuZERldmVsb3BtZW50JmFnZW5jeUNvZGU9Q09TQQkkAAAAAQwAAAAGAAAAAQkTAAAABiYAAAAKRG9jdW1lbnRzfAQAAAAGJwAAAAE0BigAAAAURG9jdW1lbnQgSW5mb3JtYXRpb24GKQAAAN0BL1Rlc3RDaXRpemVuQWNjZXNzL0NhcC9DYXBFZGl0LmFzcHg/c3NuPTEmY3VycmVudFBhZ2U9MCZpc0Zyb21TaG9wcGluZ0NhcnQ9JmN1cnJlbnRTdGVwPTMmaXNGcm9tQ29uZmlybVBhZ2U9LE4sTixOLE4sTixOLE4sTiZjb25maXJtU3RlcE51bWJlcj0wJnN0ZXBOdW1iZXI9NSZwYWdlTnVtYmVyPTEmaXNSZW5ld2FsPU4mTW9kdWxlPUxhbmREZXZlbG9wbWVudCZhZ2VuY3lDb2RlPUNPU0EJKgAAAAEOAAAABgAAAAEJEwAAAAoFAAAABiwAAAABNQYtAAAABlJldmlldwYuAAAAAAoBEAAAAAYAAAABCRMAAAAKBgAAAAYwAAAAATYGMQAAAAhQYXkgRmVlcwkuAAAACgESAAAABgAAAAEJEwAAAAoHAAAABjQAAAABNwY1AAAAD1JlY29yZCBJc3N1YW5jZ"
		"QkuAAAACgQYAAAAf1N5c3RlbS5Db2xsZWN0aW9ucy5HZW5lcmljLkxpc3RgMVtbU3lzdGVtLlN0cmluZywgbXNjb3JsaWIsIFZlcnNpb249NC4wLjAuMCwgQ3VsdHVyZT1uZXV0cmFsLCBQdWJsaWNLZXlUb2tlbj1iNzdhNWM1NjE5MzRlMDg5XV0DAAAABl9pdGVtcwVfc2l6ZQhfdmVyc2lvbgYAAAgICTcAAAAEAAAABAAAAAEeAAAAGAAAAAk4AAAAAgAAAAIAAAABJAAAABgAAAAJOQAAAAMAAAADAAAAASoAAAAYAAAACToAAAABAAAAAQAAABE3AAAABAAAAAoGOwAAAK0DPGRpdiBjbGFzcz0iQUNBX0xnQnV0dG9uIEFDQV9MZ0J1dHRvbl9Gb250U2l6ZSI+PGEgdGl0bGU9Ik5vIEFkZGl0aW9uYWwgUGFyY2VscyIgaWQ9ImJ0bnNraXBhZGRpdGluYWxwYXJjZWwiIGhyZWY9Ii9UZXN0Q2l0aXplbkFjY2Vzcy9DYXAvQ2FwRWRpdC5hc3B4P3N0ZXBOdW1iZXI9MyZhbXA7cGFnZU51bWJlcj0xJmFtcDtjdXJyZW50U3RlcD0xJmFtcDtjdXJyZW50UGFnZT0wJmFtcDtNb2R1bGU9TGFuZERldmVsb3BtZW50JmFtcDtpc1JlbmV3YWw9TiZhbXA7aXNGcm9tU2hvcHBpbmdDYXJ0PSZhbXA7aXNGcm9tQ29uZmlybVBhZ2U9LE4sTixOLE4mYW1wO2NvbmZpcm1TdGVwTnVtYmVyPTAmYW1wO2lzRnJvbUNvbmZpcm1QYWdlPU4mYW1wO2FnZW5jeUNvZGU9Q09TQSIgPjxzcGFuPk5vIEFkZGl0aW9uYWwgUGFyY2Vsczwvc3Bhbj48L2E+PC9kaXY+BjwAAACIAzxkaXYgY2xhc3M9IkFDQV9MZ0J1dHRvbiBBQ0FfTGdCdXR0b25fRm9udFNpemUiPjxhIHRpdGxlPSJBZGQgTW9"
		"yZSBQYXJjZWxzIiBpZD0iYnRuYWRkbW9yZXBhcmNlbCIgaHJlZj0iL1Rlc3RDaXRpemVuQWNjZXNzL0NhcC9DYXBFZGl0LmFzcHg/c3RlcE51bWJlcj0yJmFtcDtwYWdlTnVtYmVyPTImYW1wO2N1cnJlbnRTdGVwPTAmYW1wO2N1cnJlbnRQYWdlPTEmYW1wO01vZHVsZT1MYW5kRGV2ZWxvcG1lbnQmYW1wO2lzUmVuZXdhbD1OJmFtcDtpc0Zyb21TaG9wcGluZ0NhcnQ9JmFtcDtpc0Zyb21Db25maXJtUGFnZT0mYW1wO2NvbmZpcm1TdGVwTnVtYmVyPTAmYW1wO2lzRnJvbUNvbmZpcm1QYWdlPU4mYW1wO2FnZW5jeUNvZGU9Q09TQSI+PHNwYW4+QmFjazwvc3Bhbj48L2E+PC9kaXY+Bj0AAACUAzxkaXYgY2xhc3M9IkFDQV9MZ0J1dHRvbiBBQ0FfTGdCdXR0b25fRm9udFNpemUiPjxhIHRpdGxlPSJBZGQgTW9yZSBQYXJjZWxzIiBpZD0iYnRuYWRkbW9yZXBhcmNlbCIgaHJlZj0iL1Rlc3RDaXRpemVuQWNjZXNzL0NhcC9DYXBFZGl0LmFzcHg/c3RlcE51bWJlcj0yJmFtcDtwYWdlTnVtYmVyPTImYW1wO2N1cnJlbnRTdGVwPTAmYW1wO2N1cnJlbnRQYWdlPTEmYW1wO01vZHVsZT1MYW5kRGV2ZWxvcG1lbnQmYW1wO2lzUmVuZXdhbD1OJmFtcDtpc0Zyb21TaG9wcGluZ0NhcnQ9JmFtcDtpc0Zyb21Db25maXJtUGFnZT0mYW1wO2NvbmZpcm1TdGVwTnVtYmVyPTAmYW1wO2lzRnJvbUNvbmZpcm1QYWdlPU4mYW1wO2FnZW5jeUNvZGU9Q09TQSI+PHNwYW4+QWRkIE1vcmUgUGFyY2Vsczwvc3Bhbj48L2E+PC9kaXY+ETgAAAAEAAAADQQROQAAAAQAAAANBBE6AAAAB"
		"AAAAA0EC2RkAgMPZBYCZg9kFgICBQ9kFgICAQ9kFgICAQ8QDxYEHwkFLGFjYV9jaGVja2JveCBhY2FfY2hlY2tib3hfZm9udHNpemUgYWNhX3JhZGlvHwwCAhYCHgRyb2xlBQxwcmVzZW50YXRpb25kFgBkAgcPZBYGZg8PFgQfAQUBMx8HZWRkAgEPFgIfAmgWAgIDDw8WAh8CaGRkAgMPFgIfAmcWAgIDDxYEHgVjbGFzcwUOTm90U2hvd0xvYWRpbmcfLAWWAVNhdmUgeW91ciBjaGFuZ2VzIGFuZCByZXN1bWUgbGF0ZXIuIFdoZW4geW91IHJldHVybiB5b3Ugd2lsbCBzdGFydCBvbiB0aGUgZmlyc3QgcGFnZSBvZiB0aGUgYXBwbGljYXRpb24gdG8gZW5zdXJlIHlvdSBoYXZlIGNvbXBsZXRlZCBhbGwgcmVxdWlyZW1lbnRzLmQCCw8PZBYCHglvbmtleWRvd24FPk92ZXJyaWRlVGFiS2V5KGV2ZW50LCB0cnVlLCAnY3RsMDBfUGxhY2VIb2xkZXJNYWluX2J0bkNhbmNlbCcpZAIMDw9kFgIfMQU7T3ZlcnJpZGVUYWJLZXkoZXZlbnQsIGZhbHNlLCAnY3RsMDBfUGxhY2VIb2xkZXJNYWluX2J0bk9LJylkAgUPDxYCHwJoZGQYDAU8Y3RsMDAkUGxhY2VIb2xkZXJNYWluJGNhcENvbmRpdGlvbnMkZ2R2R2VuZXJhbENvbmRpdGlvbnNMaXN0D2dkBVBjdGwwMCRQbGFjZUhvbGRlck1haW4kQXBwU3BlY1RhYmxlMTVDRTIwOEZFZGl0JHJwdEFTSVRhYmxlTGlzdCRjdGwwMiRnZHZBU0lUYWJsZQ88KwAMAQhmZAVQY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMTQkZ2R2QVNJVGFibGUPPCsADAEIZmQ"
		"FUGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxNUNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDA4JGdkdkFTSVRhYmxlDzwrAAwBCGZkBVBjdGwwMCRQbGFjZUhvbGRlck1haW4kQXBwU3BlY1RhYmxlMTVDRTIwOEZFZGl0JHJwdEFTSVRhYmxlTGlzdCRjdGwxMCRnZHZBU0lUYWJsZQ88KwAMAQhmZAVQY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMTYkZ2R2QVNJVGFibGUPPCsADAEIAgFkBT9jdGwwMCRQbGFjZUhvbGRlck1haW4kY2FwQ29uZGl0aW9ucyRnZHZDb25kaXRpb25zT2ZBcHByb3ZhbExpc3QPZ2QFUGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxNUNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDAwJGdkdkFTSVRhYmxlDzwrAAwBCAIBZAVQY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMDYkZ2R2QVNJVGFibGUPPCsADAEIZmQFUGN0bDAwJFBsYWNlSG9sZGVyTWFpbiRBcHBTcGVjVGFibGUxNUNFMjA4RkVkaXQkcnB0QVNJVGFibGVMaXN0JGN0bDA0JGdkdkFTSVRhYmxlDzwrAAwBCGZkBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WAgVbY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMDAkZ2R2QVNJVGFibGUkY3RsMDIkQ0JfMAVbY3RsMDAkUGxhY2VIb2xkZXJNYWluJ"
		"EFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMTYkZ2R2QVNJVGFibGUkY3RsMDIkQ0JfMAVQY3RsMDAkUGxhY2VIb2xkZXJNYWluJEFwcFNwZWNUYWJsZTE1Q0UyMDhGRWRpdCRycHRBU0lUYWJsZUxpc3QkY3RsMTIkZ2R2QVNJVGFibGUPPCsADAEIZmRkYmmynuYIAA+L4XaKiwh0z93bYGs9GLHxfPhasxxSsQ==", ENDITEM,
		"Name=__VIEWSTATEGENERATOR", "Value={ViewStateGen_3}", ENDITEM,
		"Name=ACA_CS_FIELD", "Value={ACA_CS_FIELD}", ENDITEM,
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("SessionTimeOutHandler.ashx_21", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_CULTURE&_=1533770188376", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=3&currentStep=2&currentPage=2&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=,N,N,N,N,N,N,N,N&confirmStepNumber=0&isFromConfirmPage=N&agencyCode=COSA", 
		"Snapshot=t84.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("SessionTimeOutHandler.ashx_22", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_LASTEST_REQUEST_TIME&_=1533770188377", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapEdit.aspx?stepNumber=4&pageNumber=3&currentStep=2&currentPage=2&Module=LandDevelopment&ssn=1&isRenewal=N&isFromShoppingCart=&isFromConfirmPage=,N,N,N,N,N,N,N,N&confirmStepNumber=0&isFromConfirmPage=N&agencyCode=COSA", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
