Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_cookie("_pendo_accountId.08c27448-9075-481d-584f-0c00aac03d50=COSA; DOMAIN=acatest.sanantonio.gov");

	web_add_cookie("ACA_USER_PREFERRED_CULTURE=en-US; DOMAIN=acatest.sanantonio.gov");

	web_add_cookie("ACA_COOKIE_SUPPORT_ACCESSSIBILITY=False; DOMAIN=acatest.sanantonio.gov");

	web_add_cookie("_pendo_visitorId.08c27448-9075-481d-584f-0c00aac03d50=31BCA02094EB78126A517B206A88C73CFA9EC6F704C7030D18212CACE820F025F00BF0EA68DBF3F3A5436CA63B53BF7BF80AD8D5DE7D8359D0B7FED9DBC3AB99; DOMAIN=acatest.sanantonio.gov");

	web_add_cookie("_pendo_meta.08c27448-9075-481d-584f-0c00aac03d50=306981682; DOMAIN=acatest.sanantonio.gov");

	web_url("Default.aspx", 
		"URL=https://acatest.sanantonio.gov/testcitizenaccess/Default.aspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	/* Login */

	web_add_cookie("SRCHUID=V=2&GUID=3F77F14E0EB24639B0BEF7C850E7E094&dmnchg=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("MC1=GUID=fbc47db8588e4086a629f03e8f89636a&HASH=fbc4&LV=201808&V=4&LU=1533682918077; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20180807; DOMAIN=iecvlist.microsoft.com");

	web_add_header("UA-CPU", 
		"AMD64");

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1478281996/iecompatviewlist.xml", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie(".ASPXANONYMOUS=OrbuOBA5KOgL1j_Hq7jNDo5nqUfS9z0Tsc-EkyRLqKJ2GSit3zcPrKqd8AYTCjhKTBJuDzNV6CZxucSUxmtas0dC8KT7FrMB-CvLTcgokji6RYAXQdcRe5XURYSPcOW0XYJJSvWjgHl7oZ_1GWQ2br1QjMkcYbytXFPtweofG7tWTNTouxnRUJ2sJtd9xS1P0; DOMAIN=acatest.sanantonio.gov");

	web_submit_data("Welcome.aspx", 
		"Action=https://acatest.sanantonio.gov/TestCitizenAccess/Welcome.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Welcome.aspx", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ACA_CS_FIELD", "Value=93050af07a6f4822bd20f725d8d22220", ENDITEM, 
		"Name=__EVENTTARGET", "Value=ctl00$PlaceHolderMain$LoginBox$btnLogin", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=/wEPDwUKMTU1MTA5OTQ1NQ8WAh4TVmFsaWRhdGVSZXF1ZXN0TW9kZQIBFgJmD2QWBgICDw8WBB4JQWNjZXNzS2V5BQEwHgdWaXNpYmxlaGRkAgMPDxYEHwEFATEeCFRhYkluZGV4Af//"
		"ZGQCBA9kFgYCAg9kFgICAg9kFgRmD2QWCGYPFgIeBGhyZWZkZAIHDw9kFgIeBXN0eWxlBQ1kaXNwbGF5Om5vbmU7ZAIJDxYCHwJoZAIMD2QWAgIFDxYCHwJoZAIBDxYCHwJnFghmDxYCHwQFHS9UZXN0Q2l0aXplbkFjY2Vzcy9Mb2dpbi5hc3B4ZAIDDw9kFgIfBQUNZGlzcGxheTpub25lO2QCBA8WAh8CaGQCBQ8WAh8EBTIvVGVzdENpdGl6ZW5BY2Nlc3MvQWNjb3VudC9SZWdpc3RlckRpc2NsYWltZXIuYXNweGQCAw9kFgYCAQ9kFgQCAQ9kFgICAQ8WAh8CaGQCAw9kFgICAQ9kFgJmDzwrAAkBAA8WBB4IRGF0YUtleXMWAB4LXyFJdGVtQ291bnQCAmQWBGYPZBYCAgMPPCsACQEADxYEHwYWAB8HAgJkFgRmD2QWAgIBDw8WBB4EVGV4dGUeD0NvbW1hbmRBcmd1bWVudA"
		"UfL0FQTy9BUE9Mb29rdXAuYXNweD9UYWJOYW1lPUFQT2RkAgEPZBYCAgEPDxYEHwhlHwkFQi9DYXAvQ2FwQXBwbHlEaXNjbGFpbWVyLmFzcHg/"
		"VGFiTmFtZT1BUE8mRmlsdGVyTmFtZT1SZWNvcmQrTGlua2luZ2RkAgEPZBYCAgMPPCsACQEADxYEHwYWAB8HAgFkFgJmD2QWAgIBDw8WBB8IZR8JBUAvQ2FwL0NhcEhvbWUuYXNweD9tb2R1bGU9TGFuZERldmVsb3BtZW50JlRhYk5hbWU9TGFuZERldmVsb3BtZW50ZGQCAw8WAh8CZxYCAgEPZBYKAgMPDxYCHgRNb2RlCyolU3lzdGVtLldlYi5VSS5XZWJDb250cm9scy5UZXh0Qm94TW9kZQIWAh4Jb25rZXlkb3duBRR0cmlnZ2VyTG9naW4oZXZlbnQpO2QCBA8WAh8CaGQCCQ8WAh4FdGl0bGUFHFJlbWVtYmVyIG1lIG9uIHRoaXMgY29tcHV0ZXJkAgsPZBYCAgEPFgIfBAUdfi9BY2NvdW50L0ZvcmdvdFBhc3N3b3JkLmFzcHhkAgwPZBYCAgEPFgIfBAUhfi9BY2NvdW"
		"50L1JlZ2lzdGVyRGlzY2xhaW1lci5hc3B4ZAIFDxYCHwJoFgICAQ9kFgICBQ9kFgICAQ88KwAJAGQCBQ8PFgIfAmhkZBgBBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WAQUqY3RsMDAkUGxhY2VIb2xkZXJNYWluJExvZ2luQm94JGNoa1JlbWVtYmVyBM/R5WbUx8HTahB6cfFGMv0LBP7gpO/1xjvL5RJVFOE=", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=987560C5", ENDITEM, 
		"Name=txtSearchCondition", "Value=Search...", ENDITEM, 
		"Name=ctl00$HeaderNavigation$hdnShoppingCartItemNumber", "Value=", ENDITEM, 
		"Name=ctl00$HeaderNavigation$hdnShowReportLink", "Value=N", ENDITEM, 
		"Name=ctl00$PlaceHolderMain$LoginBox$hdnValidateResubmit", "Value=65afa233-a20a-4b7d-8ceb-0d081aa19d11", ENDITEM, 
		"Name=ctl00$PlaceHolderMain$LoginBox$txtUserId", "Value=amitagrawal", ENDITEM, 
		"Name=ctl00$PlaceHolderMain$LoginBox$txtPassword", "Value=Elsevier@1", ENDITEM, 
		"Name=ctl00$HDExpressionParam", "Value=", ENDITEM, 
		LAST);

	web_add_cookie("LASTEST_REQUEST_TIME=1533772582833; DOMAIN=acatest.sanantonio.gov");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("SessionTimeOutHandler.ashx", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_CULTURE&_=1533768992295", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Dashboard.aspx?TabName=Home", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("SessionTimeOutHandler.ashx_2", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_LASTEST_REQUEST_TIME&_=1533768992296", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Dashboard.aspx?TabName=Home", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
