Logout()
{

	lr_think_time(23);

	web_url("Logout.aspx", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Logout.aspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapCompletion.aspx?stepNumber=8&Module=LandDevelopment&isRenewal=N&isPay4ExistingCap=N", 
		"Snapshot=t139.inf", 
		"Mode=HTML", 
		LAST);

	web_url("Login.aspx", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Login.aspx", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Logout.aspx", 
		"Snapshot=t141.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}