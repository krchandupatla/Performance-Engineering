PaymentDetails()
{

	web_submit_data("MakePayment.aspx_2", 
		"Action=https://acatest.sanantonio.gov/PaymentGateway/MakePayment.aspx?ApplicationID=1&TransactionID=35&TransactionID=&PaymentAmount=2968.6&PaymentAmount=&ConvFee=0&PostbackURL=https%3a%2f%2facatest.sanantonio.gov%3a443%2fTestCitizenAccess%2fpayment%2fpaymentpostback.aspx&PostbackURL=&RedirectURL=https%3a%2f%2facatest.sanantonio.gov%3a443%2fTestCitizenAccess%2fpayment%2fpaymentredirect.aspx&RedirectURL=&UserID=PUBLICUSER235&FullName=Amit%2520Agrawal&UserEmail=amit.agrawal%40gcomsoft.com&AgencyCode="
		"COSA&PaymentType=CC&MerchantAccountID=0&Lang=en-US", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t134.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__VIEWSTATE", "Value=mgJWKeaR4PJgVxUO6zCHcf2GERKPwIvk5WNvEEjJjGdthIaxut87zl7equYDRHTgBQfkcsOEZTq29z2wZ2IAathcxV0ZPXQHyU0WRADc/lE=", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=A6671826", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=qqp8uZrXozb5l78QOR1rRrXb3NL/je0gVPifScx+2+dSOBQMBkYhMR5lSzunm6/MGqHQuxrW78WBJ9tv2ricm7y7Ec9u3kipe0ay6cuJdusWUEvwa1i6YJWXqok24OwyIC5y3atUNYPsUgTlZa8Y3w==", ENDITEM, 
		"Name=PaymentMethod", "Value=CreditCard", ENDITEM, 
		"Name=Continue", "Value=Continue", ENDITEM, 
		LAST);

	/* enter payment details and click complete transaction */

	web_submit_data("POSItemPayment.aspx", 
		"Action=https://161.226.28.96/POSWeb_Accela/POSItemPayment.aspx", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://161.226.28.96/POSWeb_Accela/POSItemPayment.aspx", 
		"Snapshot=t135.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=__EVENTTARGET", "Value=", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__LASTFOCUS", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=/"
		"wEPDwUJLTU1MjAwMTkzD2QWAmYPZBYGAgQPDxYEHgRUZXh0BQlWaWV3IENhcnQeB1Rvb2xUaXAFCVZpZXcgQ2FydBYEHgdvbmNsaWNrBSdiVmFsaWRhdGUgPSBmYWxzZTsgYlVzZUFNU0VuY3IgPSBmYWxzZTseA2FsdAUJVmlldyBDYXJ0ZAIFDw8WBB8ABRdPbmxpbmUgSW52b2ljZSBQYXltZW50cx8BBRdPbmxpbmUgSW52b2ljZSBQYXltZW50cxYEHwIFJ2JWYWxpZGF0ZSA9IGZhbHNlOyBiVXNlQU1TRW5jciA9IGZhbHNlOx8DBRdPbmxpbmUgSW52b2ljZSBQYXltZW50c2QCCA9kFgQCAQ8PFgIeB1Zpc2libGVoZGQCAg8PFgIfBGhkZBgBBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WAwUUb3B0UGF5bWVudENyZWRpdENhcmQFFW9wdFBheW1lbnRCYW5"
		"rQWNjb3VudAUVb3B0UGF5bWVudEJhbmtBY2NvdW50oyp0sPuex6hOeuNVrtJSYpUQrmtaX0NC9TDDZfRrQBY=", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=DBE891B1", ENDITEM, 
		"Name=__EVENTVALIDATION", "Value=/wEdAAodPfxlJnDxoQoyGv9a93rGmTGJ+VRbuEC7VTEbU+jqoUXTCD1yQOcNp81sNlKdK3Yx9N8Wezjf4S9G1vPMKHhVLGv9nyZyg53D2vDKx3d9V44AKTi6Ky+aXQbft5V7rFMvBQx/aleAB/enrN2P1iTJJbDCahDkvu1ejIrx1DscjXdnEvBi22/7h4NqlyqB3M2rHIwb9NYOIusKuL7x0jj+5xjMN6ipwGEoCtWlMHJSRTSe7vBoQ2179RYxY1eK1Ms=", ENDITEM, 
		"Name=AMSEncrModulus", "Value=", ENDITEM, 
		"Name=AMSEncrExponent", "Value=", ENDITEM, 
		"Name=AMSEncrCipherText", "Value=", ENDITEM, 
		"Name=AMSEncrCipherResponse", "Value=", ENDITEM, 
		"Name=Payment", "Value=optPaymentCreditCard", ENDITEM, 
		"Name=cardtype", "Value=4", ENDITEM, 
		"Name=cardtypeindex", "Value=2", ENDITEM, 
		"Name=cardnumber", "Value=5404000000000001", ENDITEM, 
		"Name=cardexpirymonth", "Value=12", ENDITEM, 
		"Name=cardexpiryyear", "Value=2018", ENDITEM, 
		"Name=address", "Value=", ENDITEM, 
		"Name=zipcode", "Value=", ENDITEM, 
		"Name=cmdCompleteTransactionButton", "Value=Complete Transaction", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("UpdatePayment.aspx", 
		"URL=https://acatest.sanantonio.gov/PaymentGateway/UpdatePayment.aspx?CartId=2577", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://161.226.28.96/POSWeb_Accela/POSItemReceipt.aspx", 
		"Snapshot=t136.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("SessionTimeOutHandler.ashx_31", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_CULTURE&_=1533770751382", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapCompletion.aspx?stepNumber=8&Module=LandDevelopment&isRenewal=N&isPay4ExistingCap=N", 
		"Snapshot=t137.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("SessionTimeOutHandler.ashx_32", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_LASTEST_REQUEST_TIME&_=1533770751383", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapCompletion.aspx?stepNumber=8&Module=LandDevelopment&isRenewal=N&isPay4ExistingCap=N", 
		"Snapshot=t138.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
