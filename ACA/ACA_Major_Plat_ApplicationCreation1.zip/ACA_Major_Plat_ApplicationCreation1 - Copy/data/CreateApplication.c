CreateApplication()
{

	/* click create an application */

	web_add_cookie("_pendo_meta.08c27448-9075-481d-584f-0c00aac03d50=4225498636; DOMAIN=acatest.sanantonio.gov");

	lr_think_time(9);

	web_url("CapApplyDisclaimer.aspx", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapApplyDisclaimer.aspx?module=LandDevelopment&TabName=LandDevelopment&FilterName=Land+Development&TabList=Home%7C0%7CLandDevelopment%7C1%7CCurrentTabIndex%7C1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapHome.aspx?module=LandDevelopment&TabName=LandDevelopment&TabList=Home%7C0%7CLandDevelopment%7C1%7CCurrentTabIndex%7C1", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("SessionTimeOutHandler.ashx_5", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_CULTURE&_=1533769058314", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapApplyDisclaimer.aspx?module=LandDevelopment&TabName=LandDevelopment&FilterName=Land+Development&TabList=Home%7C0%7CLandDevelopment%7C1%7CCurrentTabIndex%7C1", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("SessionTimeOutHandler.ashx_6", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_LASTEST_REQUEST_TIME&_=1533769058315", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapApplyDisclaimer.aspx?module=LandDevelopment&TabName=LandDevelopment&FilterName=Land+Development&TabList=Home%7C0%7CLandDevelopment%7C1%7CCurrentTabIndex%7C1", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	/* accept terms and conditions and click continue application */

	/* select check box and click continue application */

	web_submit_data("CapApplyDisclaimer.aspx_2", 
		"Action=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapApplyDisclaimer.aspx?module=LandDevelopment&TabName=LandDevelopment&FilterName=Land+Development&TabList=Home%7c0%7cLandDevelopment%7c1%7cCurrentTabIndex%7c1", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapApplyDisclaimer.aspx?module=LandDevelopment&TabName=LandDevelopment&FilterName=Land+Development&TabList=Home%7C0%7CLandDevelopment%7C1%7CCurrentTabIndex%7C1", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=ACA_CS_FIELD", "Value=93050af07a6f4822bd20f725d8d22220", ENDITEM, 
		"Name=__EVENTTARGET", "Value=ctl00$PlaceHolderMain$btnNextStep", ENDITEM, 
		"Name=__EVENTARGUMENT", "Value=", ENDITEM, 
		"Name=__VIEWSTATE", "Value=/wEPDwUKMTY4MDUxNzU1Nw8WAh4TVmFsaWRhdGVSZXF1ZXN0TW9kZQIBFgJmD2QWBgICDw8WBB4JQWNjZXNzS2V5BQEwHgdWaXNpYmxlaGRkAgMPDxYEHwEFATEeCFRhYkluZGV4Af//"
		"ZGQCBA9kFgYCAg9kFgICAg9kFgRmDxYCHwJnFgpmDxYCHgRocmVmBR4vVGVzdENpdGl6ZW5BY2Nlc3MvTG9nb3V0LmFzcHhkAgcPD2QWAh4Fc3R5bGUFDWRpc3BsYXk6bm9uZTtkAgkPFgIfAmgWAgIBDw8WAh8CaGRkAgoPDxYEHglJc0VuY29kZWRoHgRUZXh0BQ9Db2xsZWN0aW9ucyAoMClkZAIODw8WBh4HVG9vbFRpcAUMQW1pdCBBZ3Jhd2FsHwZoHwcFDEFtaXQgQWdyYXdhbGRkAgEPZBYEAgMPD2QWAh8FBQ1kaXNwbGF5Om5vbmU7ZAIFDxYCHwRkZAIDD2QWBAIJDxYCHgV0aXRsZQUpSSBoYXZlIHJlYWQgYW5kIGFjY2VwdGVkIHRoZSBhYm92ZSB0ZXJtcy5kAgwPZBYCAgEPDxYCHwEFATNkZAIFDw8WAh8CaGRkGAEFHl9fQ29udHJvbHNSZXF1aXJlUG9zdEJhY2"
		"tLZXlfXxYBBSBjdGwwMCRQbGFjZUhvbGRlck1haW4kdGVybUFjY2VwdIF3INyDsIAwuTcrhTySzXytm3jq4WL+8IvIQI83OlIH", ENDITEM, 
		"Name=__VIEWSTATEGENERATOR", "Value=4D2D8321", ENDITEM, 
		"Name=txtSearchCondition", "Value=Search...", ENDITEM, 
		"Name=ctl00$HeaderNavigation$hdnShoppingCartItemNumber", "Value=", ENDITEM, 
		"Name=ctl00$HeaderNavigation$hdnShowReportLink", "Value=Y", ENDITEM, 
		"Name=ctl00$PlaceHolderMain$termAccept", "Value=on", ENDITEM, 
		"Name=ctl00$HDExpressionParam", "Value=", ENDITEM, 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("SessionTimeOutHandler.ashx_7", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_CULTURE&_=1533769228205", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapType.aspx?Module=LandDevelopment&stepNumber=1&pageNumber=1&isFeeEstimator=&createdBy=PUBLICUSER235&TabName=LandDevelopment&FilterName=Land+Development", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("SessionTimeOutHandler.ashx_8", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_LASTEST_REQUEST_TIME&_=1533769228206", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapType.aspx?Module=LandDevelopment&stepNumber=1&pageNumber=1&isFeeEstimator=&createdBy=PUBLICUSER235&TabName=LandDevelopment&FilterName=Land+Development", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
