LandDevelopment()
{

	/* click land development */

	web_add_cookie("_pendo_visitorId.08c27448-9075-481d-584f-0c00aac03d50=01E6A0B801CC1FAF35AF3095AEC2A8ED923E360F0EE6B325DB713F139543B752E6C9B9A2531B9E17537CCFC9A4E7D1B5102E1396E3E7A87AECA6649278525A52; DOMAIN=acatest.sanantonio.gov");

	web_add_cookie("_pendo_meta.08c27448-9075-481d-584f-0c00aac03d50=2766651098; DOMAIN=acatest.sanantonio.gov");

	web_add_cookie("TabNav=Home|0|LandDevelopment|1|CurrentTabIndex|1; DOMAIN=acatest.sanantonio.gov");

	lr_think_time(28);

	web_url("CapHome.aspx", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapHome.aspx?module=LandDevelopment&TabName=LandDevelopment&TabList=Home%7C0%7CLandDevelopment%7C1%7CCurrentTabIndex%7C1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Dashboard.aspx?TabName=Home", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("SessionTimeOutHandler.ashx_3", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_CULTURE&_=1533769022356", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapHome.aspx?module=LandDevelopment&TabName=LandDevelopment&TabList=Home%7C0%7CLandDevelopment%7C1%7CCurrentTabIndex%7C1", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_url("SessionTimeOutHandler.ashx_4", 
		"URL=https://acatest.sanantonio.gov/TestCitizenAccess/Handlers/SessionTimeOutHandler.ashx?action=GET_LASTEST_REQUEST_TIME&_=1533769022357", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://acatest.sanantonio.gov/TestCitizenAccess/Cap/CapHome.aspx?module=LandDevelopment&TabName=LandDevelopment&TabList=Home%7C0%7CLandDevelopment%7C1%7CCurrentTabIndex%7C1", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
