//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Library_AV2()
{
	truclient_step("1", "Function NewUI", "snapshot=AV2_1.inf");
	{
		truclient_step("1.1", "Click on Switch New UI link", "snapshot=AV2_1.1.inf");
	}

	return 0;
}
