Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_url("dashboard.do", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t105.inf", 
		"Mode=HTML", 
		LAST);

	web_url("hostSignon.do", 
		"URL=https://av-pt-ferrari.accela.com/security/hostSignon.do?successUrl=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/ssoAdapter/loginAction.do?successURL=https%3A%2F%2Fav-pt-ferrari.accela.com%2Fportlets%2Fspa%2Fdashboard.do&SignOnModule=", 
		"Snapshot=t106.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(4);

	lr_start_transaction("MILARA_Login");

	web_custom_request("loginAction.do", 
		"URL=https://av-pt-ferrari.accela.com/ssoAdapter/loginAction.do?requestType=checkWebSSOAdapter&servProvCode=MILARA", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/security/hostSignon.do?hostSignOn=true", 
		"Snapshot=t107.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded", 
		LAST);

	lr_think_time(9);

	web_submit_data("hostSignon.do_2", 
		"Action=https://av-pt-ferrari.accela.com/security/hostSignon.do?hostSignOn=true", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/security/hostSignon.do?hostSignOn=true", 
		"Snapshot=t108.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=action", "Value=signon", ENDITEM, 
		"Name=successUrl", "Value=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", ENDITEM, 
		"Name=cookieUserName", "Value=", ENDITEM, 
		"Name=cookieAgencyName", "Value=", ENDITEM, 
		"Name=requestToken", "Value=13251c25710a", ENDITEM, 
		"Name=requestLanguageToken", "Value=141140309339", ENDITEM, 
		"Name=password1", "Value=", ENDITEM, 
		"Name=servProvCode", "Value=MILARA", ENDITEM, 
		"Name=username", "Value=admin", ENDITEM, 
		"Name=password", "Value=admin", ENDITEM, 
		"Name=accela_select_language", "Value=en_US", ENDITEM, 
		"Name=submit_", "Value=Login", ENDITEM, 
		LAST);

	web_url("dashboard.do_2", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/security/hostSignon.do?hostSignOn=true", 
		"Snapshot=t109.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("text.do", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/text.do?mode=localizedText", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"Snapshot=t110.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"AANewUX_ApplicationMenu_Administration\":\"\",\"AANewUX_ApplicationMenu_CivicPlatform\":\"\",\"AANewUX_ApplicationMenu_ExitAdministration\":\"\",\"AANewUX_ApplicationMenu_ClassicAdministration\":\"\",\"AANewUX_ApplicationMenu_ExitClassicAdministration\":\"\",\"AANewUX_ApplicationMenu_Help\":\"\",\"AANewUX_ApplicationMenu_SignOut\":\"\",\"AANewUX_ApplicationMenu_SwitchToV360\":\"\",\"AANewUX_Dialog_Close\":\"\",\"AANewUX_Dialog_PortletErrorTitle\":\"\",\"AANewUX_Dialog_URLRequired\":\"\",\""
		"AANewUX_Error_InvalidResponse\":\"\",\"AANewUX_Error_SessionTimedOut\":\"\",\"AANewUX_GIS_CreateInspections\":\"\",\"AANewUX_GIS_Actions\":\"\",\"AANewUX_GIS_AccelaRecords\":\"\",\"AANewUX_GIS_Address\":\"\",\"AANewUX_GIS_Addresses\":\"\",\"AANewUX_GIS_Assets\":\"\",\"AANewUX_GIS_Contents\":\"\",\"AANewUX_GIS_NotPlotted\":\"\",\"AANewUX_GIS_AllRecords\":\"\",\"AANewUX_GIS_AllTransactions\":\"\",\"AANewUX_GIS_AssetGroup\":\"\",\"AANewUX_GIS_AssetID\":\"\",\"AANewUX_GIS_AssetType\":\"\",\""
		"AANewUX_GIS_ClassType\":\"\",\"AANewUX_GIS_ClearAll\":\"\",\"AANewUX_GIS_AttachToRecord\":\"\",\"AANewUX_GIS_BufferSelection\":\"\",\"AANewUX_GIS_DriveTimeBufferSelection\":\"\",\"AANewUX_GIS_CreateNewRecord\":\"\",\"AANewUX_GIS_CreateWorkOrder\":\"\",\"AANewUX_GIS_CreateMultipleWorkOrders\":\"\",\"AANewUX_GIS_ExportToCSV\":\"\",\"AANewUX_GIS_Description\":\"\",\"AANewUX_GIS_GISObjects\":\"\",\"AANewUX_GIS_HideDetails\":\"\",\"AANewUX_GIS_InstallDate\":\"\",\"AANewUX_GIS_Inspections\":\"\",\""
		"AANewUX_GIS_InspectionType\":\"\",\"AANewUX_GIS_OpenedDate\":\"\",\"AANewUX_GIS_Owner\":\"\",\"AANewUX_GIS_Parcel\":\"\",\"AANewUX_GIS_Parcels\":\"\",\"AANewUX_GIS_Permits\":\"\",\"AANewUX_GIS_ParcelID\":\"\",\"AANewUX_GIS_RecordID\":\"\",\"AANewUX_GIS_PermitID\":\"\",\"AANewUX_GIS_Records\":\"\",\"AANewUX_GIS_RecordType\":\"\",\"AANewUX_GIS_ScheduledDate\":\"\",\"AANewUX_GIS_SelectNearbyFeatures\":\"\",\"AANewUX_GIS_SendGISFeature\":\"\",\"AANewUX_GIS_ShowDetails\":\"\",\""
		"AANewUX_GIS_ShowDocument\":\"\",\"AANewUX_GIS_ShowingResults\":\"\",\"AANewUX_GIS_Status\":\"\",\"AANewUX_GIS_TooManyGisObjectsTitle\":\"\",\"AANewUX_GIS_TooManyGisObjectsMsg\":\"\",\"AANewUX_GIS_Transactions\":\"\",\"AANewUX_GIS_XCoordinate\":\"\",\"AANewUX_GIS_YCoordinate\":\"\",\"AANewUX_GIS_ZipCode\":\"\",\"AANewUX_GIS_InspRecords\":\"\",\"AANewUX_GIS_selected\":\"\",\"AANewUX_GIS_SelectAll\":\"\",\"AANewUX_GIS_DeselectAll\":\"\",\"AANewUX_GIS_Opened\":\"\",\"AANewUX_GIS_MORE\":\"\",\""
		"AANewUX_GIS_NewPanelRecords\":\"\",\"AANewUX_GlobalSearch_Address\":\"\",\"AANewUX_GlobalSearch_Agency\":\"\",\"AANewUX_GlobalSearch_AltID\":\"\",\"AANewUX_GlobalSearch_Applicant\":\"\",\"AANewUX_GlobalSearch_ApplicationName\":\"\",\"AANewUX_GlobalSearch_AssetInfo\":\"\",\"AANewUX_GlobalSearch_AssetsTab\":\"\",\"AANewUX_GlobalSearch_BusinessName\":\"\",\"AANewUX_GlobalSearch_ColumnView\":\"\",\"AANewUX_GlobalSearch_Contact\":\"\",\"AANewUX_GlobalSearch_ContactNumber\":\"\",\""
		"AANewUX_GlobalSearch_ContactBusinessName\":\"\",\"AANewUX_GlobalSearch_ContactsTab\":\"\",\"AANewUX_GlobalSearch_ContactType\":\"\",\"AANewUX_GlobalSearch_CreatedDate\":\"\",\"AANewUX_GlobalSearch_CreatedOn\":\"\",\"AANewUX_GlobalSearch_Description\":\"\",\"AANewUX_GlobalSearch_Document\":\"\",\"AANewUX_GlobalSearch_DocumentCategory\":\"\",\"AANewUX_GlobalSearch_DocumentName\":\"\",\"AANewUX_GlobalSearch_DocumentStatus\":\"\",\"AANewUX_GlobalSearch_DocumentsTab\":\"\",\"AANewUX_GlobalSearch_Email"
		"\":\"\",\"AANewUX_GlobalSearch_FilterButton\":\"\",\"AANewUX_GlobalSearch_FullName\":\"\",\"AANewUX_GlobalSearch_LastPage\":\"\",\"AANewUX_GlobalSearch_LastUpdatedOn\":\"\",\"AANewUX_GlobalSearch_LicenseExpiresOn\":\"\",\"AANewUX_GlobalSearch_LicenseIssuedOn\":\"\",\"AANewUX_GlobalSearch_LicenceProfessionalsTab\":\"\",\"AANewUX_GlobalSearch_LicenseType\":\"\",\"AANewUX_GlobalSearch_Location\":\"\",\"AANewUX_GlobalSearch_LocationsTab\":\"\",\"AANewUX_GlobalSearch_NextPageLink\":\"\",\""
		"AANewUX_GlobalSearch_Owner\":\"\",\"AANewUX_GlobalSearch_Page\":\"\",\"AANewUX_GlobalSearch_Parcel\":\"\",\"AANewUX_GlobalSearch_ParcelsTab\":\"\",\"AANewUX_GlobalSearch_PhoneNumber\":\"\",\"AANewUX_GlobalSearch_ProjectName\":\"\",\"AANewUX_GlobalSearch_Record\":\"\",\"AANewUX_GlobalSearch_RecordID\":\"\",\"AANewUX_GlobalSearch_RecordInfo\":\"\",\"AANewUX_GlobalSearch_RecordsTab\":\"\",\"AANewUX_GlobalSearch_RecordType\":\"\",\"AANewUX_GlobalSearch_ReportedType\":\"\",\""
		"AANewUX_GlobalSearch_ResultsCount\":\"\",\"AANewUX_GlobalSearch_Review\":\"\",\"AANewUX_GlobalSearch_PreviousPageLink\":\"\",\"AANewUX_GlobalSearch_ShortNotes\":\"\",\"AANewUX_GlobalSearch_Showing\":\"\",\"AANewUX_GlobalSearch_SortByMostRecent\":\"\",\"AANewUX_GlobalSearch_Status\":\"\",\"AANewUX_GlobalSearch_StatusDate\":\"\",\"AANewUX_GlobalSearch_StateLicenseNo\":\"\",\"AANewUX_GlobalSearch_TabRecordCount\":\"\",\"AANewUX_GlobalSearch_TradeName\":\"\",\"AANewUX_GlobalSearch_Type\":\"\",\""
		"AANewUX_GlobalSearchForm_Advanced\":\"\",\"AANewUX_GlobalSearchForm_RecentSearches\":\"\",\"AANewUX_GlobalSearchForm_InputPlaceholder\":\"\",\"AANewUX_GlobalSearchForm_SubmitButtonText\":\"\",\"AANewUX_Launchpad_Address\":\"\",\"AANewUX_Launchpad_AddFavorite\":\"\",\"AANewUX_Launchpad_AllPages\":\"\",\"AANewUX_Launchpad_Assets\":\"\",\"AANewUX_Launchpad_ClearAll\":\"\",\"AANewUX_Launchpad_Contacts\":\"\",\"AANewUX_Launchpad_Filter\":\"\",\"AANewUX_Launchpad_FilterList\":\"\",\""
		"AANewUX_Launchpad_HideAllPages\":\"\",\"AANewUX_Launchpad_New\":\"\",\"AANewUX_Launchpad_NewApplication\":\"\",\"AANewUX_Launchpad_Owners\":\"\",\"AANewUX_Launchpad_Parcels\":\"\",\"AANewUX_Launchpad_Professionals\":\"\",\"AANewUX_Launchpad_Recent\":\"\",\"AANewUX_Launchpad_ShowAllPages\":\"\",\"AANewUX_Launchpad_YourPages\":\"\",\"AANewUX_Launchpad_RemoveFavorite\":\"\",\"AANewUX_MainMenu_Label\":\"\",\"AANewUX_MainMenu_DashboardActive\":\"\",\"AANewUX_MainMenu_DashboardOpen\":\"\",\""
		"AANewUX_MainMenu_GlobalSearchOpen\":\"\",\"AANewUX_MainMenu_GlobalSearchClose\":\"\",\"AANewUX_MainMenu_LaunchpadOpen\":\"\",\"AANewUX_MainMenu_LaunchpadClose\":\"\",\"AANewUX_Task_Actions\":\"\",\"AANewUX_Task_Active\":\"\",\"AANewUX_Task_ActivityDeleteSuccess\":\"\",\"AANewUX_Task_ActivityID\":\"\",\"AANewUX_Task_Address\":\"\",\"AANewUX_Task_Agenda\":\"\",\"AANewUX_Task_AllPages\":\"\",\"AANewUX_Task_AltID\":\"\",\"AANewUX_Task_AlternateID\":\"\",\"AANewUX_Task_Assign\":\"\",\""
		"AANewUX_Task_Assigned\":\"\",\"AANewUX_Task_AssignedTo\":\"\",\"AANewUX_Task_Cancel\":\"\",\"AANewUX_Task_Category\":\"\",\"AANewUX_Task_CategoryACTIVITY\":\"\",\"AANewUX_Task_CategoryDOCUMENT\":\"\",\"AANewUX_Task_CategoryINSPECTION\":\"\",\"AANewUX_Task_CategoryMEETING\":\"\",\"AANewUX_Task_CategoryWORKFLOW\":\"\",\"AANewUX_Task_Claim\":\"\",\"AANewUX_Task_Clear\":\"\",\"AANewUX_Task_ColumnView\":\"\",\"AANewUX_Task_Completed\":\"\",\"AANewUX_Task_ConditionApplied\":\"\",\""
		"AANewUX_Task_ConditionPlusNMore\":\"\",\"AANewUX_Task_Delete\":\"\",\"AANewUX_Task_DocumentActionNotDefined\":\"\",\"AANewUX_Task_DocumentPreviewPermissionFail\":\"\",\"AANewUX_Task_Download\":\"\",\"AANewUX_Task_Due\":\"\",\"AANewUX_Task_DueInNDays\":\"\",\"AANewUX_Task_DueDateNotAssigned\":\"\",\"AANewUX_Task_DueToday\":\"\",\"AANewUX_Task_Duplicate\":\"\",\"AANewUX_Task_Duration\":\"\",\"AANewUX_Task_DurationHour\":\"\",\"AANewUX_Task_DurationHours\":\"\",\"AANewUX_Task_DurationMinute\":\"\",\""
		"AANewUX_Task_DurationMinutes\":\"\",\"AANewUX_Task_ExportToCSV\":\"\",\"AANewUX_Task_Filter\":\"\",\"AANewUX_Task_FilterAdvanced\":\"\",\"AANewUX_Task_FilterApply\":\"\",\"AANewUX_Task_FilterClearAll\":\"\",\"AANewUX_Task_FilterDateRangeAssigned\":\"\",\"AANewUX_Task_FilterDateRangeDue\":\"\",\"AANewUX_Task_FilterDateRangeOpen\":\"\",\"AANewUX_Task_FilterDateRangeStatus\":\"\",\"AANewUX_Task_FilterFrom\":\"\",\"AANewUX_Task_FilterSelected\":\"\",\"AANewUX_Task_FilterSave\":\"\",\""
		"AANewUX_Task_FilterStatusCompleted\":\"\",\"AANewUX_Task_FilterTabAssignedTo\":\"\",\"AANewUX_Task_FilterTabDateRange\":\"\",\"AANewUX_Task_FilterTabSaved\":\"\",\"AANewUX_Task_FilterTabStatus\":\"\",\"AANewUX_Task_FilterTabType\":\"\",\"AANewUX_Task_FilterTo\":\"\",\"AANewUX_Task_Group\":\"\",\"AANewUX_Task_HasNoAddress\":\"\",\"AANewUX_Task_HasNoCity\":\"\",\"AANewUX_Task_HasNoComment\":\"\",\"AANewUX_Task_HasNoDescription\":\"\",\"AANewUX_Task_HasNoLocation\":\"\",\""
		"AANewUX_Task_HasNoMeetingBody\":\"\",\"AANewUX_Task_HasNoScheduledTime\":\"\",\"AANewUX_Task_InspectionCancelSuccess\":\"\",\"AANewUX_Task_InspectionDeleteFail\":\"\",\"AANewUX_Task_InspectionDeleteSuccess\":\"\",\"AANewUX_Task_InTheAfternoon\":\"\",\"AANewUX_Task_InTheMorning\":\"\",\"AANewUX_Task_Location\":\"\",\"AANewUX_Task_LoadMore\":\"\",\"AANewUX_Task_LoadingTasks\":\"\",\"AANewUX_Task_MeetingRejectedSuccess\":\"\",\"AANewUX_Task_NoMoreRecordsAvailable\":\"\",\""
		"AANewUX_Task_NoTasksAssigned\":\"\",\"AANewUX_Task_NoTasksFound\":\"\",\"AANewUX_Task_NoFilteredTasksFound\":\"\",\"AANewUX_Task_NoQuickQueriesFound\":\"\",\"AANewUX_Task_PageLabel\":\"\",\"AANewUX_Task_PageOfLabel\":\"\",\"AANewUX_Task_Preview\":\"\",\"AANewUX_Task_PreviewDocument\":\"\",\"AANewUX_Task_Print\":\"\",\"AANewUX_Task_QuickQueries\":\"\",\"AANewUX_Task_Reassign\":\"\",\"AANewUX_Task_RecordAgendaSetSuccess\":\"\",\"AANewUX_Task_RecordActionDownloadSuccess\":\"\",\""
		"AANewUX_Task_RecordDuplicateSuccess\":\"\",\"AANewUX_Task_RecordID\":\"\",\"AANewUX_Task_RecordReassignSuccess\":\"\",\"AANewUX_Task_RecordRemoveSuccess\":\"\",\"AANewUX_Task_RecordRescheduleSuccess\":\"\",\"AANewUX_Task_RecordReviewSuccess\":\"\",\"AANewUX_Task_RecordType\":\"\",\"AANewUX_Task_Reject\":\"\",\"AANewUX_Task_Release\":\"\",\"AANewUX_Task_Remove\":\"\",\"AANewUX_Task_Reschedule\":\"\",\"AANewUX_Task_Result\":\"\",\"AANewUX_Task_Review\":\"\",\"AANewUX_Task_Schedule\":\"\",\""
		"AANewUX_Task_ShowingNTasks\":\"\",\"AANewUX_Task_ShowingNFilteredTasks\":\"\",\"AANewUX_Task_Sort\":\"\",\"AANewUX_Task_Success\":\"\",\"AANewUX_Task_TaskErrorHeading\":\"\",\"AANewUX_Task_TaskName\":\"\",\"AANewUX_Task_TaskListFixedColumnHeader\":\"\",\"AANewUX_Task_TaskListDueDateHeader\":\"\",\"AANewUX_Task_TaskListFlagsHeader\":\"\",\"AANewUX_Task_TaskListStatusHeader\":\"\",\"AANewUX_Task_TaskListDetailsHeader\":\"\",\"AANewUX_Task_Tasks\":\"\",\"AANewUX_Task_TotalTasks\":\"\",\""
		"AANewUX_Task_Type\":\"\",\"AANewUX_Task_ViewDocInfo\":\"\",\"AANewUX_Task_Warning\":\"\",\"AANewUX_Task_Workflow\":\"\",\"AANewUX_Task_WorkflowClaimFail\":\"\",\"AANewUX_Task_WorkflowClaimPermissionFail\":\"\",\"AANewUX_Task_WorkflowClaimSuccess\":\"\",\"AANewUX_Task_WorkflowReleaseFail\":\"\",\"AANewUX_Task_WorkflowReleasePermissionFail\":\"\",\"AANewUX_Task_WorkflowReleaseSuccess\":\"\",\"AANewUX_Tooltip_CardView\":\"\",\"AANewUX_Tooltip_ListView\":\"\",\"AANewUX_Tooltip_Map\":\"\",\""
		"AANewUX_Tooltip_SuperAgencyDashboard\":\"\",\"AANewUX_Tooltip_Tasks\":\"\",\"AANewUX_Workspace_Close\":\"\",\"AANewUX_Workspace_More\":\"\",\"AANewUX_Workspace_OpenSpaces\":\"\",\"AANewUX_Workspace_Pin\":\"\",\"AANewUX_Workspace_Unpin\":\"\"}", 
		LAST);

	web_custom_request("userinfo.do", 
		"URL=https://av-pt-ferrari.accela.com/portlets/user/userinfo.do?mode=userInfo", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/x-json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"Snapshot=t111.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={}", 
		LAST);

	web_url("session.do", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.mytask-list", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("MILARA_Login",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("MILARA_TC3_01_ClickRecords");

	web_url("session.do_2", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=null", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"Snapshot=t113.inf", 
		"Mode=HTML", 
		LAST);

	web_url("session.do_3", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.mytask-list", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		LAST);

	web_url("session.do_4", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=null", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"Snapshot=t115.inf", 
		"Mode=HTML", 
		LAST);

	web_url("session.do_5", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"Snapshot=t116.inf", 
		"Mode=HTML", 
		LAST);

	web_url("myCAPDetailPortlet.jsp", 
		"URL=https://av-pt-ferrari.accela.com/portlets/commons/cap/myCAPDetailPortlet.jsp?module=-select-", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"Snapshot=t117.inf", 
		"Mode=HTML", 
		LAST);

	web_url("View the content of this inline frame", 
		"URL=https://av-pt-ferrari.accela.com/portlets/framework/includes/error/blank.jsp", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/capSearch.do?searchBy=ByCondition&height=270&mode=init&module=Licenses&cleanCapId=Y&isGeneralCAP=Y&supportMulAgencySearch=Y", 
		"Snapshot=t118.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("empty.jsp", 
		"Action=https://av-pt-ferrari.accela.com/portlets/framework/includes/error/empty.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/spa/dashboard.do", 
		"Snapshot=t119.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	lr_end_transaction("MILARA_TC3_01_ClickRecords",LR_AUTO);

	lr_start_transaction("MILARA_TC3_02_Records_ClickNew");

	web_url("session.do_6", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1&module=Licenses", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/capSearch.do?searchBy=ByCondition&height=270&mode=init&module=Licenses&cleanCapId=Y&isGeneralCAP=Y&supportMulAgencySearch=Y", 
		"Snapshot=t120.inf", 
		"Mode=HTML", 
		LAST);

	web_url("capTypePickerSelector.do", 
		"URL=https://av-pt-ferrari.accela.com/portlets/picker/capTypePickerSelector.do?fromModel=cap&module=Licenses&isGeneralCAP=Y", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/capSearch.do?searchBy=ByCondition&height=270&mode=init&module=Licenses&cleanCapId=Y&isGeneralCAP=Y&supportMulAgencySearch=Y", 
		"Snapshot=t121.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("empty.jsp_2", 
		"Action=https://av-pt-ferrari.accela.com/portlets/framework/includes/error/empty.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePickerSelector.do?fromModel=cap&module=Licenses&isGeneralCAP=Y", 
		"Snapshot=t122.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_url("session.do_7", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1&module=Licenses", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePickerSelector.do?fromModel=cap&module=Licenses&isGeneralCAP=Y", 
		"Snapshot=t123.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("MILARA_TC3_02_Records_ClickNew",LR_AUTO);

	lr_start_transaction("MILARA_TC3_03_SelectRecordType_OpenSpearForm");

	web_url("session.do_8", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1&module=Licenses", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePickerSelector.do?fromModel=cap&module=Licenses&isGeneralCAP=Y", 
		"Snapshot=t124.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("capTypePicker.do", 
		"URL=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=validateCapType&modelId=&module=Enforcement", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePickerSelector.do?fromModel=cap&module=Licenses&isGeneralCAP=Y", 
		"Snapshot=t125.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=%2Fportlets%2Fpicker%2FcapTypePicker.do%3FfromModel%3Dcap%26module%3DLicenses%26isGeneralCAP%3DY&value(CurrentEntryURL)=%2Fportlets%2Fpicker%2FcapTypePicker.do%3FfromModel%3Dcap%26module%3DLicenses%26isGeneralCAP%3DY&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=&modeName=&module=Licenses&accelasubmitbuttonname=&itemName=&CurrentViewID=119&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&"
		"CurrentViewID=119&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(capTypeModel*type)=Complaint&value(capTypeModel*subType)=NA&value(capTypeModel*category)=NA&value(selectModuleName)=Enforcement&value(g1AssetGroup)=&value(g1AssetType)=&value(mode)=add&value(srLevel)=&value(capGroupIndex)=&value(capTypeModel*group)=Enforcement&value(capTypeModel)=Enforcement%2FComplaint%2FNA%2FNA&value(fromModel)=cap&value(modelId)=&value(formKey)=&value(GISCommand)=&", 
		LAST);

	web_submit_data("capTypePicker.do_2", 
		"Action=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePickerSelector.do?fromModel=cap&module=Licenses&isGeneralCAP=Y", 
		"Snapshot=t126.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=value(FirstEntryURL)", "Value=/portlets/picker/capTypePicker.do?fromModel=cap&module=Licenses&isGeneralCAP=Y", ENDITEM, 
		"Name=value(CurrentEntryURL)", "Value=/portlets/picker/capTypePicker.do?fromModel=cap&module=Licenses&isGeneralCAP=Y", ENDITEM, 
		"Name=portlet_language", "Value=en_US", ENDITEM, 
		"Name=refresh_target", "Value=", ENDITEM, 
		"Name=refresh_url", "Value=", ENDITEM, 
		"Name=buttonName", "Value=", ENDITEM, 
		"Name=modeName", "Value=", ENDITEM, 
		"Name=module", "Value=Licenses", ENDITEM, 
		"Name=accelasubmitbuttonname", "Value=", ENDITEM, 
		"Name=itemName", "Value=", ENDITEM, 
		"Name=CurrentViewID", "Value=119", ENDITEM, 
		"Name=exceptionLogID", "Value=", ENDITEM, 
		"Name=generalCAPSearch", "Value=", ENDITEM, 
		"Name=isGeneralCAP", "Value=Y", ENDITEM, 
		"Name=objectName", "Value=", ENDITEM, 
		"Name=CheckBoxName", "Value=", ENDITEM, 
		"Name=MaxNumber", "Value=", ENDITEM, 
		"Name=ExportFileType", "Value=print", ENDITEM, 
		"Name=CurrentViewID", "Value=119", ENDITEM, 
		"Name=sessionIdFromWindow", "Value=PYJmP2wdFUFYzeEcI06OO4MN", ENDITEM, 
		"Name=listID", "Value=", ENDITEM, 
		"Name=printType", "Value=", ENDITEM, 
		"Name=checkBoxValue", "Value=", ENDITEM, 
		"Name=value(capTypeModel*type)", "Value=Complaint", ENDITEM, 
		"Name=value(capTypeModel*subType)", "Value=NA", ENDITEM, 
		"Name=value(capTypeModel*category)", "Value=NA", ENDITEM, 
		"Name=value(selectModuleName)", "Value=Enforcement", ENDITEM, 
		"Name=value(g1AssetGroup)", "Value=", ENDITEM, 
		"Name=value(g1AssetType)", "Value=", ENDITEM, 
		"Name=value(mode)", "Value=add", ENDITEM, 
		"Name=value(srLevel)", "Value=", ENDITEM, 
		"Name=value(capGroupIndex)", "Value=", ENDITEM, 
		"Name=value(capTypeModel*group)", "Value=Enforcement", ENDITEM, 
		"Name=value(capTypeModel)", "Value=Enforcement/Complaint/NA/NA", ENDITEM, 
		"Name=value(fromModel)", "Value=cap", ENDITEM, 
		"Name=value(modelId)", "Value=", ENDITEM, 
		"Name=value(formKey)", "Value=", ENDITEM, 
		"Name=value(GISCommand)", "Value=", ENDITEM, 
		LAST);

	web_submit_data("ajax.do", 
		"Action=https://av-pt-ferrari.accela.com/portlets/i18n/ajax.do?mode=getDateFormat", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t127.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_custom_request("countryStateAJAX.jsp", 
		"URL=https://av-pt-ferrari.accela.com/portlets/commons/address/countryStateAJAX.jsp?statevalue=MI&stateProperty=value(contactsModel2*state)&aaZoneId=aazone-country-state-contact2&stateReadOnly=false&country=&tempModuleName=Enforcement&aaxmlrequest=true&aa_rand=0.9471561785321683&aazones=aazone-country-state-contact2&width=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t128.inf", 
		"Mode=HTML", 
		"Body=aazone-country-state-contact2", 
		LAST);

	web_custom_request("countryStateAJAX.jsp_2", 
		"URL=https://av-pt-ferrari.accela.com/portlets/commons/address/countryStateAJAX.jsp?statevalue=&stateProperty=value(contactsModel2*driverLicenseState)&aaZoneId=aazone-country-driverLicenseState2&stateReadOnly=false&country=&tempModuleName=Enforcement&aaxmlrequest=true&aa_rand=0.3488353844732046&aazones=aazone-country-driverLicenseState2&width=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t129.inf", 
		"Mode=HTML", 
		"Body=aazone-country-driverLicenseState2", 
		LAST);

	web_custom_request("countryStateAJAX.jsp_3", 
		"URL=https://av-pt-ferrari.accela.com/portlets/commons/address/countryStateAJAX.jsp?statevalue=&stateProperty=value(contactsModel2*birthState)&aaZoneId=aazone-birth-state-contact2&stateReadOnly=false&country=&tempModuleName=Enforcement&aaxmlrequest=true&aa_rand=0.45619081356562674&aazones=aazone-birth-state-contact2&width=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t130.inf", 
		"Mode=HTML", 
		"Body=aazone-birth-state-contact2", 
		LAST);

	web_submit_data("empty.jsp_3", 
		"Action=https://av-pt-ferrari.accela.com/portlets/framework/includes/error/empty.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t131.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_url("getXRefContactAddressListBySingleContact3.do", 
		"URL=https://av-pt-ferrari.accela.com/portlets/attachedgis/getXRefContactAddressListBySingleContact3.do?mode=list&type=contact3&currentContactType=&module=Enforcement&showReadOnlyContactAddress=N&fromViewSummary=null", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t132.inf", 
		"Mode=HTML", 
		LAST);

	web_url("getXRefContactAddressListBySingleContact3.do_2", 
		"URL=https://av-pt-ferrari.accela.com/portlets/attachedgis/getXRefContactAddressListBySingleContact3.do?mode=list&type=contact3&currentContactType=&module=Enforcement&showReadOnlyContactAddress=N&fromViewSummary=null", 
		"TargetFrame=_self", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t133.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("empty.jsp_4", 
		"Action=https://av-pt-ferrari.accela.com/portlets/framework/includes/error/empty.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t134.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("appSpecInfoForm.do", 
		"Action=https://av-pt-ferrari.accela.com/portlets/appspecinfo/appSpecInfoForm.do?mode=buildDrillList&module=Enforcement&guideSheetSeq=&singleMode=", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t135.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_custom_request("search.do", 
		"URL=https://av-pt-ferrari.accela.com/portlets/globalSearch/search.do?action=textResources", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/x-json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t136.inf", 
		"Mode=HTML", 
		"Body=categoryName=Portlet - Expression", 
		LAST);

	web_submit_data("regionalSyncMask.do", 
		"Action=https://av-pt-ferrari.accela.com/portlets/regional/regionalSyncMask.do?mode=syncMask&maskType=phoneNumber&referValue=", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t137.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("regionalSyncMask.do_2", 
		"Action=https://av-pt-ferrari.accela.com/portlets/regional/regionalSyncMask.do?mode=syncMask&maskType=phoneNumber&getMsg=Y", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t138.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("regionalSyncMask.do_3", 
		"Action=https://av-pt-ferrari.accela.com/portlets/regional/regionalSyncMask.do?mode=syncMask&maskType=phoneNumber&referValue=", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t139.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("regionalSyncMask.do_4", 
		"Action=https://av-pt-ferrari.accela.com/portlets/regional/regionalSyncMask.do?mode=syncMask&maskType=phoneNumber&referValue=", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t140.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("expression.do", 
		"Action=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=getFields", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t141.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=argumentPKs", "Value=[{\"portletID\":-1,\"viewKey1\":\"\",\"viewKey2\":\"\",\"viewKey3\":\"\"},{\"portletID\":124,\"viewKey1\":\"Complainant\",\"viewKey2\":\"\",\"viewKey3\":\"\"}]", ENDITEM, 
		"Name=expressionPageType", "Value=SPEAR", ENDITEM, 
		"Name=isReload", "Value=false", ENDITEM, 
		"Name=module", "Value=Enforcement", ENDITEM, 
		"Name=capType", "Value=Enforcement/Complaint/NA/NA", ENDITEM, 
		LAST);

	web_custom_request("expression.do_2", 
		"URL=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=execute", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t142.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=&value(CurrentEntryURL)=&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=&modeName=new&module=Enforcement&itemName=&CurrentViewID=&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(paLicenseId)=&isRefreshPartialCondition=N&isAppSpecInfo=1&value(capID*ID1)=&value(capID*ID2)=&value(capID*ID3)=&"
		"singleModeName=COMPLAINT%2BINFORMATION&app_spec_info_COMPLAINT_INFORMATION_Profession=&app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_License_Number=&app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint=&singleModeName=WILLINGNESS%2BTO%2BTESTIFY&singleModeName=COMMUNICATION%2BCONSENT&app_spec_info_COMMUNICATION_CONSENT_Name=&app_spec_info_COMMUNICATION_CONSENT_Address=&"
		"app_spec_info_COMMUNICATION_CONSENT_Telephone_Number=&app_spec_info_COMMUNICATION_CONSENT_Email_Address=&app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You=&singleModeName=PATIENT%2BMEDICAL%2BTREATMENT&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Name=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Date_of_Birth=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%2527s_of_Patient%2527s_SSN=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident=&singleModeName="
		"MEDICAL%2BSTAFF%2BPRIVILEGES&app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation=&singleModeName=POLICE%2BREPORT&app_spec_info_POLICE_REPORT_Police_Agency=&"
		"app_spec_info_POLICE_REPORT_Police_Report_Incident_Number=&singleModeName=CRIMINAL%2BCONVICTIONS&app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee=&singleModeName=SELF%2BREPORTING&app_spec_info_SELF_REPORTING_State_Board_Name=&app_spec_info_SELF_REPORTING_Date_of_Action=&app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action=&singleModeName=ENFORCEMENT%2BROUTING&app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type=&"
		"app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints=on&expression_portlet_to_be_populate=-1&expression_portlet_to_be_populate=-99999&is_ASI_fields_displayed=true&expressionPageType=SPEAR&expression_page_reload_after_submit_or_validate_failed=true&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&"
		"sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(mode)=newsave&value(contactSeqNumber)=&value(contact2*refContactNumber)=&value(contactsModel2*refContactNumber)=&value(serviceProviderCode)=&value(contactsModel2*contactTypeFlag)=individual&value(contactsModel2*accessLevel)=N&value(contactsModel2*contactType)=Complainant&value(contactsModel2*title)=&value(contactsModel2*fullName)=&value(contactsModel2*addressId)=&value(contactsModel2*addressLine1)=&value"
		"(contactsModel2*addressLine2)=&value(contactsModel2*addressLine3)=&value(contactsModel2*city)=&value(contactsModel2*state)=MI&value(contactsModel2*zip)=&value(contactsModel2*countryCode)=&value(contactsModel2*fax)=&value(contactsModel2*contactOnSRChange)=&value(contactsModel2*comment)=&value(maskformat_contactsModel2*maskedSsn)=%23%23%23-%23%23-%23%23%23%23&value(contactsModel2*maskedSsn)=&value(maskformat_contactsModel2*fein)=&value(contactsModel2*fein)=&value(contactsModel2*userID)=&value"
		"(contactsModel2*internalUserFlag)=&value(templateData)=&value(contactsModel2*salutation)=&value(contactsModel2*gender)=&value(contactsModel2*postOfficeBox)=&date(contactsModel2*birthDate)=&value(contactsModel2*namesuffix)=&value(contactsModel2*birthCity)=&value(contactsModel2*birthState)=&value(contactsModel2*birthRegion)=&value(contactsModel2*race)=&date(contactsModel2*deceasedDate)=&value(contactsModel2*passportNumber)=&value(contactsModel2*driverLicenseNbr)=&value"
		"(contactsModel2*driverLicenseState)=&value(contactsModel2*stateIDNbr)=&value(contactsModel2*relation)=&value(contactsModel2*flag)=N&value(contactsModel2*firstName)=&value(contactsModel2*middleName)=&value(contactsModel2*lastName)=&value(contactsModel2*businessName)=&value(contactsModel2*businessName2)=&value(contactsModel2*tradeName)=&ACMask_124_9_value(contactsModel2*phone1_disp)=&ACMask_124_9_value(contactsModel2*phone1)=&ACMask_124_10_value(contactsModel2*phone2_disp)=&ACMask_124_10_value"
		"(contactsModel2*phone2)=&ACMask_124_23_value(contactsModel2*phone3_disp)=&ACMask_124_23_value(contactsModel2*phone3)=&value(contactsModel2*preferredChannel)=&value(contactsModel2*email)=&value(serviceProviderCode)=&value(ID1)=&value(ID2)=&value(ID3)=&value(mode)=New&value(modePro)=add&valuetextarea15=&sourcetextarea15=&layouttextarea15=null&contactsModel2*uiuid=15&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow="
		"PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&endDate=&chooseItems=&effectiveDate=&isContact3=1&contact3ViewID=124&isContact3Validation=N&isContact3Required=Y&contact3AccessRight=F&contact3ContactNumber=null&value(mode)=add&value(srTest)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capID)=&value(capDetailModel*shortNotes)=&value(capModel*specialText)=&value(capWorkDescriptionModel*description)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value"
		"(capDetailModel*creatorDeptAlias)=&value(capDetailModel*asgnDept)=&value(capModel*capSubType)=&date(capDetailModel*closedDate)=&date(capDetailModel*asgnDate)=&date(capDetailModel*completeDate)=&date(capDetailModel*scheduledDate)=&value(capDetailModel*scheduledTime)=&value(capDetailModel*completeDept)=&value(capDetailModel*completeStaff)=&value(capDetailModel*closedDept)=&value(capDetailModel*closedBy)=&value(capModel*capStatus)=Submitted&value(capDetailModel*asgnStaff)=&value"
		"(capDetailModel*priority)=&value(capDetailModel*reportedChannel)=Call%20Center&value(capDetailModel*severity)=&value(capModel*altID)=&value(jobValue)=&value(capDetailModel*totalFee)=0.0&value(capDetailModel*totalPay)=0.0&value(capDetailModel*balance)=0.0&value(capDetailModel*estProdUnits)=0.0&value(capDetailModel*actualProdUnits)=0.0&value(capDetailModel*estCostPerUnit)=&value(capDetailModel*costPerUnit)=&value(capDetailModel*estJobCost)=&value(blank1)=&value(blank2)=&value(blank3)=&value(blank4)="
		"&value(blank5)=&value(capDetailModel*totalJobCost)=&value(b1ExpirationModel*expStatus)=&date(b1ExpirationModel*expDate)=&date(capModel*reportedDate)=08%2F28%2F2018&value(capModel*reportedTime)=&value(capDetailModel*anonymousFlag)=&value(capDetailModel*referenceType)=&value(capDetailModel*enforceDept)=&value(capDetailModel*enforceOfficerName)=&value(capDetailModel*enforceOfficerId)=&value(capDetailModel*inspectorDept)=&value(capDetailModel*inspectorName)=&value(capDetailModel*inspectorId)=&date"
		"(capDetailModel*appearanceDate)=&value(capDetailModel*appearanceDayOfWeek)=&value(capDetailModel*infractionFlag)=&value(capDetailModel*misdemeanorFlag)=&value(capDetailModel*offnWitnessedFlag)=&value(capDetailModel*dfndtSignatureFlag)=&value(capDetailModel*bookingFlag)=&value(capDetailModel*statusReason)=&date(capDetailModel*firstIssuedDate)=&value(capDetailModel*undistributedCost)=&value(capDetailModel*url)=&value(capModel*pendingValidation)=&date(capModel*fileDate)=08%2F28%2F2018&editPar=2112&"
		"allViewIDGroup=%2C124%2C225&viewGroup=%2C124%2C225&formGroup=%2Ccontact3DetailForm%2CcapDetailForm&fromModel=cap&modelId=&fromEditPartialCap=&fromMode=newSingle&GISCommand=null&isAddressList=&isParcelList=&isOwnerList=&isProfessionalList=&value(contactValidatePassed)=true&value(createCapForParcelType)=&SKIP_EMSE_FLAG=N&isFromAssetList=null%20&isValidationFailed=null&isValidated=null&_viewstate_=%7B%22empty%22%3Afalse%2C%22fields%22%3A%7B%22value(contactsModel2*maskedSsn)"
		"%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22SSN%22%7D%2C%22value(contactsModel2*fein)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22FEIN%22%7D%7D%7D&accelasubmitbuttonname=Previous&callBack=&variableKey=onLoad&refAPONumber=undefined&argumentPKs="
		"%5B%7B%22portletID%22%3A-1%2C%22viewKey1%22%3A%22%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%2C%7B%22portletID%22%3A124%2C%22viewKey1%22%3A%22Complainant%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%5D&expressionPageType=SPEAR&mode=execute", 
		LAST);

	lr_end_transaction("MILARA_TC3_03_SelectRecordType_OpenSpearForm",LR_AUTO);

	lr_think_time(14);

	web_url("session.do_9", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1&module=Enforcement", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t143.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	web_url("session.do_10", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1&module=Enforcement", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t144.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("expression.do_3", 
		"URL=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=execute", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t145.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=&value(CurrentEntryURL)=&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=&modeName=new&module=Enforcement&itemName=&CurrentViewID=&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(paLicenseId)=&isRefreshPartialCondition=N&isAppSpecInfo=1&value(capID*ID1)=&value(capID*ID2)=&value(capID*ID3)=&"
		"singleModeName=COMPLAINT%2BINFORMATION&app_spec_info_COMPLAINT_INFORMATION_Profession=Nursing&app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee=performance&app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_License_Number=&app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint=performance&app_spec_info_COMPLAINT_INFORMATION_Is_this_drug_related%253F=No&singleModeName=WILLINGNESS%2BTO%2BTESTIFY&"
		"app_spec_info_WILLINGNESS_TO_TESTIFY_Are_you_willing_to_testify_in_a_hearing=No&singleModeName=COMMUNICATION%2BCONSENT&app_spec_info_COMMUNICATION_CONSENT_I_authorize_the_Department_to_release_my_name_and_all_relevant_information_pertaining_to_this_allega=No&app_spec_info_COMMUNICATION_CONSENT_Do_you_authorize_another_person_to_communicate_with_the_department_regarding_your_complaint=No&app_spec_info_COMMUNICATION_CONSENT_Name=&app_spec_info_COMMUNICATION_CONSENT_Address=&"
		"app_spec_info_COMMUNICATION_CONSENT_Telephone_Number=&app_spec_info_COMMUNICATION_CONSENT_Email_Address=&app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You=&singleModeName=PATIENT%2BMEDICAL%2BTREATMENT&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Name=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Date_of_Birth=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%2527s_of_Patient%2527s_SSN=0&app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident=&singleModeName="
		"MEDICAL%2BSTAFF%2BPRIVILEGES&app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation=&singleModeName=POLICE%2BREPORT&app_spec_info_POLICE_REPORT_Police_Agency=&"
		"app_spec_info_POLICE_REPORT_Police_Report_Incident_Number=&singleModeName=CRIMINAL%2BCONVICTIONS&app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee=&singleModeName=SELF%2BREPORTING&app_spec_info_SELF_REPORTING_State_Board_Name=&app_spec_info_SELF_REPORTING_Date_of_Action=&app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action=&singleModeName=ENFORCEMENT%2BROUTING&app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type=&"
		"app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints=on&expression_portlet_to_be_populate=-1&expression_portlet_to_be_populate=-99999&is_ASI_fields_displayed=true&expressionPageType=SPEAR&expression_page_reload_after_submit_or_validate_failed=true&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&"
		"sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(mode)=newsave&value(contactSeqNumber)=&value(contact2*refContactNumber)=&value(contactsModel2*refContactNumber)=&value(serviceProviderCode)=&value(contactsModel2*contactTypeFlag)=individual&value(contactsModel2*accessLevel)=N&value(contactsModel2*contactType)=Complainant&value(contactsModel2*title)=&value(contactsModel2*fullName)=&value(contactsModel2*addressId)=&value(contactsModel2*addressLine1)=&value"
		"(contactsModel2*addressLine2)=&value(contactsModel2*addressLine3)=&value(contactsModel2*city)=&value(contactsModel2*state)=MI&value(contactsModel2*zip)=&value(contactsModel2*countryCode)=&value(contactsModel2*fax)=&value(contactsModel2*contactOnSRChange)=&value(contactsModel2*comment)=&value(maskformat_contactsModel2*maskedSsn)=%23%23%23-%23%23-%23%23%23%23&value(contactsModel2*maskedSsn)=&value(maskformat_contactsModel2*fein)=&value(contactsModel2*fein)=&value(contactsModel2*userID)=&value"
		"(contactsModel2*internalUserFlag)=&value(templateData)=&value(contactsModel2*salutation)=&value(contactsModel2*gender)=&value(contactsModel2*postOfficeBox)=&date(contactsModel2*birthDate)=&value(contactsModel2*namesuffix)=&value(contactsModel2*birthCity)=&value(contactsModel2*birthState)=&value(contactsModel2*birthRegion)=&value(contactsModel2*race)=&date(contactsModel2*deceasedDate)=&value(contactsModel2*passportNumber)=&value(contactsModel2*driverLicenseNbr)=&value"
		"(contactsModel2*driverLicenseState)=&value(contactsModel2*stateIDNbr)=&value(contactsModel2*relation)=&value(contactsModel2*flag)=N&value(contactsModel2*firstName)=&value(contactsModel2*middleName)=&value(contactsModel2*lastName)=&value(contactsModel2*businessName)=&value(contactsModel2*businessName2)=&value(contactsModel2*tradeName)=&ACMask_124_9_value(contactsModel2*phone1_disp)=&ACMask_124_9_value(contactsModel2*phone1)=&ACMask_124_10_value(contactsModel2*phone2_disp)=&ACMask_124_10_value"
		"(contactsModel2*phone2)=&ACMask_124_23_value(contactsModel2*phone3_disp)=&ACMask_124_23_value(contactsModel2*phone3)=&value(contactsModel2*preferredChannel)=&value(contactsModel2*email)=&value(serviceProviderCode)=&value(ID1)=&value(ID2)=&value(ID3)=&value(mode)=New&value(modePro)=add&valuetextarea15=&sourcetextarea15=&layouttextarea15=null&contactsModel2*uiuid=15&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow="
		"PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&endDate=&chooseItems=&effectiveDate=&isContact3=1&contact3ViewID=124&isContact3Validation=N&isContact3Required=Y&contact3AccessRight=F&contact3ContactNumber=null&value(mode)=add&value(srTest)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capID)=&value(capDetailModel*shortNotes)=&value(capModel*specialText)=&value(capWorkDescriptionModel*description)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value"
		"(capDetailModel*creatorDeptAlias)=&value(capDetailModel*asgnDept)=&value(capModel*capSubType)=&date(capDetailModel*closedDate)=&date(capDetailModel*asgnDate)=&date(capDetailModel*completeDate)=&date(capDetailModel*scheduledDate)=&value(capDetailModel*scheduledTime)=&value(capDetailModel*completeDept)=&value(capDetailModel*completeStaff)=&value(capDetailModel*closedDept)=&value(capDetailModel*closedBy)=&value(capModel*capStatus)=Submitted&value(capDetailModel*asgnStaff)=&value"
		"(capDetailModel*priority)=&value(capDetailModel*reportedChannel)=Call%20Center&value(capDetailModel*severity)=&value(capModel*altID)=&value(jobValue)=&value(capDetailModel*totalFee)=0.0&value(capDetailModel*totalPay)=0.0&value(capDetailModel*balance)=0.0&value(capDetailModel*estProdUnits)=0.0&value(capDetailModel*actualProdUnits)=0.0&value(capDetailModel*estCostPerUnit)=&value(capDetailModel*costPerUnit)=&value(capDetailModel*estJobCost)=&value(blank1)=&value(blank2)=&value(blank3)=&value(blank4)="
		"&value(blank5)=&value(capDetailModel*totalJobCost)=&value(b1ExpirationModel*expStatus)=&date(b1ExpirationModel*expDate)=&date(capModel*reportedDate)=08%2F28%2F2018&value(capModel*reportedTime)=&value(capDetailModel*anonymousFlag)=&value(capDetailModel*referenceType)=&value(capDetailModel*enforceDept)=&value(capDetailModel*enforceOfficerName)=&value(capDetailModel*enforceOfficerId)=&value(capDetailModel*inspectorDept)=&value(capDetailModel*inspectorName)=&value(capDetailModel*inspectorId)=&date"
		"(capDetailModel*appearanceDate)=&value(capDetailModel*appearanceDayOfWeek)=&value(capDetailModel*infractionFlag)=&value(capDetailModel*misdemeanorFlag)=&value(capDetailModel*offnWitnessedFlag)=&value(capDetailModel*dfndtSignatureFlag)=&value(capDetailModel*bookingFlag)=&value(capDetailModel*statusReason)=&date(capDetailModel*firstIssuedDate)=&value(capDetailModel*undistributedCost)=&value(capDetailModel*url)=&value(capModel*pendingValidation)=&date(capModel*fileDate)=08%2F28%2F2018&editPar=2112&"
		"allViewIDGroup=%2C124%2C225&viewGroup=%2C124%2C225&formGroup=%2Ccontact3DetailForm%2CcapDetailForm&fromModel=cap&modelId=&fromEditPartialCap=&fromMode=newSingle&GISCommand=null&isAddressList=&isParcelList=&isOwnerList=&isProfessionalList=&value(contactValidatePassed)=true&value(createCapForParcelType)=&SKIP_EMSE_FLAG=N&isFromAssetList=null%20&isValidationFailed=null&isValidated=null&_viewstate_=%7B%22empty%22%3Afalse%2C%22fields%22%3A%7B%22value(contactsModel2*maskedSsn)"
		"%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22SSN%22%7D%2C%22value(contactsModel2*fein)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22FEIN%22%7D%7D%7D&accelasubmitbuttonname=Previous&callBack=&variableKey=ASI%3A%3ACOMMUNICATION%20CONSENT%3A%3ADo%20you%20authorize%20another%20person%20to%20communicate%20with%20the%20department%20regarding%20your%20complaint&refAPONumber=undefined&argumentPKs="
		"%5B%7B%22portletID%22%3A-1%2C%22viewKey1%22%3A%22%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%2C%7B%22portletID%22%3A124%2C%22viewKey1%22%3A%22Complainant%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%5D&expressionPageType=SPEAR&mode=execute", 
		LAST);

	web_custom_request("expression.do_4", 
		"URL=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=execute", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t146.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=&value(CurrentEntryURL)=&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=&modeName=new&module=Enforcement&itemName=&CurrentViewID=&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(paLicenseId)=&isRefreshPartialCondition=N&isAppSpecInfo=1&value(capID*ID1)=&value(capID*ID2)=&value(capID*ID3)=&"
		"singleModeName=COMPLAINT%2BINFORMATION&app_spec_info_COMPLAINT_INFORMATION_Profession=Nursing&app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee=performance&app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_License_Number=&app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint=performance&app_spec_info_COMPLAINT_INFORMATION_Is_this_drug_related%253F=No&singleModeName=WILLINGNESS%2BTO%2BTESTIFY&"
		"app_spec_info_WILLINGNESS_TO_TESTIFY_Are_you_willing_to_testify_in_a_hearing=No&singleModeName=COMMUNICATION%2BCONSENT&app_spec_info_COMMUNICATION_CONSENT_I_authorize_the_Department_to_release_my_name_and_all_relevant_information_pertaining_to_this_allega=No&app_spec_info_COMMUNICATION_CONSENT_Do_you_authorize_another_person_to_communicate_with_the_department_regarding_your_complaint=No&app_spec_info_COMMUNICATION_CONSENT_Name=&app_spec_info_COMMUNICATION_CONSENT_Address=&"
		"app_spec_info_COMMUNICATION_CONSENT_Telephone_Number=&app_spec_info_COMMUNICATION_CONSENT_Email_Address=&app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You=&singleModeName=PATIENT%2BMEDICAL%2BTREATMENT&app_spec_info_PATIENT_MEDICAL_TREATMENT_Is_your_complaint_regarding_the_medical_treatment_of_a_patient=No&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Name=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Date_of_Birth=&"
		"app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%2527s_of_Patient%2527s_SSN=0&app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident=&singleModeName=MEDICAL%2BSTAFF%2BPRIVILEGES&app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension=&"
		"app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation=&singleModeName=POLICE%2BREPORT&app_spec_info_POLICE_REPORT_Police_Agency=&app_spec_info_POLICE_REPORT_Police_Report_Incident_Number=&singleModeName=CRIMINAL%2BCONVICTIONS&app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee=&singleModeName=SELF%2BREPORTING&app_spec_info_SELF_REPORTING_State_Board_Name=&app_spec_info_SELF_REPORTING_Date_of_Action=&"
		"app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action=&singleModeName=ENFORCEMENT%2BROUTING&app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type=&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints=on&expression_portlet_to_be_populate=-1&expression_portlet_to_be_populate=-99999&is_ASI_fields_displayed=true&expressionPageType=SPEAR&"
		"expression_page_reload_after_submit_or_validate_failed=true&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(mode)=newsave&value(contactSeqNumber)=&value(contact2*refContactNumber)=&value(contactsModel2*refContactNumber)=&value(serviceProviderCode)=&value(contactsModel2*contactTypeFlag)=individual&value(contactsModel2*accessLevel)=N&value"
		"(contactsModel2*contactType)=Complainant&value(contactsModel2*title)=&value(contactsModel2*fullName)=&value(contactsModel2*addressId)=&value(contactsModel2*addressLine1)=&value(contactsModel2*addressLine2)=&value(contactsModel2*addressLine3)=&value(contactsModel2*city)=&value(contactsModel2*state)=MI&value(contactsModel2*zip)=&value(contactsModel2*countryCode)=&value(contactsModel2*fax)=&value(contactsModel2*contactOnSRChange)=&value(contactsModel2*comment)=&value"
		"(maskformat_contactsModel2*maskedSsn)=%23%23%23-%23%23-%23%23%23%23&value(contactsModel2*maskedSsn)=&value(maskformat_contactsModel2*fein)=&value(contactsModel2*fein)=&value(contactsModel2*userID)=&value(contactsModel2*internalUserFlag)=&value(templateData)=&value(contactsModel2*salutation)=&value(contactsModel2*gender)=&value(contactsModel2*postOfficeBox)=&date(contactsModel2*birthDate)=&value(contactsModel2*namesuffix)=&value(contactsModel2*birthCity)=&value(contactsModel2*birthState)=&value"
		"(contactsModel2*birthRegion)=&value(contactsModel2*race)=&date(contactsModel2*deceasedDate)=&value(contactsModel2*passportNumber)=&value(contactsModel2*driverLicenseNbr)=&value(contactsModel2*driverLicenseState)=&value(contactsModel2*stateIDNbr)=&value(contactsModel2*relation)=&value(contactsModel2*flag)=N&value(contactsModel2*firstName)=&value(contactsModel2*middleName)=&value(contactsModel2*lastName)=&value(contactsModel2*businessName)=&value(contactsModel2*businessName2)=&value"
		"(contactsModel2*tradeName)=&ACMask_124_9_value(contactsModel2*phone1_disp)=&ACMask_124_9_value(contactsModel2*phone1)=&ACMask_124_10_value(contactsModel2*phone2_disp)=&ACMask_124_10_value(contactsModel2*phone2)=&ACMask_124_23_value(contactsModel2*phone3_disp)=&ACMask_124_23_value(contactsModel2*phone3)=&value(contactsModel2*preferredChannel)=&value(contactsModel2*email)=&value(serviceProviderCode)=&value(ID1)=&value(ID2)=&value(ID3)=&value(mode)=New&value(modePro)=add&valuetextarea15=&"
		"sourcetextarea15=&layouttextarea15=null&contactsModel2*uiuid=15&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&endDate=&chooseItems=&effectiveDate=&isContact3=1&contact3ViewID=124&isContact3Validation=N&isContact3Required=Y&contact3AccessRight=F&contact3ContactNumber=null&value(mode)=add&value(srTest)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value"
		"(capID)=&value(capDetailModel*shortNotes)=&value(capModel*specialText)=&value(capWorkDescriptionModel*description)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capDetailModel*creatorDeptAlias)=&value(capDetailModel*asgnDept)=&value(capModel*capSubType)=&date(capDetailModel*closedDate)=&date(capDetailModel*asgnDate)=&date(capDetailModel*completeDate)=&date(capDetailModel*scheduledDate)=&value(capDetailModel*scheduledTime)=&value(capDetailModel*completeDept)=&value"
		"(capDetailModel*completeStaff)=&value(capDetailModel*closedDept)=&value(capDetailModel*closedBy)=&value(capModel*capStatus)=Submitted&value(capDetailModel*asgnStaff)=&value(capDetailModel*priority)=&value(capDetailModel*reportedChannel)=Call%20Center&value(capDetailModel*severity)=&value(capModel*altID)=&value(jobValue)=&value(capDetailModel*totalFee)=0.0&value(capDetailModel*totalPay)=0.0&value(capDetailModel*balance)=0.0&value(capDetailModel*estProdUnits)=0.0&value(capDetailModel*actualProdUnits"
		")=0.0&value(capDetailModel*estCostPerUnit)=&value(capDetailModel*costPerUnit)=&value(capDetailModel*estJobCost)=&value(blank1)=&value(blank2)=&value(blank3)=&value(blank4)=&value(blank5)=&value(capDetailModel*totalJobCost)=&value(b1ExpirationModel*expStatus)=&date(b1ExpirationModel*expDate)=&date(capModel*reportedDate)=08%2F28%2F2018&value(capModel*reportedTime)=&value(capDetailModel*anonymousFlag)=&value(capDetailModel*referenceType)=&value(capDetailModel*enforceDept)=&value"
		"(capDetailModel*enforceOfficerName)=&value(capDetailModel*enforceOfficerId)=&value(capDetailModel*inspectorDept)=&value(capDetailModel*inspectorName)=&value(capDetailModel*inspectorId)=&date(capDetailModel*appearanceDate)=&value(capDetailModel*appearanceDayOfWeek)=&value(capDetailModel*infractionFlag)=&value(capDetailModel*misdemeanorFlag)=&value(capDetailModel*offnWitnessedFlag)=&value(capDetailModel*dfndtSignatureFlag)=&value(capDetailModel*bookingFlag)=&value(capDetailModel*statusReason)=&date"
		"(capDetailModel*firstIssuedDate)=&value(capDetailModel*undistributedCost)=&value(capDetailModel*url)=&value(capModel*pendingValidation)=&date(capModel*fileDate)=08%2F28%2F2018&editPar=2112&allViewIDGroup=%2C124%2C225&viewGroup=%2C124%2C225&formGroup=%2Ccontact3DetailForm%2CcapDetailForm&fromModel=cap&modelId=&fromEditPartialCap=&fromMode=newSingle&GISCommand=null&isAddressList=&isParcelList=&isOwnerList=&isProfessionalList=&value(contactValidatePassed)=true&value(createCapForParcelType)=&"
		"SKIP_EMSE_FLAG=N&isFromAssetList=null%20&isValidationFailed=null&isValidated=null&_viewstate_=%7B%22empty%22%3Afalse%2C%22fields%22%3A%7B%22value(contactsModel2*maskedSsn)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22SSN%22%7D%2C%22value(contactsModel2*fein)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22FEIN%22%7D%7D%7D&accelasubmitbuttonname=Previous&callBack=&variableKey="
		"ASI%3A%3APATIENT%20MEDICAL%20TREATMENT%3A%3AIs%20your%20complaint%20regarding%20the%20medical%20treatment%20of%20a%20patient&refAPONumber=undefined&argumentPKs=%5B%7B%22portletID%22%3A-1%2C%22viewKey1%22%3A%22%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%2C%7B%22portletID%22%3A124%2C%22viewKey1%22%3A%22Complainant%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%5D&expressionPageType=SPEAR&mode=execute", 
		LAST);

	lr_think_time(61);

	web_url("session.do_11", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1&module=Enforcement", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t147.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("expression.do_5", 
		"URL=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=execute", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t148.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=&value(CurrentEntryURL)=&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=&modeName=new&module=Enforcement&itemName=&CurrentViewID=&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(paLicenseId)=&isRefreshPartialCondition=N&isAppSpecInfo=1&value(capID*ID1)=&value(capID*ID2)=&value(capID*ID3)=&"
		"singleModeName=COMPLAINT%2BINFORMATION&app_spec_info_COMPLAINT_INFORMATION_Profession=Nursing&app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee=performance&app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_License_Number=&app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint=performance&app_spec_info_COMPLAINT_INFORMATION_Is_this_drug_related%253F=No&singleModeName=WILLINGNESS%2BTO%2BTESTIFY&"
		"app_spec_info_WILLINGNESS_TO_TESTIFY_Are_you_willing_to_testify_in_a_hearing=No&singleModeName=COMMUNICATION%2BCONSENT&app_spec_info_COMMUNICATION_CONSENT_I_authorize_the_Department_to_release_my_name_and_all_relevant_information_pertaining_to_this_allega=No&app_spec_info_COMMUNICATION_CONSENT_Do_you_authorize_another_person_to_communicate_with_the_department_regarding_your_complaint=No&app_spec_info_COMMUNICATION_CONSENT_Name=&app_spec_info_COMMUNICATION_CONSENT_Address=&"
		"app_spec_info_COMMUNICATION_CONSENT_Telephone_Number=&app_spec_info_COMMUNICATION_CONSENT_Email_Address=&app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You=&singleModeName=PATIENT%2BMEDICAL%2BTREATMENT&app_spec_info_PATIENT_MEDICAL_TREATMENT_Is_your_complaint_regarding_the_medical_treatment_of_a_patient=No&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Name=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Date_of_Birth=&"
		"app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%2527s_of_Patient%2527s_SSN=0&app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident=&singleModeName=MEDICAL%2BSTAFF%2BPRIVILEGES&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Are_you_reporting_a_change_in_medical_staff_privileges=No&app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff=&"
		"app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation=&singleModeName=POLICE%2BREPORT&app_spec_info_POLICE_REPORT_Police_Agency=&app_spec_info_POLICE_REPORT_Police_Report_Incident_Number=&singleModeName=CRIMINAL%2BCONVICTIONS&app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee=&singleModeName="
		"SELF%2BREPORTING&app_spec_info_SELF_REPORTING_State_Board_Name=&app_spec_info_SELF_REPORTING_Date_of_Action=&app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action=&singleModeName=ENFORCEMENT%2BROUTING&app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type=&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints=on&expression_portlet_to_be_populate=-1&"
		"expression_portlet_to_be_populate=-99999&is_ASI_fields_displayed=true&expressionPageType=SPEAR&expression_page_reload_after_submit_or_validate_failed=true&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(mode)=newsave&value(contactSeqNumber)=&value(contact2*refContactNumber)=&value(contactsModel2*refContactNumber)=&value(serviceProviderCode)=&value"
		"(contactsModel2*contactTypeFlag)=individual&value(contactsModel2*accessLevel)=N&value(contactsModel2*contactType)=Complainant&value(contactsModel2*title)=&value(contactsModel2*fullName)=&value(contactsModel2*addressId)=&value(contactsModel2*addressLine1)=&value(contactsModel2*addressLine2)=&value(contactsModel2*addressLine3)=&value(contactsModel2*city)=&value(contactsModel2*state)=MI&value(contactsModel2*zip)=&value(contactsModel2*countryCode)=&value(contactsModel2*fax)=&value"
		"(contactsModel2*contactOnSRChange)=&value(contactsModel2*comment)=&value(maskformat_contactsModel2*maskedSsn)=%23%23%23-%23%23-%23%23%23%23&value(contactsModel2*maskedSsn)=&value(maskformat_contactsModel2*fein)=&value(contactsModel2*fein)=&value(contactsModel2*userID)=&value(contactsModel2*internalUserFlag)=&value(templateData)=&value(contactsModel2*salutation)=&value(contactsModel2*gender)=&value(contactsModel2*postOfficeBox)=&date(contactsModel2*birthDate)=&value(contactsModel2*namesuffix)=&"
		"value(contactsModel2*birthCity)=&value(contactsModel2*birthState)=&value(contactsModel2*birthRegion)=&value(contactsModel2*race)=&date(contactsModel2*deceasedDate)=&value(contactsModel2*passportNumber)=&value(contactsModel2*driverLicenseNbr)=&value(contactsModel2*driverLicenseState)=&value(contactsModel2*stateIDNbr)=&value(contactsModel2*relation)=&value(contactsModel2*flag)=N&value(contactsModel2*firstName)=&value(contactsModel2*middleName)=&value(contactsModel2*lastName)=&value"
		"(contactsModel2*businessName)=&value(contactsModel2*businessName2)=&value(contactsModel2*tradeName)=&ACMask_124_9_value(contactsModel2*phone1_disp)=&ACMask_124_9_value(contactsModel2*phone1)=&ACMask_124_10_value(contactsModel2*phone2_disp)=&ACMask_124_10_value(contactsModel2*phone2)=&ACMask_124_23_value(contactsModel2*phone3_disp)=&ACMask_124_23_value(contactsModel2*phone3)=&value(contactsModel2*preferredChannel)=&value(contactsModel2*email)=&value(serviceProviderCode)=&value(ID1)=&value(ID2)=&"
		"value(ID3)=&value(mode)=New&value(modePro)=add&valuetextarea15=&sourcetextarea15=&layouttextarea15=null&contactsModel2*uiuid=15&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&endDate=&chooseItems=&effectiveDate=&isContact3=1&contact3ViewID=124&isContact3Validation=N&isContact3Required=Y&contact3AccessRight=F&contact3ContactNumber=null&value(mode)=add&value"
		"(srTest)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capID)=&value(capDetailModel*shortNotes)=&value(capModel*specialText)=&value(capWorkDescriptionModel*description)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capDetailModel*creatorDeptAlias)=&value(capDetailModel*asgnDept)=&value(capModel*capSubType)=&date(capDetailModel*closedDate)=&date(capDetailModel*asgnDate)=&date(capDetailModel*completeDate)=&date(capDetailModel*scheduledDate)=&value(capDetailModel*scheduledTime)=&"
		"value(capDetailModel*completeDept)=&value(capDetailModel*completeStaff)=&value(capDetailModel*closedDept)=&value(capDetailModel*closedBy)=&value(capModel*capStatus)=Submitted&value(capDetailModel*asgnStaff)=&value(capDetailModel*priority)=&value(capDetailModel*reportedChannel)=Call%20Center&value(capDetailModel*severity)=&value(capModel*altID)=&value(jobValue)=&value(capDetailModel*totalFee)=0.0&value(capDetailModel*totalPay)=0.0&value(capDetailModel*balance)=0.0&value(capDetailModel*estProdUnits)"
		"=0.0&value(capDetailModel*actualProdUnits)=0.0&value(capDetailModel*estCostPerUnit)=&value(capDetailModel*costPerUnit)=&value(capDetailModel*estJobCost)=&value(blank1)=&value(blank2)=&value(blank3)=&value(blank4)=&value(blank5)=&value(capDetailModel*totalJobCost)=&value(b1ExpirationModel*expStatus)=&date(b1ExpirationModel*expDate)=&date(capModel*reportedDate)=08%2F28%2F2018&value(capModel*reportedTime)=&value(capDetailModel*anonymousFlag)=&value(capDetailModel*referenceType)=&value"
		"(capDetailModel*enforceDept)=&value(capDetailModel*enforceOfficerName)=&value(capDetailModel*enforceOfficerId)=&value(capDetailModel*inspectorDept)=&value(capDetailModel*inspectorName)=&value(capDetailModel*inspectorId)=&date(capDetailModel*appearanceDate)=&value(capDetailModel*appearanceDayOfWeek)=&value(capDetailModel*infractionFlag)=&value(capDetailModel*misdemeanorFlag)=&value(capDetailModel*offnWitnessedFlag)=&value(capDetailModel*dfndtSignatureFlag)=&value(capDetailModel*bookingFlag)=&value"
		"(capDetailModel*statusReason)=&date(capDetailModel*firstIssuedDate)=&value(capDetailModel*undistributedCost)=&value(capDetailModel*url)=&value(capModel*pendingValidation)=&date(capModel*fileDate)=08%2F28%2F2018&editPar=2112&allViewIDGroup=%2C124%2C225&viewGroup=%2C124%2C225&formGroup=%2Ccontact3DetailForm%2CcapDetailForm&fromModel=cap&modelId=&fromEditPartialCap=&fromMode=newSingle&GISCommand=null&isAddressList=&isParcelList=&isOwnerList=&isProfessionalList=&value(contactValidatePassed)=true&value"
		"(createCapForParcelType)=&SKIP_EMSE_FLAG=N&isFromAssetList=null%20&isValidationFailed=null&isValidated=null&_viewstate_=%7B%22empty%22%3Afalse%2C%22fields%22%3A%7B%22value(contactsModel2*maskedSsn)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22SSN%22%7D%2C%22value(contactsModel2*fein)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22FEIN%22%7D%7D%7D&accelasubmitbuttonname=Previous&callBack=&variableKey="
		"ASI%3A%3AMEDICAL%20STAFF%20PRIVILEGES%3A%3AAre%20you%20reporting%20a%20change%20in%20medical%20staff%20privileges&refAPONumber=undefined&argumentPKs=%5B%7B%22portletID%22%3A-1%2C%22viewKey1%22%3A%22%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%2C%7B%22portletID%22%3A124%2C%22viewKey1%22%3A%22Complainant%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%5D&expressionPageType=SPEAR&mode=execute", 
		LAST);

	web_custom_request("expression.do_6", 
		"URL=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=execute", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t149.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=&value(CurrentEntryURL)=&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=&modeName=new&module=Enforcement&itemName=&CurrentViewID=&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(paLicenseId)=&isRefreshPartialCondition=N&isAppSpecInfo=1&value(capID*ID1)=&value(capID*ID2)=&value(capID*ID3)=&"
		"singleModeName=COMPLAINT%2BINFORMATION&app_spec_info_COMPLAINT_INFORMATION_Profession=Nursing&app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee=performance&app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_License_Number=&app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint=performance&app_spec_info_COMPLAINT_INFORMATION_Is_this_drug_related%253F=No&singleModeName=WILLINGNESS%2BTO%2BTESTIFY&"
		"app_spec_info_WILLINGNESS_TO_TESTIFY_Are_you_willing_to_testify_in_a_hearing=No&singleModeName=COMMUNICATION%2BCONSENT&app_spec_info_COMMUNICATION_CONSENT_I_authorize_the_Department_to_release_my_name_and_all_relevant_information_pertaining_to_this_allega=No&app_spec_info_COMMUNICATION_CONSENT_Do_you_authorize_another_person_to_communicate_with_the_department_regarding_your_complaint=No&app_spec_info_COMMUNICATION_CONSENT_Name=&app_spec_info_COMMUNICATION_CONSENT_Address=&"
		"app_spec_info_COMMUNICATION_CONSENT_Telephone_Number=&app_spec_info_COMMUNICATION_CONSENT_Email_Address=&app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You=&singleModeName=PATIENT%2BMEDICAL%2BTREATMENT&app_spec_info_PATIENT_MEDICAL_TREATMENT_Is_your_complaint_regarding_the_medical_treatment_of_a_patient=No&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Name=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Date_of_Birth=&"
		"app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%2527s_of_Patient%2527s_SSN=0&app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident=&singleModeName=MEDICAL%2BSTAFF%2BPRIVILEGES&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Are_you_reporting_a_change_in_medical_staff_privileges=No&app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff=&"
		"app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation=&singleModeName=POLICE%2BREPORT&app_spec_info_POLICE_REPORT_Is_there_a_police_report=No&app_spec_info_POLICE_REPORT_Police_Agency=&app_spec_info_POLICE_REPORT_Police_Report_Incident_Number=&singleModeName=CRIMINAL%2BCONVICTIONS&"
		"app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee=&singleModeName=SELF%2BREPORTING&app_spec_info_SELF_REPORTING_State_Board_Name=&app_spec_info_SELF_REPORTING_Date_of_Action=&app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action=&singleModeName=ENFORCEMENT%2BROUTING&app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type=&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value=Y&"
		"app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints=on&expression_portlet_to_be_populate=-1&expression_portlet_to_be_populate=-99999&is_ASI_fields_displayed=true&expressionPageType=SPEAR&expression_page_reload_after_submit_or_validate_failed=true&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&"
		"value(mode)=newsave&value(contactSeqNumber)=&value(contact2*refContactNumber)=&value(contactsModel2*refContactNumber)=&value(serviceProviderCode)=&value(contactsModel2*contactTypeFlag)=individual&value(contactsModel2*accessLevel)=N&value(contactsModel2*contactType)=Complainant&value(contactsModel2*title)=&value(contactsModel2*fullName)=&value(contactsModel2*addressId)=&value(contactsModel2*addressLine1)=&value(contactsModel2*addressLine2)=&value(contactsModel2*addressLine3)=&value"
		"(contactsModel2*city)=&value(contactsModel2*state)=MI&value(contactsModel2*zip)=&value(contactsModel2*countryCode)=&value(contactsModel2*fax)=&value(contactsModel2*contactOnSRChange)=&value(contactsModel2*comment)=&value(maskformat_contactsModel2*maskedSsn)=%23%23%23-%23%23-%23%23%23%23&value(contactsModel2*maskedSsn)=&value(maskformat_contactsModel2*fein)=&value(contactsModel2*fein)=&value(contactsModel2*userID)=&value(contactsModel2*internalUserFlag)=&value(templateData)=&value"
		"(contactsModel2*salutation)=&value(contactsModel2*gender)=&value(contactsModel2*postOfficeBox)=&date(contactsModel2*birthDate)=&value(contactsModel2*namesuffix)=&value(contactsModel2*birthCity)=&value(contactsModel2*birthState)=&value(contactsModel2*birthRegion)=&value(contactsModel2*race)=&date(contactsModel2*deceasedDate)=&value(contactsModel2*passportNumber)=&value(contactsModel2*driverLicenseNbr)=&value(contactsModel2*driverLicenseState)=&value(contactsModel2*stateIDNbr)=&value"
		"(contactsModel2*relation)=&value(contactsModel2*flag)=N&value(contactsModel2*firstName)=&value(contactsModel2*middleName)=&value(contactsModel2*lastName)=&value(contactsModel2*businessName)=&value(contactsModel2*businessName2)=&value(contactsModel2*tradeName)=&ACMask_124_9_value(contactsModel2*phone1_disp)=&ACMask_124_9_value(contactsModel2*phone1)=&ACMask_124_10_value(contactsModel2*phone2_disp)=&ACMask_124_10_value(contactsModel2*phone2)=&ACMask_124_23_value(contactsModel2*phone3_disp)=&"
		"ACMask_124_23_value(contactsModel2*phone3)=&value(contactsModel2*preferredChannel)=&value(contactsModel2*email)=&value(serviceProviderCode)=&value(ID1)=&value(ID2)=&value(ID3)=&value(mode)=New&value(modePro)=add&valuetextarea15=&sourcetextarea15=&layouttextarea15=null&contactsModel2*uiuid=15&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&endDate=&chooseItems="
		"&effectiveDate=&isContact3=1&contact3ViewID=124&isContact3Validation=N&isContact3Required=Y&contact3AccessRight=F&contact3ContactNumber=null&value(mode)=add&value(srTest)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capID)=&value(capDetailModel*shortNotes)=&value(capModel*specialText)=&value(capWorkDescriptionModel*description)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capDetailModel*creatorDeptAlias)=&value(capDetailModel*asgnDept)=&value(capModel*capSubType)=&date"
		"(capDetailModel*closedDate)=&date(capDetailModel*asgnDate)=&date(capDetailModel*completeDate)=&date(capDetailModel*scheduledDate)=&value(capDetailModel*scheduledTime)=&value(capDetailModel*completeDept)=&value(capDetailModel*completeStaff)=&value(capDetailModel*closedDept)=&value(capDetailModel*closedBy)=&value(capModel*capStatus)=Submitted&value(capDetailModel*asgnStaff)=&value(capDetailModel*priority)=&value(capDetailModel*reportedChannel)=Call%20Center&value(capDetailModel*severity)=&value"
		"(capModel*altID)=&value(jobValue)=&value(capDetailModel*totalFee)=0.0&value(capDetailModel*totalPay)=0.0&value(capDetailModel*balance)=0.0&value(capDetailModel*estProdUnits)=0.0&value(capDetailModel*actualProdUnits)=0.0&value(capDetailModel*estCostPerUnit)=&value(capDetailModel*costPerUnit)=&value(capDetailModel*estJobCost)=&value(blank1)=&value(blank2)=&value(blank3)=&value(blank4)=&value(blank5)=&value(capDetailModel*totalJobCost)=&value(b1ExpirationModel*expStatus)=&date"
		"(b1ExpirationModel*expDate)=&date(capModel*reportedDate)=08%2F28%2F2018&value(capModel*reportedTime)=&value(capDetailModel*anonymousFlag)=&value(capDetailModel*referenceType)=&value(capDetailModel*enforceDept)=&value(capDetailModel*enforceOfficerName)=&value(capDetailModel*enforceOfficerId)=&value(capDetailModel*inspectorDept)=&value(capDetailModel*inspectorName)=&value(capDetailModel*inspectorId)=&date(capDetailModel*appearanceDate)=&value(capDetailModel*appearanceDayOfWeek)=&value"
		"(capDetailModel*infractionFlag)=&value(capDetailModel*misdemeanorFlag)=&value(capDetailModel*offnWitnessedFlag)=&value(capDetailModel*dfndtSignatureFlag)=&value(capDetailModel*bookingFlag)=&value(capDetailModel*statusReason)=&date(capDetailModel*firstIssuedDate)=&value(capDetailModel*undistributedCost)=&value(capDetailModel*url)=&value(capModel*pendingValidation)=&date(capModel*fileDate)=08%2F28%2F2018&editPar=2112&allViewIDGroup=%2C124%2C225&viewGroup=%2C124%2C225&formGroup="
		"%2Ccontact3DetailForm%2CcapDetailForm&fromModel=cap&modelId=&fromEditPartialCap=&fromMode=newSingle&GISCommand=null&isAddressList=&isParcelList=&isOwnerList=&isProfessionalList=&value(contactValidatePassed)=true&value(createCapForParcelType)=&SKIP_EMSE_FLAG=N&isFromAssetList=null%20&isValidationFailed=null&isValidated=null&_viewstate_=%7B%22empty%22%3Afalse%2C%22fields%22%3A%7B%22value(contactsModel2*maskedSsn)"
		"%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22SSN%22%7D%2C%22value(contactsModel2*fein)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22FEIN%22%7D%7D%7D&accelasubmitbuttonname=Previous&callBack=&variableKey=ASI%3A%3APOLICE%20REPORT%3A%3AIs%20there%20a%20police%20report&refAPONumber=undefined&argumentPKs="
		"%5B%7B%22portletID%22%3A-1%2C%22viewKey1%22%3A%22%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%2C%7B%22portletID%22%3A124%2C%22viewKey1%22%3A%22Complainant%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%5D&expressionPageType=SPEAR&mode=execute", 
		LAST);

	web_custom_request("expression.do_7", 
		"URL=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=execute", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t150.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=&value(CurrentEntryURL)=&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=&modeName=new&module=Enforcement&itemName=&CurrentViewID=&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(paLicenseId)=&isRefreshPartialCondition=N&isAppSpecInfo=1&value(capID*ID1)=&value(capID*ID2)=&value(capID*ID3)=&"
		"singleModeName=COMPLAINT%2BINFORMATION&app_spec_info_COMPLAINT_INFORMATION_Profession=Nursing&app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee=performance&app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_License_Number=&app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint=performance&app_spec_info_COMPLAINT_INFORMATION_Is_this_drug_related%253F=No&singleModeName=WILLINGNESS%2BTO%2BTESTIFY&"
		"app_spec_info_WILLINGNESS_TO_TESTIFY_Are_you_willing_to_testify_in_a_hearing=No&singleModeName=COMMUNICATION%2BCONSENT&app_spec_info_COMMUNICATION_CONSENT_I_authorize_the_Department_to_release_my_name_and_all_relevant_information_pertaining_to_this_allega=No&app_spec_info_COMMUNICATION_CONSENT_Do_you_authorize_another_person_to_communicate_with_the_department_regarding_your_complaint=No&app_spec_info_COMMUNICATION_CONSENT_Name=&app_spec_info_COMMUNICATION_CONSENT_Address=&"
		"app_spec_info_COMMUNICATION_CONSENT_Telephone_Number=&app_spec_info_COMMUNICATION_CONSENT_Email_Address=&app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You=&singleModeName=PATIENT%2BMEDICAL%2BTREATMENT&app_spec_info_PATIENT_MEDICAL_TREATMENT_Is_your_complaint_regarding_the_medical_treatment_of_a_patient=No&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Name=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Date_of_Birth=&"
		"app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%2527s_of_Patient%2527s_SSN=0&app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident=&singleModeName=MEDICAL%2BSTAFF%2BPRIVILEGES&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Are_you_reporting_a_change_in_medical_staff_privileges=No&app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff=&"
		"app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation=&singleModeName=POLICE%2BREPORT&app_spec_info_POLICE_REPORT_Is_there_a_police_report=No&app_spec_info_POLICE_REPORT_Police_Agency=&app_spec_info_POLICE_REPORT_Police_Report_Incident_Number=&singleModeName=CRIMINAL%2BCONVICTIONS&app_spec_info_CRIMINAL_CONVICTIONS_Are_you_reporting_a_criminal_conviction=No&"
		"app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee=&singleModeName=SELF%2BREPORTING&app_spec_info_SELF_REPORTING_State_Board_Name=&app_spec_info_SELF_REPORTING_Date_of_Action=&app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action=&singleModeName=ENFORCEMENT%2BROUTING&app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type=&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value=Y&"
		"app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints=on&expression_portlet_to_be_populate=-1&expression_portlet_to_be_populate=-99999&is_ASI_fields_displayed=true&expressionPageType=SPEAR&expression_page_reload_after_submit_or_validate_failed=true&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&"
		"value(mode)=newsave&value(contactSeqNumber)=&value(contact2*refContactNumber)=&value(contactsModel2*refContactNumber)=&value(serviceProviderCode)=&value(contactsModel2*contactTypeFlag)=individual&value(contactsModel2*accessLevel)=N&value(contactsModel2*contactType)=Complainant&value(contactsModel2*title)=&value(contactsModel2*fullName)=&value(contactsModel2*addressId)=&value(contactsModel2*addressLine1)=&value(contactsModel2*addressLine2)=&value(contactsModel2*addressLine3)=&value"
		"(contactsModel2*city)=&value(contactsModel2*state)=MI&value(contactsModel2*zip)=&value(contactsModel2*countryCode)=&value(contactsModel2*fax)=&value(contactsModel2*contactOnSRChange)=&value(contactsModel2*comment)=&value(maskformat_contactsModel2*maskedSsn)=%23%23%23-%23%23-%23%23%23%23&value(contactsModel2*maskedSsn)=&value(maskformat_contactsModel2*fein)=&value(contactsModel2*fein)=&value(contactsModel2*userID)=&value(contactsModel2*internalUserFlag)=&value(templateData)=&value"
		"(contactsModel2*salutation)=&value(contactsModel2*gender)=&value(contactsModel2*postOfficeBox)=&date(contactsModel2*birthDate)=&value(contactsModel2*namesuffix)=&value(contactsModel2*birthCity)=&value(contactsModel2*birthState)=&value(contactsModel2*birthRegion)=&value(contactsModel2*race)=&date(contactsModel2*deceasedDate)=&value(contactsModel2*passportNumber)=&value(contactsModel2*driverLicenseNbr)=&value(contactsModel2*driverLicenseState)=&value(contactsModel2*stateIDNbr)=&value"
		"(contactsModel2*relation)=&value(contactsModel2*flag)=N&value(contactsModel2*firstName)=&value(contactsModel2*middleName)=&value(contactsModel2*lastName)=&value(contactsModel2*businessName)=&value(contactsModel2*businessName2)=&value(contactsModel2*tradeName)=&ACMask_124_9_value(contactsModel2*phone1_disp)=&ACMask_124_9_value(contactsModel2*phone1)=&ACMask_124_10_value(contactsModel2*phone2_disp)=&ACMask_124_10_value(contactsModel2*phone2)=&ACMask_124_23_value(contactsModel2*phone3_disp)=&"
		"ACMask_124_23_value(contactsModel2*phone3)=&value(contactsModel2*preferredChannel)=&value(contactsModel2*email)=&value(serviceProviderCode)=&value(ID1)=&value(ID2)=&value(ID3)=&value(mode)=New&value(modePro)=add&valuetextarea15=&sourcetextarea15=&layouttextarea15=null&contactsModel2*uiuid=15&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&endDate=&chooseItems="
		"&effectiveDate=&isContact3=1&contact3ViewID=124&isContact3Validation=N&isContact3Required=Y&contact3AccessRight=F&contact3ContactNumber=null&value(mode)=add&value(srTest)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capID)=&value(capDetailModel*shortNotes)=&value(capModel*specialText)=&value(capWorkDescriptionModel*description)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capDetailModel*creatorDeptAlias)=&value(capDetailModel*asgnDept)=&value(capModel*capSubType)=&date"
		"(capDetailModel*closedDate)=&date(capDetailModel*asgnDate)=&date(capDetailModel*completeDate)=&date(capDetailModel*scheduledDate)=&value(capDetailModel*scheduledTime)=&value(capDetailModel*completeDept)=&value(capDetailModel*completeStaff)=&value(capDetailModel*closedDept)=&value(capDetailModel*closedBy)=&value(capModel*capStatus)=Submitted&value(capDetailModel*asgnStaff)=&value(capDetailModel*priority)=&value(capDetailModel*reportedChannel)=Call%20Center&value(capDetailModel*severity)=&value"
		"(capModel*altID)=&value(jobValue)=&value(capDetailModel*totalFee)=0.0&value(capDetailModel*totalPay)=0.0&value(capDetailModel*balance)=0.0&value(capDetailModel*estProdUnits)=0.0&value(capDetailModel*actualProdUnits)=0.0&value(capDetailModel*estCostPerUnit)=&value(capDetailModel*costPerUnit)=&value(capDetailModel*estJobCost)=&value(blank1)=&value(blank2)=&value(blank3)=&value(blank4)=&value(blank5)=&value(capDetailModel*totalJobCost)=&value(b1ExpirationModel*expStatus)=&date"
		"(b1ExpirationModel*expDate)=&date(capModel*reportedDate)=08%2F28%2F2018&value(capModel*reportedTime)=&value(capDetailModel*anonymousFlag)=&value(capDetailModel*referenceType)=&value(capDetailModel*enforceDept)=&value(capDetailModel*enforceOfficerName)=&value(capDetailModel*enforceOfficerId)=&value(capDetailModel*inspectorDept)=&value(capDetailModel*inspectorName)=&value(capDetailModel*inspectorId)=&date(capDetailModel*appearanceDate)=&value(capDetailModel*appearanceDayOfWeek)=&value"
		"(capDetailModel*infractionFlag)=&value(capDetailModel*misdemeanorFlag)=&value(capDetailModel*offnWitnessedFlag)=&value(capDetailModel*dfndtSignatureFlag)=&value(capDetailModel*bookingFlag)=&value(capDetailModel*statusReason)=&date(capDetailModel*firstIssuedDate)=&value(capDetailModel*undistributedCost)=&value(capDetailModel*url)=&value(capModel*pendingValidation)=&date(capModel*fileDate)=08%2F28%2F2018&editPar=2112&allViewIDGroup=%2C124%2C225&viewGroup=%2C124%2C225&formGroup="
		"%2Ccontact3DetailForm%2CcapDetailForm&fromModel=cap&modelId=&fromEditPartialCap=&fromMode=newSingle&GISCommand=null&isAddressList=&isParcelList=&isOwnerList=&isProfessionalList=&value(contactValidatePassed)=true&value(createCapForParcelType)=&SKIP_EMSE_FLAG=N&isFromAssetList=null%20&isValidationFailed=null&isValidated=null&_viewstate_=%7B%22empty%22%3Afalse%2C%22fields%22%3A%7B%22value(contactsModel2*maskedSsn)"
		"%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22SSN%22%7D%2C%22value(contactsModel2*fein)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22FEIN%22%7D%7D%7D&accelasubmitbuttonname=Previous&callBack=&variableKey=ASI%3A%3ACRIMINAL%20CONVICTIONS%3A%3AAre%20you%20reporting%20a%20criminal%20conviction&refAPONumber=undefined&argumentPKs="
		"%5B%7B%22portletID%22%3A-1%2C%22viewKey1%22%3A%22%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%2C%7B%22portletID%22%3A124%2C%22viewKey1%22%3A%22Complainant%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%5D&expressionPageType=SPEAR&mode=execute", 
		LAST);

	web_custom_request("expression.do_8", 
		"URL=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=execute", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t151.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=&value(CurrentEntryURL)=&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=&modeName=new&module=Enforcement&itemName=&CurrentViewID=&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(paLicenseId)=&isRefreshPartialCondition=N&isAppSpecInfo=1&value(capID*ID1)=&value(capID*ID2)=&value(capID*ID3)=&"
		"singleModeName=COMPLAINT%2BINFORMATION&app_spec_info_COMPLAINT_INFORMATION_Profession=Nursing&app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee=performance&app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_License_Number=&app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint=performance&app_spec_info_COMPLAINT_INFORMATION_Is_this_drug_related%253F=No&singleModeName=WILLINGNESS%2BTO%2BTESTIFY&"
		"app_spec_info_WILLINGNESS_TO_TESTIFY_Are_you_willing_to_testify_in_a_hearing=No&singleModeName=COMMUNICATION%2BCONSENT&app_spec_info_COMMUNICATION_CONSENT_I_authorize_the_Department_to_release_my_name_and_all_relevant_information_pertaining_to_this_allega=No&app_spec_info_COMMUNICATION_CONSENT_Do_you_authorize_another_person_to_communicate_with_the_department_regarding_your_complaint=No&app_spec_info_COMMUNICATION_CONSENT_Name=&app_spec_info_COMMUNICATION_CONSENT_Address=&"
		"app_spec_info_COMMUNICATION_CONSENT_Telephone_Number=&app_spec_info_COMMUNICATION_CONSENT_Email_Address=&app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You=&singleModeName=PATIENT%2BMEDICAL%2BTREATMENT&app_spec_info_PATIENT_MEDICAL_TREATMENT_Is_your_complaint_regarding_the_medical_treatment_of_a_patient=No&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Name=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Date_of_Birth=&"
		"app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%2527s_of_Patient%2527s_SSN=0&app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident=&singleModeName=MEDICAL%2BSTAFF%2BPRIVILEGES&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Are_you_reporting_a_change_in_medical_staff_privileges=No&app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff=&"
		"app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation=&singleModeName=POLICE%2BREPORT&app_spec_info_POLICE_REPORT_Is_there_a_police_report=No&app_spec_info_POLICE_REPORT_Police_Agency=&app_spec_info_POLICE_REPORT_Police_Report_Incident_Number=&singleModeName=CRIMINAL%2BCONVICTIONS&app_spec_info_CRIMINAL_CONVICTIONS_Are_you_reporting_a_criminal_conviction=No&"
		"app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee=&singleModeName=SELF%2BREPORTING&app_spec_info_SELF_REPORTING_Are_you_self_reporting_disciplinary_action_taken_against_you_by_another_state_board=No&app_spec_info_SELF_REPORTING_State_Board_Name=&app_spec_info_SELF_REPORTING_Date_of_Action=&app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action=&singleModeName=ENFORCEMENT%2BROUTING&app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type"
		"=&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints=on&expression_portlet_to_be_populate=-1&expression_portlet_to_be_populate=-99999&is_ASI_fields_displayed=true&expressionPageType=SPEAR&expression_page_reload_after_submit_or_validate_failed=true&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&"
		"sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(mode)=newsave&value(contactSeqNumber)=&value(contact2*refContactNumber)=&value(contactsModel2*refContactNumber)=&value(serviceProviderCode)=&value(contactsModel2*contactTypeFlag)=individual&value(contactsModel2*accessLevel)=N&value(contactsModel2*contactType)=Complainant&value(contactsModel2*title)=&value(contactsModel2*fullName)=&value(contactsModel2*addressId)=&value(contactsModel2*addressLine1)=&value"
		"(contactsModel2*addressLine2)=&value(contactsModel2*addressLine3)=&value(contactsModel2*city)=&value(contactsModel2*state)=MI&value(contactsModel2*zip)=&value(contactsModel2*countryCode)=&value(contactsModel2*fax)=&value(contactsModel2*contactOnSRChange)=&value(contactsModel2*comment)=&value(maskformat_contactsModel2*maskedSsn)=%23%23%23-%23%23-%23%23%23%23&value(contactsModel2*maskedSsn)=&value(maskformat_contactsModel2*fein)=&value(contactsModel2*fein)=&value(contactsModel2*userID)=&value"
		"(contactsModel2*internalUserFlag)=&value(templateData)=&value(contactsModel2*salutation)=&value(contactsModel2*gender)=&value(contactsModel2*postOfficeBox)=&date(contactsModel2*birthDate)=&value(contactsModel2*namesuffix)=&value(contactsModel2*birthCity)=&value(contactsModel2*birthState)=&value(contactsModel2*birthRegion)=&value(contactsModel2*race)=&date(contactsModel2*deceasedDate)=&value(contactsModel2*passportNumber)=&value(contactsModel2*driverLicenseNbr)=&value"
		"(contactsModel2*driverLicenseState)=&value(contactsModel2*stateIDNbr)=&value(contactsModel2*relation)=&value(contactsModel2*flag)=N&value(contactsModel2*firstName)=&value(contactsModel2*middleName)=&value(contactsModel2*lastName)=&value(contactsModel2*businessName)=&value(contactsModel2*businessName2)=&value(contactsModel2*tradeName)=&ACMask_124_9_value(contactsModel2*phone1_disp)=&ACMask_124_9_value(contactsModel2*phone1)=&ACMask_124_10_value(contactsModel2*phone2_disp)=&ACMask_124_10_value"
		"(contactsModel2*phone2)=&ACMask_124_23_value(contactsModel2*phone3_disp)=&ACMask_124_23_value(contactsModel2*phone3)=&value(contactsModel2*preferredChannel)=&value(contactsModel2*email)=&value(serviceProviderCode)=&value(ID1)=&value(ID2)=&value(ID3)=&value(mode)=New&value(modePro)=add&valuetextarea15=&sourcetextarea15=&layouttextarea15=null&contactsModel2*uiuid=15&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow="
		"PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&endDate=&chooseItems=&effectiveDate=&isContact3=1&contact3ViewID=124&isContact3Validation=N&isContact3Required=Y&contact3AccessRight=F&contact3ContactNumber=null&value(mode)=add&value(srTest)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capID)=&value(capDetailModel*shortNotes)=&value(capModel*specialText)=&value(capWorkDescriptionModel*description)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value"
		"(capDetailModel*creatorDeptAlias)=&value(capDetailModel*asgnDept)=&value(capModel*capSubType)=&date(capDetailModel*closedDate)=&date(capDetailModel*asgnDate)=&date(capDetailModel*completeDate)=&date(capDetailModel*scheduledDate)=&value(capDetailModel*scheduledTime)=&value(capDetailModel*completeDept)=&value(capDetailModel*completeStaff)=&value(capDetailModel*closedDept)=&value(capDetailModel*closedBy)=&value(capModel*capStatus)=Submitted&value(capDetailModel*asgnStaff)=&value"
		"(capDetailModel*priority)=&value(capDetailModel*reportedChannel)=Call%20Center&value(capDetailModel*severity)=&value(capModel*altID)=&value(jobValue)=&value(capDetailModel*totalFee)=0.0&value(capDetailModel*totalPay)=0.0&value(capDetailModel*balance)=0.0&value(capDetailModel*estProdUnits)=0.0&value(capDetailModel*actualProdUnits)=0.0&value(capDetailModel*estCostPerUnit)=&value(capDetailModel*costPerUnit)=&value(capDetailModel*estJobCost)=&value(blank1)=&value(blank2)=&value(blank3)=&value(blank4)="
		"&value(blank5)=&value(capDetailModel*totalJobCost)=&value(b1ExpirationModel*expStatus)=&date(b1ExpirationModel*expDate)=&date(capModel*reportedDate)=08%2F28%2F2018&value(capModel*reportedTime)=&value(capDetailModel*anonymousFlag)=&value(capDetailModel*referenceType)=&value(capDetailModel*enforceDept)=&value(capDetailModel*enforceOfficerName)=&value(capDetailModel*enforceOfficerId)=&value(capDetailModel*inspectorDept)=&value(capDetailModel*inspectorName)=&value(capDetailModel*inspectorId)=&date"
		"(capDetailModel*appearanceDate)=&value(capDetailModel*appearanceDayOfWeek)=&value(capDetailModel*infractionFlag)=&value(capDetailModel*misdemeanorFlag)=&value(capDetailModel*offnWitnessedFlag)=&value(capDetailModel*dfndtSignatureFlag)=&value(capDetailModel*bookingFlag)=&value(capDetailModel*statusReason)=&date(capDetailModel*firstIssuedDate)=&value(capDetailModel*undistributedCost)=&value(capDetailModel*url)=&value(capModel*pendingValidation)=&date(capModel*fileDate)=08%2F28%2F2018&editPar=2112&"
		"allViewIDGroup=%2C124%2C225&viewGroup=%2C124%2C225&formGroup=%2Ccontact3DetailForm%2CcapDetailForm&fromModel=cap&modelId=&fromEditPartialCap=&fromMode=newSingle&GISCommand=null&isAddressList=&isParcelList=&isOwnerList=&isProfessionalList=&value(contactValidatePassed)=true&value(createCapForParcelType)=&SKIP_EMSE_FLAG=N&isFromAssetList=null%20&isValidationFailed=null&isValidated=null&_viewstate_=%7B%22empty%22%3Afalse%2C%22fields%22%3A%7B%22value(contactsModel2*maskedSsn)"
		"%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22SSN%22%7D%2C%22value(contactsModel2*fein)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22FEIN%22%7D%7D%7D&accelasubmitbuttonname=Previous&callBack=&variableKey=ASI%3A%3ASELF%20REPORTING%3A%3AAre%20you%20self-reporting%20disciplinary%20action%20taken%20against%20you%20by%20another%20state%20board&refAPONumber=undefined&argumentPKs="
		"%5B%7B%22portletID%22%3A-1%2C%22viewKey1%22%3A%22%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%2C%7B%22portletID%22%3A124%2C%22viewKey1%22%3A%22Complainant%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%5D&expressionPageType=SPEAR&mode=execute", 
		LAST);

	lr_think_time(10);

	web_url("session.do_12", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1&module=Enforcement", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t152.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(21);

	lr_start_transaction("MILARA_TC3_08_SubmitApplication_AddNewApplication");

	web_url("session.do_13", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1&module=Enforcement", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t153.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("expression.do_9", 
		"URL=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=execute", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t154.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=&value(CurrentEntryURL)=&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=&modeName=new&module=Enforcement&itemName=&CurrentViewID=&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(paLicenseId)=&isRefreshPartialCondition=N&isAppSpecInfo=1&value(capID*ID1)=&value(capID*ID2)=&value(capID*ID3)=&"
		"singleModeName=COMPLAINT%2BINFORMATION&app_spec_info_COMPLAINT_INFORMATION_Profession=Nursing&app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee=performance&app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_License_Number=&app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint=performance&app_spec_info_COMPLAINT_INFORMATION_Is_this_drug_related%253F=No&singleModeName=WILLINGNESS%2BTO%2BTESTIFY&"
		"app_spec_info_WILLINGNESS_TO_TESTIFY_Are_you_willing_to_testify_in_a_hearing=No&singleModeName=COMMUNICATION%2BCONSENT&app_spec_info_COMMUNICATION_CONSENT_I_authorize_the_Department_to_release_my_name_and_all_relevant_information_pertaining_to_this_allega=No&app_spec_info_COMMUNICATION_CONSENT_Do_you_authorize_another_person_to_communicate_with_the_department_regarding_your_complaint=No&app_spec_info_COMMUNICATION_CONSENT_Name=&app_spec_info_COMMUNICATION_CONSENT_Address=&"
		"app_spec_info_COMMUNICATION_CONSENT_Telephone_Number=&app_spec_info_COMMUNICATION_CONSENT_Email_Address=&app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You=&singleModeName=PATIENT%2BMEDICAL%2BTREATMENT&app_spec_info_PATIENT_MEDICAL_TREATMENT_Is_your_complaint_regarding_the_medical_treatment_of_a_patient=No&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Name=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Date_of_Birth=&"
		"app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%2527s_of_Patient%2527s_SSN=0&app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident=&singleModeName=MEDICAL%2BSTAFF%2BPRIVILEGES&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Are_you_reporting_a_change_in_medical_staff_privileges=No&app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff=&"
		"app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation=&singleModeName=POLICE%2BREPORT&app_spec_info_POLICE_REPORT_Is_there_a_police_report=No&app_spec_info_POLICE_REPORT_Police_Agency=&app_spec_info_POLICE_REPORT_Police_Report_Incident_Number=&singleModeName=CRIMINAL%2BCONVICTIONS&app_spec_info_CRIMINAL_CONVICTIONS_Are_you_reporting_a_criminal_conviction=No&"
		"app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee=&singleModeName=SELF%2BREPORTING&app_spec_info_SELF_REPORTING_Are_you_self_reporting_disciplinary_action_taken_against_you_by_another_state_board=No&app_spec_info_SELF_REPORTING_State_Board_Name=&app_spec_info_SELF_REPORTING_Date_of_Action=&app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action=&singleModeName=ENFORCEMENT%2BROUTING&app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type"
		"=Public&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints=on&expression_portlet_to_be_populate=-1&expression_portlet_to_be_populate=-99999&is_ASI_fields_displayed=true&expressionPageType=SPEAR&expression_page_reload_after_submit_or_validate_failed=true&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&"
		"sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(mode)=newsave&value(contactSeqNumber)=&value(contact2*refContactNumber)=&value(contactsModel2*refContactNumber)=&value(serviceProviderCode)=&value(contactsModel2*contactTypeFlag)=individual&value(contactsModel2*accessLevel)=N&value(contactsModel2*contactType)=Complainant&value(contactsModel2*title)=&value(contactsModel2*fullName)=&value(contactsModel2*addressId)=&value(contactsModel2*addressLine1)=&value"
		"(contactsModel2*addressLine2)=&value(contactsModel2*addressLine3)=&value(contactsModel2*city)=&value(contactsModel2*state)=MI&value(contactsModel2*zip)=&value(contactsModel2*countryCode)=&value(contactsModel2*fax)=&value(contactsModel2*contactOnSRChange)=&value(contactsModel2*comment)=&value(maskformat_contactsModel2*maskedSsn)=%23%23%23-%23%23-%23%23%23%23&value(contactsModel2*maskedSsn)=&value(maskformat_contactsModel2*fein)=&value(contactsModel2*fein)=&value(contactsModel2*userID)=&value"
		"(contactsModel2*internalUserFlag)=&value(templateData)=&value(contactsModel2*salutation)=&value(contactsModel2*gender)=&value(contactsModel2*postOfficeBox)=&date(contactsModel2*birthDate)=&value(contactsModel2*namesuffix)=&value(contactsModel2*birthCity)=&value(contactsModel2*birthState)=&value(contactsModel2*birthRegion)=&value(contactsModel2*race)=&date(contactsModel2*deceasedDate)=&value(contactsModel2*passportNumber)=&value(contactsModel2*driverLicenseNbr)=&value"
		"(contactsModel2*driverLicenseState)=&value(contactsModel2*stateIDNbr)=&value(contactsModel2*relation)=&value(contactsModel2*flag)=N&value(contactsModel2*firstName)=&value(contactsModel2*middleName)=&value(contactsModel2*lastName)=&value(contactsModel2*businessName)=&value(contactsModel2*businessName2)=&value(contactsModel2*tradeName)=&ACMask_124_9_value(contactsModel2*phone1_disp)=123457890&ACMask_124_9_value(contactsModel2*phone1)=123457890&ACMask_124_10_value(contactsModel2*phone2_disp)="
		"2345678901&ACMask_124_10_value(contactsModel2*phone2)=2345678901&ACMask_124_23_value(contactsModel2*phone3_disp)=3456789012&ACMask_124_23_value(contactsModel2*phone3)=3456789012&value(contactsModel2*preferredChannel)=&value(contactsModel2*email)=&value(serviceProviderCode)=&value(ID1)=&value(ID2)=&value(ID3)=&value(mode)=New&value(modePro)=add&valuetextarea15=&sourcetextarea15=&layouttextarea15=null&contactsModel2*uiuid=15&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&"
		"ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&endDate=&chooseItems=&effectiveDate=&isContact3=1&contact3ViewID=124&isContact3Validation=N&isContact3Required=Y&contact3AccessRight=F&contact3ContactNumber=null&value(mode)=add&value(srTest)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capID)=&value(capDetailModel*shortNotes)=&value(capModel*specialText)=&value(capWorkDescriptionModel*description)=&value(capType)="
		"Enforcement%2FComplaint%2FNA%2FNA&value(capDetailModel*creatorDeptAlias)=&value(capDetailModel*asgnDept)=&value(capModel*capSubType)=&date(capDetailModel*closedDate)=&date(capDetailModel*asgnDate)=&date(capDetailModel*completeDate)=&date(capDetailModel*scheduledDate)=&value(capDetailModel*scheduledTime)=&value(capDetailModel*completeDept)=&value(capDetailModel*completeStaff)=&value(capDetailModel*closedDept)=&value(capDetailModel*closedBy)=&value(capModel*capStatus)=Submitted&value"
		"(capDetailModel*asgnStaff)=&value(capDetailModel*priority)=&value(capDetailModel*reportedChannel)=Call%20Center&value(capDetailModel*severity)=&value(capModel*altID)=&value(jobValue)=&value(capDetailModel*totalFee)=0.0&value(capDetailModel*totalPay)=0.0&value(capDetailModel*balance)=0.0&value(capDetailModel*estProdUnits)=0.0&value(capDetailModel*actualProdUnits)=0.0&value(capDetailModel*estCostPerUnit)=&value(capDetailModel*costPerUnit)=&value(capDetailModel*estJobCost)=&value(blank1)=&value"
		"(blank2)=&value(blank3)=&value(blank4)=&value(blank5)=&value(capDetailModel*totalJobCost)=&value(b1ExpirationModel*expStatus)=&date(b1ExpirationModel*expDate)=&date(capModel*reportedDate)=08%2F28%2F2018&value(capModel*reportedTime)=&value(capDetailModel*anonymousFlag)=&value(capDetailModel*referenceType)=&value(capDetailModel*enforceDept)=&value(capDetailModel*enforceOfficerName)=&value(capDetailModel*enforceOfficerId)=&value(capDetailModel*inspectorDept)=&value(capDetailModel*inspectorName)=&"
		"value(capDetailModel*inspectorId)=&date(capDetailModel*appearanceDate)=&value(capDetailModel*appearanceDayOfWeek)=&value(capDetailModel*infractionFlag)=&value(capDetailModel*misdemeanorFlag)=&value(capDetailModel*offnWitnessedFlag)=&value(capDetailModel*dfndtSignatureFlag)=&value(capDetailModel*bookingFlag)=&value(capDetailModel*statusReason)=&date(capDetailModel*firstIssuedDate)=&value(capDetailModel*undistributedCost)=&value(capDetailModel*url)=&value(capModel*pendingValidation)=&date"
		"(capModel*fileDate)=08%2F28%2F2018&editPar=2112&allViewIDGroup=%2C124%2C225&viewGroup=%2C124%2C225&formGroup=%2Ccontact3DetailForm%2CcapDetailForm&fromModel=cap&modelId=&fromEditPartialCap=&fromMode=newSingle&GISCommand=null&isAddressList=&isParcelList=&isOwnerList=&isProfessionalList=&value(contactValidatePassed)=true&value(createCapForParcelType)=&SKIP_EMSE_FLAG=N&isFromAssetList=null%20&isValidationFailed=null&isValidated=null&_viewstate_=%7B%22empty%22%3Afalse%2C%22fields%22%3A%7B%22value"
		"(contactsModel2*maskedSsn)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22SSN%22%7D%2C%22value(contactsModel2*fein)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22FEIN%22%7D%7D%7D&accelasubmitbuttonname=Previous&callBack=window.expression.__doExpressionSubmitCallBack(0)&variableKey=onSubmit&refAPONumber=undefined&argumentPKs="
		"%5B%7B%22portletID%22%3A-1%2C%22viewKey1%22%3A%22%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%2C%7B%22portletID%22%3A124%2C%22viewKey1%22%3A%22Complainant%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%5D&expressionPageType=SPEAR&mode=execute", 
		LAST);

	web_submit_data("CapBySingle.do", 
		"Action=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/picker/capTypePicker.do?mode=submit&modelId=&module=Enforcement", 
		"Snapshot=t155.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=value(FirstEntryURL)", "Value=", ENDITEM, 
		"Name=value(CurrentEntryURL)", "Value=", ENDITEM, 
		"Name=portlet_language", "Value=en_US", ENDITEM, 
		"Name=refresh_target", "Value=", ENDITEM, 
		"Name=refresh_url", "Value=", ENDITEM, 
		"Name=buttonName", "Value=", ENDITEM, 
		"Name=modeName", "Value=new", ENDITEM, 
		"Name=module", "Value=Enforcement", ENDITEM, 
		"Name=accelasubmitbuttonname", "Value=newCap", ENDITEM, 
		"Name=itemName", "Value=", ENDITEM, 
		"Name=CurrentViewID", "Value=", ENDITEM, 
		"Name=exceptionLogID", "Value=", ENDITEM, 
		"Name=generalCAPSearch", "Value=", ENDITEM, 
		"Name=isGeneralCAP", "Value=Y", ENDITEM, 
		"Name=objectName", "Value=", ENDITEM, 
		"Name=CheckBoxName", "Value=", ENDITEM, 
		"Name=MaxNumber", "Value=", ENDITEM, 
		"Name=ExportFileType", "Value=print", ENDITEM, 
		"Name=CurrentViewID", "Value=", ENDITEM, 
		"Name=sessionIdFromWindow", "Value=PYJmP2wdFUFYzeEcI06OO4MN", ENDITEM, 
		"Name=listID", "Value=", ENDITEM, 
		"Name=printType", "Value=", ENDITEM, 
		"Name=checkBoxValue", "Value=", ENDITEM, 
		"Name=value(paLicenseId)", "Value=", ENDITEM, 
		"Name=isRefreshPartialCondition", "Value=N", ENDITEM, 
		"Name=isAppSpecInfo", "Value=1", ENDITEM, 
		"Name=value(capID*ID1)", "Value=", ENDITEM, 
		"Name=value(capID*ID2)", "Value=", ENDITEM, 
		"Name=value(capID*ID3)", "Value=", ENDITEM, 
		"Name=singleModeName", "Value=COMPLAINT+INFORMATION", ENDITEM, 
		"Name=app_spec_info_COMPLAINT_INFORMATION_Profession", "Value=Nursing", ENDITEM, 
		"Name=app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee", "Value=performance", ENDITEM, 
		"Name=app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee", "Value=", ENDITEM, 
		"Name=app_spec_info_COMPLAINT_INFORMATION_License_Number", "Value=", ENDITEM, 
		"Name=app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint", "Value=performance", ENDITEM, 
		"Name=app_spec_info_COMPLAINT_INFORMATION_Is_this_drug_related%3F", "Value=No", ENDITEM, 
		"Name=singleModeName", "Value=WILLINGNESS+TO+TESTIFY", ENDITEM, 
		"Name=app_spec_info_WILLINGNESS_TO_TESTIFY_Are_you_willing_to_testify_in_a_hearing", "Value=No", ENDITEM, 
		"Name=singleModeName", "Value=COMMUNICATION+CONSENT", ENDITEM, 
		"Name=app_spec_info_COMMUNICATION_CONSENT_I_authorize_the_Department_to_release_my_name_and_all_relevant_information_pertaining_to_this_allega", "Value=No", ENDITEM, 
		"Name=app_spec_info_COMMUNICATION_CONSENT_Do_you_authorize_another_person_to_communicate_with_the_department_regarding_your_complaint", "Value=No", ENDITEM, 
		"Name=app_spec_info_COMMUNICATION_CONSENT_Name", "Value=", ENDITEM, 
		"Name=app_spec_info_COMMUNICATION_CONSENT_Address", "Value=", ENDITEM, 
		"Name=app_spec_info_COMMUNICATION_CONSENT_Telephone_Number", "Value=", ENDITEM, 
		"Name=app_spec_info_COMMUNICATION_CONSENT_Email_Address", "Value=", ENDITEM, 
		"Name=app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You", "Value=", ENDITEM, 
		"Name=singleModeName", "Value=PATIENT+MEDICAL+TREATMENT", ENDITEM, 
		"Name=app_spec_info_PATIENT_MEDICAL_TREATMENT_Is_your_complaint_regarding_the_medical_treatment_of_a_patient", "Value=No", ENDITEM, 
		"Name=app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%27s_Name", "Value=", ENDITEM, 
		"Name=app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%27s_Date_of_Birth", "Value=", ENDITEM, 
		"Name=app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%27s_of_Patient%27s_SSN", "Value=0", ENDITEM, 
		"Name=app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident", "Value=", ENDITEM, 
		"Name=singleModeName", "Value=MEDICAL+STAFF+PRIVILEGES", ENDITEM, 
		"Name=app_spec_info_MEDICAL_STAFF_PRIVILEGES_Are_you_reporting_a_change_in_medical_staff_privileges", "Value=No", ENDITEM, 
		"Name=app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur", "Value=", ENDITEM, 
		"Name=app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff", "Value=", ENDITEM, 
		"Name=app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary", "Value=", ENDITEM, 
		"Name=app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension", "Value=", ENDITEM, 
		"Name=app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation", "Value=", ENDITEM, 
		"Name=singleModeName", "Value=POLICE+REPORT", ENDITEM, 
		"Name=app_spec_info_POLICE_REPORT_Is_there_a_police_report", "Value=No", ENDITEM, 
		"Name=app_spec_info_POLICE_REPORT_Police_Agency", "Value=", ENDITEM, 
		"Name=app_spec_info_POLICE_REPORT_Police_Report_Incident_Number", "Value=", ENDITEM, 
		"Name=singleModeName", "Value=CRIMINAL+CONVICTIONS", ENDITEM, 
		"Name=app_spec_info_CRIMINAL_CONVICTIONS_Are_you_reporting_a_criminal_conviction", "Value=No", ENDITEM, 
		"Name=app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee", "Value=", ENDITEM, 
		"Name=singleModeName", "Value=SELF+REPORTING", ENDITEM, 
		"Name=app_spec_info_SELF_REPORTING_Are_you_self_reporting_disciplinary_action_taken_against_you_by_another_state_board", "Value=No", ENDITEM, 
		"Name=app_spec_info_SELF_REPORTING_State_Board_Name", "Value=", ENDITEM, 
		"Name=app_spec_info_SELF_REPORTING_Date_of_Action", "Value=", ENDITEM, 
		"Name=app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action", "Value=", ENDITEM, 
		"Name=singleModeName", "Value=ENFORCEMENT+ROUTING", ENDITEM, 
		"Name=app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type", "Value=Public", ENDITEM, 
		"Name=app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value", "Value=Y", ENDITEM, 
		"Name=app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value", "Value=Y", ENDITEM, 
		"Name=app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints", "Value=on", ENDITEM, 
		"Name=value(mode)", "Value=New", ENDITEM, 
		"Name=expression_portlet_to_be_populate", "Value=-1", ENDITEM, 
		"Name=expression_portlet_to_be_populate", "Value=-99999", ENDITEM, 
		"Name=is_ASI_fields_displayed", "Value=true", ENDITEM, 
		"Name=expressionPageType", "Value=SPEAR", ENDITEM, 
		"Name=expression_page_reload_after_submit_or_validate_failed", "Value=true", ENDITEM, 
		"Name=generalCAPSearch", "Value=", ENDITEM, 
		"Name=isGeneralCAP", "Value=Y", ENDITEM, 
		"Name=objectName", "Value=", ENDITEM, 
		"Name=CheckBoxName", "Value=", ENDITEM, 
		"Name=MaxNumber", "Value=", ENDITEM, 
		"Name=ExportFileType", "Value=print", ENDITEM, 
		"Name=CurrentViewID", "Value=124", ENDITEM, 
		"Name=sessionIdFromWindow", "Value=PYJmP2wdFUFYzeEcI06OO4MN", ENDITEM, 
		"Name=listID", "Value=", ENDITEM, 
		"Name=printType", "Value=", ENDITEM, 
		"Name=checkBoxValue", "Value=", ENDITEM, 
		"Name=value(mode)", "Value=newsave", ENDITEM, 
		"Name=value(contactSeqNumber)", "Value=", ENDITEM, 
		"Name=value(contact2*refContactNumber)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*refContactNumber)", "Value=", ENDITEM, 
		"Name=value(serviceProviderCode)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*contactTypeFlag)", "Value=individual", ENDITEM, 
		"Name=value(contactsModel2*contactType_cur)", "Value=Complainant", ENDITEM, 
		"Name=value(contactsModel2*contactType)", "Value=Complainant", ENDITEM, 
		"Name=value(contactsModel2*title)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*fullName)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*addressId)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*addressLine1)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*addressLine2)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*addressLine3)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*city)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*state)", "Value=MI", ENDITEM, 
		"Name=value(contactsModel2*zip)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*countryCode)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*fax)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*contactOnSRChange)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*comment)", "Value=", ENDITEM, 
		"Name=value(maskformat_contactsModel2*maskedSsn)", "Value=###-##-####", ENDITEM, 
		"Name=value(contactsModel2*maskedSsn)", "Value=", ENDITEM, 
		"Name=value(maskformat_contactsModel2*fein)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*fein)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*userID)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*internalUserFlag)", "Value=", ENDITEM, 
		"Name=value(templateData)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*salutation)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*gender)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*postOfficeBox)", "Value=", ENDITEM, 
		"Name=date(contactsModel2*birthDate)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*namesuffix)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*birthCity)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*birthState)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*birthRegion)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*race)", "Value=", ENDITEM, 
		"Name=date(contactsModel2*deceasedDate)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*passportNumber)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*driverLicenseNbr)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*driverLicenseState)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*stateIDNbr)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*relation)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*flag)", "Value=N", ENDITEM, 
		"Name=value(contactsModel2*firstName)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*middleName)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*lastName)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*businessName)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*businessName2)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*tradeName)", "Value=", ENDITEM, 
		"Name=ACMask_124_9_value(contactsModel2*phone1_disp)", "Value=123457890", ENDITEM, 
		"Name=ACMask_124_9_value(contactsModel2*phone1)", "Value=123457890", ENDITEM, 
		"Name=ACMask_124_10_value(contactsModel2*phone2_disp)", "Value=2345678901", ENDITEM, 
		"Name=ACMask_124_10_value(contactsModel2*phone2)", "Value=2345678901", ENDITEM, 
		"Name=ACMask_124_23_value(contactsModel2*phone3_disp)", "Value=3456789012", ENDITEM, 
		"Name=ACMask_124_23_value(contactsModel2*phone3)", "Value=3456789012", ENDITEM, 
		"Name=value(contactsModel2*preferredChannel)", "Value=", ENDITEM, 
		"Name=value(contactsModel2*email)", "Value=", ENDITEM, 
		"Name=value(serviceProviderCode)", "Value=", ENDITEM, 
		"Name=value(ID1)", "Value=", ENDITEM, 
		"Name=value(ID2)", "Value=", ENDITEM, 
		"Name=value(ID3)", "Value=", ENDITEM, 
		"Name=value(mode)", "Value=New", ENDITEM, 
		"Name=value(modePro)", "Value=add", ENDITEM, 
		"Name=valuetextarea15", "Value=", ENDITEM, 
		"Name=sourcetextarea15", "Value=", ENDITEM, 
		"Name=layouttextarea15", "Value=null", ENDITEM, 
		"Name=contactsModel2*uiuid", "Value=15", ENDITEM, 
		"Name=generalCAPSearch", "Value=", ENDITEM, 
		"Name=isGeneralCAP", "Value=Y", ENDITEM, 
		"Name=objectName", "Value=", ENDITEM, 
		"Name=CheckBoxName", "Value=", ENDITEM, 
		"Name=MaxNumber", "Value=", ENDITEM, 
		"Name=ExportFileType", "Value=print", ENDITEM, 
		"Name=CurrentViewID", "Value=124", ENDITEM, 
		"Name=sessionIdFromWindow", "Value=PYJmP2wdFUFYzeEcI06OO4MN", ENDITEM, 
		"Name=listID", "Value=", ENDITEM, 
		"Name=printType", "Value=", ENDITEM, 
		"Name=checkBoxValue", "Value=", ENDITEM, 
		"Name=endDate", "Value=", ENDITEM, 
		"Name=chooseItems", "Value=", ENDITEM, 
		"Name=effectiveDate", "Value=", ENDITEM, 
		"Name=isContact3", "Value=1", ENDITEM, 
		"Name=contact3ViewID", "Value=124", ENDITEM, 
		"Name=isContact3Validation", "Value=N", ENDITEM, 
		"Name=isContact3Required", "Value=Y", ENDITEM, 
		"Name=contact3AccessRight", "Value=F", ENDITEM, 
		"Name=contact3ContactNumber", "Value=null", ENDITEM, 
		"Name=value(mode)", "Value=add", ENDITEM, 
		"Name=value(srTest)", "Value=", ENDITEM, 
		"Name=value(capType)", "Value=Enforcement/Complaint/NA/NA", ENDITEM, 
		"Name=value(capID)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*shortNotes)", "Value=", ENDITEM, 
		"Name=value(capModel*specialText)", "Value=", ENDITEM, 
		"Name=value(capWorkDescriptionModel*description)", "Value=", ENDITEM, 
		"Name=value(capType)", "Value=Enforcement/Complaint/NA/NA", ENDITEM, 
		"Name=value(capDetailModel*creatorDeptAlias)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*asgnDept)", "Value=", ENDITEM, 
		"Name=value(capModel*capSubType)", "Value=", ENDITEM, 
		"Name=date(capDetailModel*closedDate)", "Value=", ENDITEM, 
		"Name=date(capDetailModel*asgnDate)", "Value=", ENDITEM, 
		"Name=date(capDetailModel*completeDate)", "Value=", ENDITEM, 
		"Name=date(capDetailModel*scheduledDate)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*scheduledTime)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*completeDept)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*completeStaff)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*closedDept)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*closedBy)", "Value=", ENDITEM, 
		"Name=value(capModel*capStatus)", "Value=Submitted", ENDITEM, 
		"Name=value(capDetailModel*asgnStaff)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*priority)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*reportedChannel)", "Value=Call Center", ENDITEM, 
		"Name=value(capDetailModel*severity)", "Value=", ENDITEM, 
		"Name=value(capModel*altID)", "Value=", ENDITEM, 
		"Name=value(jobValue)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*totalFee)", "Value=0.0", ENDITEM, 
		"Name=value(capDetailModel*totalPay)", "Value=0.0", ENDITEM, 
		"Name=value(capDetailModel*balance)", "Value=0.0", ENDITEM, 
		"Name=value(capDetailModel*estProdUnits)", "Value=0.0", ENDITEM, 
		"Name=value(capDetailModel*actualProdUnits)", "Value=0.0", ENDITEM, 
		"Name=value(capDetailModel*estCostPerUnit)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*costPerUnit)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*estJobCost)", "Value=", ENDITEM, 
		"Name=value(blank1)", "Value=", ENDITEM, 
		"Name=value(blank2)", "Value=", ENDITEM, 
		"Name=value(blank3)", "Value=", ENDITEM, 
		"Name=value(blank4)", "Value=", ENDITEM, 
		"Name=value(blank5)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*totalJobCost)", "Value=", ENDITEM, 
		"Name=value(b1ExpirationModel*expStatus)", "Value=", ENDITEM, 
		"Name=date(b1ExpirationModel*expDate)", "Value=", ENDITEM, 
		"Name=date(capModel*reportedDate)", "Value=08/28/2018", ENDITEM, 
		"Name=value(capModel*reportedTime)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*anonymousFlag)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*referenceType)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*enforceDept)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*enforceOfficerName)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*enforceOfficerId)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*inspectorDept)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*inspectorName)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*inspectorId)", "Value=", ENDITEM, 
		"Name=date(capDetailModel*appearanceDate)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*appearanceDayOfWeek)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*infractionFlag)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*misdemeanorFlag)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*offnWitnessedFlag)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*dfndtSignatureFlag)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*bookingFlag)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*statusReason)", "Value=", ENDITEM, 
		"Name=date(capDetailModel*firstIssuedDate)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*undistributedCost)", "Value=", ENDITEM, 
		"Name=value(capDetailModel*url)", "Value=", ENDITEM, 
		"Name=value(capModel*pendingValidation)", "Value=", ENDITEM, 
		"Name=date(capModel*fileDate)", "Value=08/28/2018", ENDITEM, 
		"Name=editPar", "Value=2112", ENDITEM, 
		"Name=allViewIDGroup", "Value=,124,225", ENDITEM, 
		"Name=viewGroup", "Value=,124,225", ENDITEM, 
		"Name=formGroup", "Value=,contact3DetailForm,capDetailForm", ENDITEM, 
		"Name=fromModel", "Value=cap", ENDITEM, 
		"Name=modelId", "Value=", ENDITEM, 
		"Name=fromEditPartialCap", "Value=", ENDITEM, 
		"Name=fromMode", "Value=newSingle", ENDITEM, 
		"Name=GISCommand", "Value=null", ENDITEM, 
		"Name=isAddressList", "Value=", ENDITEM, 
		"Name=isParcelList", "Value=", ENDITEM, 
		"Name=isOwnerList", "Value=", ENDITEM, 
		"Name=isProfessionalList", "Value=", ENDITEM, 
		"Name=value(contactValidatePassed)", "Value=true", ENDITEM, 
		"Name=value(createCapForParcelType)", "Value=", ENDITEM, 
		"Name=SKIP_EMSE_FLAG", "Value=N", ENDITEM, 
		"Name=isFromAssetList", "Value=null ", ENDITEM, 
		"Name=isValidationFailed", "Value=null", ENDITEM, 
		"Name=isValidated", "Value=null", ENDITEM, 
		"Name=_viewstate_", "Value={\"empty\":false,\"fields\":{\"value(contactsModel2*maskedSsn)\":{\"maskValue\":\"\",\"originalValue\":\"\",\"strategy\":\"SSN\"},\"value(contactsModel2*fein)\":{\"maskValue\":\"\",\"originalValue\":\"\",\"strategy\":\"FEIN\"}}}", ENDITEM, 
		LAST);

	web_submit_data("ajax.do_2", 
		"Action=https://av-pt-ferrari.accela.com/portlets/i18n/ajax.do?mode=getDateFormat", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t156.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_custom_request("countryStateAJAX.jsp_4", 
		"URL=https://av-pt-ferrari.accela.com/portlets/commons/address/countryStateAJAX.jsp?statevalue=MI&stateProperty=value(contactsModel2*state)&aaZoneId=aazone-country-state-contact2&stateReadOnly=false&country=&tempModuleName=Enforcement&aaxmlrequest=true&aa_rand=0.7810270378831774&aazones=aazone-country-state-contact2&width=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t157.inf", 
		"Mode=HTML", 
		"Body=aazone-country-state-contact2", 
		LAST);

	web_custom_request("countryStateAJAX.jsp_5", 
		"URL=https://av-pt-ferrari.accela.com/portlets/commons/address/countryStateAJAX.jsp?statevalue=&stateProperty=value(contactsModel2*driverLicenseState)&aaZoneId=aazone-country-driverLicenseState2&stateReadOnly=false&country=&tempModuleName=Enforcement&aaxmlrequest=true&aa_rand=0.7347979496698827&aazones=aazone-country-driverLicenseState2&width=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t158.inf", 
		"Mode=HTML", 
		"Body=aazone-country-driverLicenseState2", 
		LAST);

	web_custom_request("countryStateAJAX.jsp_6", 
		"URL=https://av-pt-ferrari.accela.com/portlets/commons/address/countryStateAJAX.jsp?statevalue=&stateProperty=value(contactsModel2*birthState)&aaZoneId=aazone-birth-state-contact2&stateReadOnly=false&country=&tempModuleName=Enforcement&aaxmlrequest=true&aa_rand=0.9803900367114693&aazones=aazone-birth-state-contact2&width=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t159.inf", 
		"Mode=HTML", 
		"Body=aazone-birth-state-contact2", 
		LAST);

	web_submit_data("empty.jsp_5", 
		"Action=https://av-pt-ferrari.accela.com/portlets/framework/includes/error/empty.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t160.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_url("getXRefContactAddressListBySingleContact3.do_3", 
		"URL=https://av-pt-ferrari.accela.com/portlets/attachedgis/getXRefContactAddressListBySingleContact3.do?mode=list&type=contact3&currentContactType=&module=Enforcement&showReadOnlyContactAddress=N&fromViewSummary=null", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t161.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("appSpecInfoForm.do_2", 
		"Action=https://av-pt-ferrari.accela.com/portlets/appspecinfo/appSpecInfoForm.do?mode=buildDrillList&module=Enforcement&guideSheetSeq=&singleMode=", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t162.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_custom_request("search.do_2", 
		"URL=https://av-pt-ferrari.accela.com/portlets/globalSearch/search.do?action=textResources", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/x-json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t163.inf", 
		"Mode=HTML", 
		"Body=categoryName=Portlet - Expression", 
		LAST);

	web_submit_data("regionalSyncMask.do_5", 
		"Action=https://av-pt-ferrari.accela.com/portlets/regional/regionalSyncMask.do?mode=syncMask&maskType=phoneNumber&referValue=", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t164.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("regionalSyncMask.do_6", 
		"Action=https://av-pt-ferrari.accela.com/portlets/regional/regionalSyncMask.do?mode=syncMask&maskType=phoneNumber&getMsg=Y", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t165.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("regionalSyncMask.do_7", 
		"Action=https://av-pt-ferrari.accela.com/portlets/regional/regionalSyncMask.do?mode=syncMask&maskType=phoneNumber&referValue=", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t166.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("regionalSyncMask.do_8", 
		"Action=https://av-pt-ferrari.accela.com/portlets/regional/regionalSyncMask.do?mode=syncMask&maskType=phoneNumber&referValue=", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t167.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	web_submit_data("expression.do_10", 
		"Action=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=getFields", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t168.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=argumentPKs", "Value=[{\"portletID\":-1,\"viewKey1\":\"\",\"viewKey2\":\"\",\"viewKey3\":\"\"},{\"portletID\":124,\"viewKey1\":\"Complainant\",\"viewKey2\":\"\",\"viewKey3\":\"\"}]", ENDITEM, 
		"Name=expressionPageType", "Value=SPEAR", ENDITEM, 
		"Name=isReload", "Value=true", ENDITEM, 
		"Name=module", "Value=Enforcement", ENDITEM, 
		"Name=capType", "Value=Enforcement/Complaint/NA/NA", ENDITEM, 
		LAST);

	web_custom_request("expression.do_11", 
		"URL=https://av-pt-ferrari.accela.com/portlets/expression/expression.do?mode=execute", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t169.inf", 
		"Mode=HTML", 
		"Body=value(FirstEntryURL)=&value(CurrentEntryURL)=%2Fportlets%2Fcap%2FCapBySingle.do%3Fmodule%3DEnforcement&portlet_language=en_US&refresh_target=&refresh_url=&buttonName=newCap&modeName=&module=Enforcement&itemName=&CurrentViewID=&exceptionLogID=&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(paLicenseId)=&isRefreshPartialCondition=N&isAppSpecInfo=1&value"
		"(capID*ID1)=&value(capID*ID2)=&value(capID*ID3)=&singleModeName=COMPLAINT%2BINFORMATION&app_spec_info_COMPLAINT_INFORMATION_Profession=Nursing&app_spec_info_COMPLAINT_INFORMATION_Name_of_Licensee=performance&app_spec_info_COMPLAINT_INFORMATION_Address_of_Licensee=&app_spec_info_COMPLAINT_INFORMATION_License_Number=&app_spec_info_COMPLAINT_INFORMATION_Description_of_Complaint=performance&app_spec_info_COMPLAINT_INFORMATION_Is_this_drug_related%253F=No&singleModeName=WILLINGNESS%2BTO%2BTESTIFY&"
		"app_spec_info_WILLINGNESS_TO_TESTIFY_Are_you_willing_to_testify_in_a_hearing=No&singleModeName=COMMUNICATION%2BCONSENT&app_spec_info_COMMUNICATION_CONSENT_I_authorize_the_Department_to_release_my_name_and_all_relevant_information_pertaining_to_this_allega=No&app_spec_info_COMMUNICATION_CONSENT_Do_you_authorize_another_person_to_communicate_with_the_department_regarding_your_complaint=No&app_spec_info_COMMUNICATION_CONSENT_Name=&app_spec_info_COMMUNICATION_CONSENT_Address=&"
		"app_spec_info_COMMUNICATION_CONSENT_Telephone_Number=&app_spec_info_COMMUNICATION_CONSENT_Email_Address=&app_spec_info_COMMUNICATION_CONSENT_Relationship_to_You=&singleModeName=PATIENT%2BMEDICAL%2BTREATMENT&app_spec_info_PATIENT_MEDICAL_TREATMENT_Is_your_complaint_regarding_the_medical_treatment_of_a_patient=No&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Name=&app_spec_info_PATIENT_MEDICAL_TREATMENT_Patient%2527s_Date_of_Birth=&"
		"app_spec_info_PATIENT_MEDICAL_TREATMENT_Last_4_Digit%2527s_of_Patient%2527s_SSN=0&app_spec_info_PATIENT_MEDICAL_TREATMENT_Date_of_Incident=&singleModeName=MEDICAL%2BSTAFF%2BPRIVILEGES&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Are_you_reporting_a_change_in_medical_staff_privileges=No&app_spec_info_MEDICAL_STAFF_PRIVILEGES_On_what_date_did_the_change_in_staff_privileges_occur=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_time_licensee_was_on_facility_staff=&"
		"app_spec_info_MEDICAL_STAFF_PRIVILEGES_Was_the_resignation_voluntary=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Suspension=&app_spec_info_MEDICAL_STAFF_PRIVILEGES_Period_of_Probation=&singleModeName=POLICE%2BREPORT&app_spec_info_POLICE_REPORT_Is_there_a_police_report=No&app_spec_info_POLICE_REPORT_Police_Agency=&app_spec_info_POLICE_REPORT_Police_Report_Incident_Number=&singleModeName=CRIMINAL%2BCONVICTIONS&app_spec_info_CRIMINAL_CONVICTIONS_Are_you_reporting_a_criminal_conviction=No&"
		"app_spec_info_CRIMINAL_CONVICTIONS_Are_you_self_reporting_a_conviction_or_reporting_a_conviction_against_a_licensee=&singleModeName=SELF%2BREPORTING&app_spec_info_SELF_REPORTING_Are_you_self_reporting_disciplinary_action_taken_against_you_by_another_state_board=No&app_spec_info_SELF_REPORTING_State_Board_Name=&app_spec_info_SELF_REPORTING_Date_of_Action=&app_spec_info_SELF_REPORTING_Nature_of_Disciplinary_Action=&singleModeName=ENFORCEMENT%2BROUTING&app_spec_info_ENFORCEMENT_ROUTING_Complaint_Type"
		"=Public&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Drug_Monitoring_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints_Value=Y&app_spec_info_ENFORCEMENT_ROUTING_Route_to_Complaints=on&expression_portlet_to_be_populate=-1&expression_portlet_to_be_populate=-99999&is_ASI_fields_displayed=true&expressionPageType=SPEAR&expression_page_reload_after_submit_or_validate_failed=true&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&MaxNumber=&ExportFileType=print&CurrentViewID=124&"
		"sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&value(mode)=newsave&value(contactSeqNumber)=&value(contact2*refContactNumber)=&value(contactsModel2*refContactNumber)=&value(serviceProviderCode)=&value(contactsModel2*contactTypeFlag)=individual&value(contactsModel2*accessLevel)=&value(contactsModel2*contactType)=Complainant&value(contactsModel2*title)=&value(contactsModel2*fullName)=&value(contactsModel2*addressId)=&value(contactsModel2*addressLine1)=&value"
		"(contactsModel2*addressLine2)=&value(contactsModel2*addressLine3)=&value(contactsModel2*city)=&value(contactsModel2*state)=MI&value(contactsModel2*zip)=&value(contactsModel2*countryCode)=&value(contactsModel2*fax)=&value(contactsModel2*contactOnSRChange)=&value(contactsModel2*comment)=&value(maskformat_contactsModel2*maskedSsn)=%23%23%23-%23%23-%23%23%23%23&value(contactsModel2*maskedSsn)=&value(maskformat_contactsModel2*fein)=&value(contactsModel2*fein)=&value(contactsModel2*userID)=&value"
		"(contactsModel2*internalUserFlag)=&value(templateData)=&value(contactsModel2*salutation)=&value(contactsModel2*gender)=&value(contactsModel2*postOfficeBox)=&date(contactsModel2*birthDate)=&value(contactsModel2*namesuffix)=&value(contactsModel2*birthCity)=&value(contactsModel2*birthState)=&value(contactsModel2*birthRegion)=&value(contactsModel2*race)=&date(contactsModel2*deceasedDate)=&value(contactsModel2*passportNumber)=&value(contactsModel2*driverLicenseNbr)=&value"
		"(contactsModel2*driverLicenseState)=&value(contactsModel2*stateIDNbr)=&value(contactsModel2*relation)=&value(contactsModel2*flag)=N&value(contactsModel2*firstName)=&value(contactsModel2*middleName)=&value(contactsModel2*lastName)=&value(contactsModel2*businessName)=&value(contactsModel2*businessName2)=&value(contactsModel2*tradeName)=&ACMask_124_9_value(contactsModel2*phone1_disp)=123457890&ACMask_124_9_value(contactsModel2*phone1)=123457890&ACMask_124_10_value(contactsModel2*phone2_disp)=(234)"
		"%20567-8901&ACMask_124_10_value(contactsModel2*phone2)=(234)%20567-8901&ACMask_124_23_value(contactsModel2*phone3_disp)=(345)%20678-9012&ACMask_124_23_value(contactsModel2*phone3)=(345)%20678-9012&value(contactsModel2*preferredChannel)=&value(contactsModel2*email)=&value(serviceProviderCode)=&value(ID1)=&value(ID2)=&value(ID3)=&value(mode)=New&value(modePro)=add&valuetextarea15=&sourcetextarea15=&layouttextarea15=&contactsModel2*uiuid=15&generalCAPSearch=&isGeneralCAP=Y&objectName=&CheckBoxName=&"
		"MaxNumber=&ExportFileType=print&CurrentViewID=124&sessionIdFromWindow=PYJmP2wdFUFYzeEcI06OO4MN&listID=&printType=&checkBoxValue=&endDate=&chooseItems=&effectiveDate=&isContact3=1&contact3ViewID=124&isContact3Validation=N&isContact3Required=Y&contact3AccessRight=F&contact3ContactNumber=null&value(mode)=add&value(srTest)=&value(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capID)=&value(capDetailModel*shortNotes)=&value(capModel*specialText)=&value(capWorkDescriptionModel*description)=&value"
		"(capType)=Enforcement%2FComplaint%2FNA%2FNA&value(capDetailModel*creatorDeptAlias)=&value(capDetailModel*asgnDept)=&value(capModel*capSubType)=&date(capDetailModel*closedDate)=&date(capDetailModel*asgnDate)=&date(capDetailModel*completeDate)=&date(capDetailModel*scheduledDate)=&value(capDetailModel*scheduledTime)=&value(capDetailModel*completeDept)=&value(capDetailModel*completeStaff)=&value(capDetailModel*closedDept)=&value(capDetailModel*closedBy)=&value(capModel*capStatus)=Submitted&value"
		"(capDetailModel*asgnStaff)=&value(capDetailModel*priority)=&value(capDetailModel*reportedChannel)=Call%20Center&value(capDetailModel*severity)=&value(capModel*altID)=&value(jobValue)=&value(capDetailModel*totalFee)=0.0&value(capDetailModel*totalPay)=0.0&value(capDetailModel*balance)=0.0&value(capDetailModel*estProdUnits)=0.0&value(capDetailModel*actualProdUnits)=0.0&value(capDetailModel*estCostPerUnit)=&value(capDetailModel*costPerUnit)=&value(capDetailModel*estJobCost)=&value(blank1)=&value"
		"(blank2)=&value(blank3)=&value(blank4)=&value(blank5)=&value(capDetailModel*totalJobCost)=&value(b1ExpirationModel*expStatus)=&date(b1ExpirationModel*expDate)=&date(capModel*reportedDate)=08%2F28%2F2018&value(capModel*reportedTime)=&value(capDetailModel*anonymousFlag)=&value(capDetailModel*referenceType)=&value(capDetailModel*enforceDept)=&value(capDetailModel*enforceOfficerName)=&value(capDetailModel*enforceOfficerId)=&value(capDetailModel*inspectorDept)=&value(capDetailModel*inspectorName)=&"
		"value(capDetailModel*inspectorId)=&date(capDetailModel*appearanceDate)=&value(capDetailModel*appearanceDayOfWeek)=&value(capDetailModel*infractionFlag)=&value(capDetailModel*misdemeanorFlag)=&value(capDetailModel*offnWitnessedFlag)=&value(capDetailModel*dfndtSignatureFlag)=&value(capDetailModel*bookingFlag)=&value(capDetailModel*statusReason)=&date(capDetailModel*firstIssuedDate)=&value(capDetailModel*undistributedCost)=&value(capDetailModel*url)=&value(capModel*pendingValidation)=&date"
		"(capModel*fileDate)=08%2F28%2F2018&editPar=2112&allViewIDGroup=%2C124%2C225&viewGroup=%2C124%2C225&formGroup=%2Ccontact3DetailForm%2CcapDetailForm&fromModel=cap&modelId=&fromEditPartialCap=&fromMode=newSingle&GISCommand=null&isAddressList=&isParcelList=&isOwnerList=&isProfessionalList=&value(contactValidatePassed)=true&value(createCapForParcelType)=&SKIP_EMSE_FLAG=N&isFromAssetList=null%20&isValidationFailed=true&isValidated=null&_viewstate_=%7B%22empty%22%3Afalse%2C%22fields%22%3A%7B%22value"
		"(contactsModel2*maskedSsn)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22SSN%22%7D%2C%22value(contactsModel2*fein)%22%3A%7B%22maskValue%22%3A%22%22%2C%22originalValue%22%3A%22%22%2C%22strategy%22%3A%22FEIN%22%7D%7D%7D&accelasubmitbuttonname=Previous&callBack=&variableKey=onLoad&refAPONumber=undefined&argumentPKs="
		"%5B%7B%22portletID%22%3A-1%2C%22viewKey1%22%3A%22%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%2C%7B%22portletID%22%3A124%2C%22viewKey1%22%3A%22Complainant%22%2C%22viewKey2%22%3A%22%22%2C%22viewKey3%22%3A%22%22%7D%5D&expressionPageType=SPEAR&mode=execute", 
		LAST);

	web_submit_data("empty.jsp_6", 
		"Action=https://av-pt-ferrari.accela.com/portlets/framework/includes/error/empty.jsp", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t170.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		LAST);

	lr_think_time(26);

	web_url("session.do_14", 
		"URL=https://av-pt-ferrari.accela.com/portlets/spa/session.do?mode=activateSpace&spaceName=spaces.383b1&module=Enforcement", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://av-pt-ferrari.accela.com/portlets/cap/CapBySingle.do?module=Enforcement", 
		"Snapshot=t171.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}